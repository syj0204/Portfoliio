package com.soma.second.matnam.ui;

public class ApplicationData {
	public static final String CLIENT_ID = "681cf04ffb9b4e9a902d4c066b559282";
	public static final String CLIENT_SECRET = "901e6e29691e4d918b0cb020112f6bcb";
	public static final String CALLBACK_URL = "http://localhost";

}
