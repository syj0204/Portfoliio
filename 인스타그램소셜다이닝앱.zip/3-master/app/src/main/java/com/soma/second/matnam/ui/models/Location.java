package com.soma.second.matnam.ui.models;

/**
 * Created by Dongjun on 15. 11. 2..
 */
public class Location {

    private String name;

    public Location(String _name) {
        this.name = _name;
    }

    public String getName() { return this.name; }
    public void setName(String _name) { this.name = _name;  }

}
