package com.example.youngjoosuh.namecard;

/**
 * Created by youngjoosuh on 2016. 10. 30..
 */
public class InfoList {
}
