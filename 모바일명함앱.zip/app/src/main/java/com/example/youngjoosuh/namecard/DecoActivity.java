package com.example.youngjoosuh.namecard;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.TypedValue;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;

/**
 * Created by youngjoosuh on 2016. 10. 30..
 */
public class DecoActivity extends AppCompatActivity {

    Intent intent = null;
    ImageView picture = null;
    TextView name = null;
    TextView department = null;
    TextView title = null;
    TextView company = null;
    TextView address = null;
    TextView phoneNum = null;
    TextView cellNum = null;
    TextView email = null;
    TextView sns = null;
    LinearLayout linearLayout = null;

    final CharSequence[] items = {"사진촬영", "갤러리가기", "삭제"};
    static final int CALL_CAMERA = 0;
    static final int CALL_GALLERY = 1;

    private static final String SD_PATH = Environment.getExternalStorageDirectory().getAbsolutePath();
    private static final String DIR_PATH = SD_PATH + "/namecard";
    public static final String IMG_PATH = DIR_PATH + "/namecard.jpg";
    File imgFile = null;
    FileOutputStream fos = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deco);

        picture = (ImageView)findViewById(R.id.picture);
        name = (TextView)findViewById(R.id.name);
        department = (TextView)findViewById(R.id.department);
        title = (TextView)findViewById(R.id.title);
        company = (TextView)findViewById(R.id.company);
        address = (TextView)findViewById(R.id.address);
        phoneNum = (TextView)findViewById(R.id.phoneNum);
        cellNum = (TextView)findViewById(R.id.cellNum);
        email = (TextView)findViewById(R.id.email);
        sns = (TextView)findViewById(R.id.sns);

        linearLayout = (LinearLayout)findViewById(R.id.namecardView);

        intent = getIntent();

        if(intent.getStringExtra("picture") != null) {
            File temp = new File(InputActivity.IMG_PATH);
            if(temp.exists()) {
                Bitmap bmp = BitmapFactory.decodeFile(InputActivity.IMG_PATH);
                picture.setImageBitmap(bmp);
            } else Toast.makeText(getApplicationContext(), "This image does not exists!!", Toast.LENGTH_SHORT).show();

        }
        if(intent.getStringExtra("name") != null) {
            name.setText(intent.getStringExtra("name"));
        }
        if(intent.getStringExtra("department") != null) {
            department.setText(intent.getStringExtra("department"));
        }
        if(intent.getStringExtra("title") != null) {
            title.setText(intent.getStringExtra("title"));
        }
        if(intent.getStringExtra("company") != null) {
            company.setText(intent.getStringExtra("company"));
        }
        if(intent.getStringExtra("address") != null) {
            address.setText(intent.getStringExtra("address"));
        }
        if(intent.getStringExtra("phoneNum") != null) {
            phoneNum.setText(intent.getStringExtra("phoneNum"));
        }
        if(intent.getStringExtra("cellNum") != null) {
            cellNum.setText(intent.getStringExtra("cellNum"));
        }
        if(intent.getStringExtra("email") != null) {
            email.setText(intent.getStringExtra("email"));
        }
        if(intent.getStringExtra("sns") != null) {
            sns.setText(intent.getStringExtra("sns"));
        }

        public void templeteBtn(View v) {
            final CharSequence[] items = {"Templete1", "Templete2", "Templete3", "Templete4", "Templete5", "Templete6", "Templete7", "Templete8", "Templete9", "Templete10"};
            AlertDialog.Builder builder = new AlertDialog.Builder(DecoActivity.this);
            builder.setTitle("배경화면 선택");
            builder.setItems(items, new DialogInterface.OnClickListener() {
                @Override
                 public void onClick(DialogInterface dialog, int which) {
                     switch(which) {
                         case 0:
                             linearLayout.setBackgroundResource(R.drawable.templete1);
                             break;
                         case 1:
                             linearLayout.setBackgroundResource(R.drawable.templete2);
                             break;
                         case 2:
                             linearLayout.setBackgroundResource(R.drawable.templete3);
                             break;
                         case 3:
                             linearLayout.setBackgroundResource(R.drawable.templete4);
                             break;
                         case 4:
                             linearLayout.setBackgroundResource(R.drawable.templete5);
                             break;
                         case 5:
                             linearLayout.setBackgroundResource(R.drawable.templete6);
                             break;
                         case 6:
                             linearLayout.setBackgroundResource(R.drawable.templete7);
                             break;
                         case 7:
                             linearLayout.setBackgroundResource(R.drawable.templete8);
                             break;
                         case 8:
                             linearLayout.setBackgroundResource(R.drawable.templete9);
                             break;
                         case 9:
                             linearLayout.setBackgroundResource(R.drawable.templete10);
                             break;
                     }
                }
             }).setNegativeButton("Cancel", null).show();
        }

    public void textColorBtn(View v) {
        final CharSequence[] items = {"BLACK", "BLUE", "DARK GRAY", "GRAY"};
        AlertDialog.Builder builder = new AlertDialog.Builder(DecoActivity.this);
        builder.setTitle("글씨색 선택");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0:
                        name.setTextColor(Color.BLACK);
                        department.setTextColor(Color.BLACK);
                        title.setTextColor(Color.BLACK);
                        company.setTextColor(Color.BLACK);
                        address.setTextColor(Color.BLACK);
                        phoneNum.setTextColor(Color.BLACK);
                        cellNum.setTextColor(Color.BLACK);
                        email.setTextColor(Color.BLACK);
                        sns.setTextColor(Color.BLACK);
                        break;

                    case 1:
                        name.setTextColor(Color.BLUE);
                        department.setTextColor(Color.BLUE);
                        title.setTextColor(Color.BLUE);
                        company.setTextColor(Color.BLUE);
                        address.setTextColor(Color.BLUE);
                        phoneNum.setTextColor(Color.BLUE);
                        cellNum.setTextColor(Color.BLUE);
                        email.setTextColor(Color.BLUE);
                        sns.setTextColor(Color.BLUE);
                        break;

                    case 2:
                        name.setTextColor(Color.DKGRAY);
                        department.setTextColor(Color.DKGRAY);
                        title.setTextColor(Color.DKGRAY);
                        company.setTextColor(Color.DKGRAY);
                        address.setTextColor(Color.DKGRAY);
                        phoneNum.setTextColor(Color.DKGRAY);
                        cellNum.setTextColor(Color.DKGRAY);
                        email.setTextColor(Color.DKGRAY);
                        sns.setTextColor(Color.DKGRAY);
                        break;

                    case 3:
                        name.setTextColor(Color.GRAY);
                        department.setTextColor(Color.GRAY);
                        title.setTextColor(Color.GRAY);
                        company.setTextColor(Color.GRAY);
                        address.setTextColor(Color.GRAY);
                        phoneNum.setTextColor(Color.GRAY);
                        cellNum.setTextColor(Color.GRAY);
                        email.setTextColor(Color.GRAY);
                        sns.setTextColor(Color.GRAY);
                        break;
                }
            }
        }).setNegativeButton("Cancel", null).show();
    }


    public void textSizeBtn(View v) {
        final CharSequence[] items = {"13sp", "15sp", "17sp", "20sp"};
        AlertDialog.Builder builder = new AlertDialog.Builder(DecoActivity.this);
        builder.setTitle("글씨색 선택");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch(which) {
                    case 0:
                        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.0f);
                        department.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.0f);
                        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.0f);
                        company.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.0f);
                        address.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.0f);
                        phoneNum.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.0f);
                        cellNum.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.0f);
                        email.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.0f);
                        sns.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.0f);
                        break;

                    case 1:
                        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.0f);
                        department.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.0f);
                        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.0f);
                        company.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.0f);
                        address.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.0f);
                        phoneNum.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.0f);
                        cellNum.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.0f);
                        email.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.0f);
                        sns.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.0f);
                        break;

                    case 2:
                        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17.0f);
                        department.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17.0f);
                        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17.0f);
                        company.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17.0f);
                        address.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17.0f);
                        phoneNum.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17.0f);
                        cellNum.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17.0f);
                        email.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17.0f);
                        sns.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17.0f);
                        break;

                    case 3:
                        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20.0f);
                        department.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20.0f);
                        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20.0f);
                        company.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20.0f);
                        address.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20.0f);
                        phoneNum.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20.0f);
                        cellNum.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20.0f);
                        email.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20.0f);
                        sns.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20.0f);
                        break;
                }
            }
        }).setNegativeButton("Cancel", null).show();

    }

    public void saveBtn(View v) {
        makeDirectory();
        intent = new Intent(DecoActivity.this, FinalActivity.class);
        imgFile = new File(IMG_PATH);

        try {
            fos = new FileOutputStream(imgFile);
            linearLayout.setDrawingCacheEnabled(true);
            Bitmap bitmap = linearLayout.getDrawingCache();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();

            linearLayout.setDrawingCacheEnabled(false);
            fos.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
        intent.putExtra("namecard", "IMG_PATH");
        startActivity(intent);

    }

    public void makeDirectory() {
        File folderFile = new File(DIR_PATH);
        folderFile.mkdirs();
    }

}
