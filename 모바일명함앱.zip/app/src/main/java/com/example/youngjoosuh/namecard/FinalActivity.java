package com.example.youngjoosuh.namecard;

import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

import java.io.File;

/**
 * Created by youngjoosuh on 2016. 10. 30..
 */
public class FinalActivity extends AppCompatActivity {

    Intent intent = null;
    ImageView namecard = null;
    InputActivity inputActivity = null;
    DecoActivity decoActivity = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);

        namecard = (ImageView)findViewById(R.id.namecard);
        intent = getIntent();
        File temp = new File(DecoActivity.IMG_PATH);
        if(temp.exists()) {
            Bitmap bitmap = BitmapFactory.decodeFile(DecoActivity.IMG_PATH);
            namecard.setImageBitmap(bitmap);
        }
    }

    public boolean checkExist(String packageName) {
        try {
            ApplicationInfo info = getPackageManager().getApplicationInfo(packageName, 0);
            return true;
        } catch(PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    public void kakaoBtn(View v) {
        Uri fileUri = Uri.parse(DecoActivity.IMG_PATH);
        String filePath = fileUri.getPath();
        Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, null, "_data='" + filePath + "'", null, null);
        c.moveToNext();
        int id = c.getInt(0);
        Uri uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);


        if(checkExist("com.kakao.talk")) {
            intent = new Intent(Intent.ACTION_SEND);
            intent.setType("image/png");
            intent.setPackage("com.kakao.talk");
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            startActivity(intent);
        }
    }

    public void faceBtn(View v) {
        Uri fileUri = Uri.parse(DecoActivity.IMG_PATH);
        String filePath = fileUri.getPath();
        Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, null, "_data='" + filePath + "'", null, null);
        c.moveToNext();
        int id = c.getInt(0);
        Uri uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);


        if(checkExist("com.facebook.katana")) {
            intent = new Intent(Intent.ACTION_SEND);
            intent.setType("image/png");
            intent.setPackage("com.facebook.katana");
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            startActivity(intent);
        }
    }

    public void toMainBtn(View v) {
        Uri fileUri = Uri.parse(DecoActivity.IMG_PATH);
        String filePath = fileUri.getPath();
        Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, null, "_data='" + filePath + "'", null, null);
        c.moveToNext();
        int id = c.getInt(0);
        Uri uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);


        if(checkExist("com.kakao.talk")) {
            intent = new Intent(Intent.ACTION_SEND);
            intent.setType("image/png");
            intent.setPackage("com.kakao.talk");
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            startActivity(intent);
        }
    }

    public void shareBtn(View v) {
        Uri fileUri = Uri.parse(DecoActivity.IMG_PATH);
        String filePath = fileUri.getPath();
        Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, null, "_data='" + filePath + "'", null, null);
        c.moveToNext();
        int id = c.getInt(0);
        Uri uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);

        intent = new Intent(Intent.ACTION_SEND);
        intent.setType("image/png");
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        startActivity(intent);

    }
}
