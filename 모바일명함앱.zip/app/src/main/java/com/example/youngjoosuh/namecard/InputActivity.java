package com.example.youngjoosuh.namecard;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import java.io.File;
import java.io.FileOutputStream;

/**
 * Created by youngjoosuh on 2016. 10. 30..
 */
public class InputActivity extends AppCompatActivity {
    Intent intent = null;
    ImageView picture = null;
    EditText name = null;
    EditText department = null;
    EditText title = null;
    EditText company = null;
    EditText address = null;
    EditText phoneNum = null;
    EditText cellNum = null;
    EditText email = null;
    EditText sns = null;

    final CharSequence[] items = {"사진촬영", "갤러리가기", "삭제"};
    static final int CALL_CAMERA = 0;
    static final int CALL_GALLERY = 1;

    private static final String SD_PATH = Environment.getExternalStorageDirectory().getAbsolutePath();
    private static final String DIR_PATH = SD_PATH + "/namecard";
    public static final String IMG_PATH = DIR_PATH + "/namecard.jpg";
    File imgFile = null;
    FileOutputStream fos = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);

        picture = (ImageView)findViewById(R.id.picture);
        name = (EditText)findViewById(R.id.name);
        department = (EditText)findViewById(R.id.department);
        title = (EditText)findViewById(R.id.title);
        company = (EditText)findViewById(R.id.company);
        address = (EditText)findViewById(R.id.address);
        phoneNum = (EditText)findViewById(R.id.phoneNum);
        cellNum = (EditText)findViewById(R.id.cellNum);
        email = (EditText)findViewById(R.id.email);
        sns = (EditText)findViewById(R.id.sns);

    }

    public void pictureClick(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(InputActivity.this);
        builder.setTitle("사진선택");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (items[which] == "사진촬영") {
                    makeDirectory();
                    intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(intent, CALL_CAMERA);
                } else if (items[which] == "갤러리가기") {
                    makeDirectory();
                    intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent, CALL_CAMERA);
                } else if (items[which] == "삭제") {

                }
            }
        });
    }

    private void makeDirectory() {
        File folderFile = new File(DIR_PATH);
        folderFile.mkdirs();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == RESULT_OK) {
            Bitmap bit = null;
            switch (requestCode) {
                case CALL_CAMERA:
                    try {
                        bit = (Bitmap) data.getExtras().get("data");
                        picture.setImageBitmap(bit);
                        imgFile = new File(IMG_PATH);
                        fos = new FileOutputStream(imgFile);
                        bit.compress(Bitmap.CompressFormat.JPEG, 100, fos);
                        fos.flush();
                        fos.close();

                    } catch(Exception e) {
                        e.printStackTrace();
                    }
                    break;

                case CALL_GALLERY:
                    try {
                        picture.setImageBitmap(MediaStore.Images.Media.getBitmap(getContentResolver(), data.getData()));
                        imgFile = new File(IMG_PATH);
                        fos = new FileOutputStream(imgFile);
                        Uri uri = data.getData();
                        bit = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                        bit.compress(Bitmap.CompressFormat.JPEG, 100, fos);
                        fos.flush();
                        fos.close();

                    } catch(Exception e) {
                        e.printStackTrace();
                    }

                    Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                    Uri uri = Uri.parse("file://"+IMG_PATH);
                    intent.setData(uri);
                    sendBroadcast(intent);
                    break;
            }
        }
    }

    public void nextBtnClick(View v) {
        intent = new Intent(InputActivity.this, DecoActivity.class);
        intent.putExtra("picture", IMG_PATH);
        intent.putExtra("name", name.getText().toString());
        intent.putExtra("department", department.getText().toString());
        intent.putExtra("title", title.getText().toString());
        intent.putExtra("company", company.getText().toString());
        intent.putExtra("address", address.getText().toString());
        intent.putExtra("phoneNum", phoneNum.getText().toString());
        intent.putExtra("cellNum", cellNum.getText().toString());
        intent.putExtra("email", email.getText().toString());
        intent.putExtra("sns", sns.getText().toString());

        startActivity(intent);
    }

    public void getInfoBtnClick(View v) {
        intent = new Intent(InputActivity.this, InfoList.class);
        startActivity(intent);
    }
}
