var express = require('express');
var io = require('socket.io');
var http = require('http');
var path = require('path');
var bodyParser = require('body-parser');
var methodOverride = require('method-override');
var cookieParser = require('cookie-parser');
var session = require('express-session');
var async = require('async');
var redis = require('redis');
var db = redis.createClient(6379, '1.234.65.181', {});
var myutils = require('./routes/myutils');
var router = express.Router();

router.use(function(req, res, next) {
	console.log('ROUTER USE', req.method, req.url);
	if (req.session.gwlist) {
		console.log('SESS GWID', req.session.gwlist);
		req.session.gwlist = JSON.parse(req.session.gwlist);
	}
	next();
});

var app = express();
var ejs = require('ejs'),
	LRU = require('lru-cache');
ejs.cache = LRU(100);

var ioserv = {};
var sensorname;

app.use(session({
	secret: 'JJK'
	,resave: false
	,saveUninitialized: true
}));
app.use(cookieParser());
app.use(methodOverride());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.set('port', process.env.PORT || 8080);
app.set('views', __dirname + '/views');
console.log('dirName : ' + __dirname);
app.set('view engine', 'ejs');

app.get('/', function (req, res) {
	res.redirect('/current');
});

var sensors = { 'DUST': 'tag1',
				'MQ_3': 'tag2',
				'MQ_4': 'tag3',
				'MQ_5': 'tag4',
				'FIRE': 'tag5',
				'MQ_7': 'tag6',
				'TEMP': 'tag7',
				'HUM' : 'tag8',
				'DISTANCE': 'tag9' };
var sensornames = Object.keys(sensors);

app.get('/current',  function (req, res) {
	res.render('pages/current2', { sensornames: sensornames });
});

var bodysensors = { 'SPO2': 'tag1',
					'BPM' : 'tag2',
					'BODY_TEMP': 'tag3' };
var bodysensornames = Object.keys(bodysensors);

app.get('/bodychart', function (req, res) {
	res.render('pages/current3', { sensornames: bodysensornames });
});

app.post('/api/setui',  function (req,res) {
	var jsonData = "";
  		req.on('data', function (chunk) {
   		jsonData += chunk;
  	});
	req.on('end', function () {
	    var reqObj = JSON.parse(jsonData);
	    for(var i in reqObj) {
	    	var parsed_data = JSON.parse(reqObj[i]);
			ioserv.sockets.in('CURRENT').emit('redraw',
				{ sensorname: i, point: parsed_data });
	    }
	});
});

app.get('/api/current', function (req, res) {
	console.log('/api/current', req.query);
	sensorname = req.query.sensorname;
	db.lindex(sensorname, 0, function (err, data) {
		var rdata = [
			Number(data.substr(0, 13)),
			Number(data.substr(14, 5))
		];
		res.json(rdata);
	});
});

var data1 = require('./routes/data1');
app.get('/api/data1', function (req, res) {
	console.log('/api/data1', req.query);
	res.json(data1.data);
});

var data2 = require('./routes/data2');
app.get('/api/data2', function (req, res) {
	console.log('/api/data2', req.query);
	res.json(data2.data);
});

app.get('/api/many', function (req, res) {
	sensorname = req.query.sensorname;
	db.lrange(sensorname, 0, 19, function(err, data) {
		var rdata = [];
		for(var i=data.length-1; i>=0; i--) {
			rdata.push([
				Number(data[i].substr(0, 13)),
				Number(data[i].substr(14, 5))
			]);
		}
		res.json(rdata);
	});
});

var port = app.get('port');
console.log('port =', port);
var server = http.createServer(app);

process.env.TZ = 'Asia/Seoul';

server.listen(port, function() {
	console.log('Express server listening on port ' + app.get('port'));
});

var allClients = [];

ioserv = io.listen(server);
ioserv.sockets.on('connection', function (socket) {
	allClients.push(socket);
	console.log('RECV: NEW CONN', allClients.length);

	socket.on('joinroom', function (roomname) {
		console.log('RECV: joinroom', roomname);
		socket.join(roomname);
	});

	socket.on('disconnect', function () {
		var i = allClients.indexOf(socket);
		delete allClients[i];
		console.log('RECV: disconnect', i, allClients.length);
	});
});
