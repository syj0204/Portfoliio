package com.example.moveic;

import kbssm.hightech.adballoon.R;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;

public class LoadingPage extends View implements Runnable
{
	/*
    WindowManager.LayoutParams lpWindow = new WindowManager.LayoutParams();    
    lpWindow.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
    lpWindow.dimAmount = 0.8f;
    lpWindow.windowAnimations = android.R.anim.accelerate_interpolator | android.R.anim.fade_in | android.R.anim.fade_out;
    getWindow().setAttributes(lpWindow);
     
   // setContentView(R.layout.popdialog);
    */
	
	
	private Drawable image;
	int viewWidth, viewHeight;
	int imageWidth, imageHeight;
	int x, y;
	
	public LoadingPage(Context context, AttributeSet attrs)
	{
		super(context, attrs);
		
		image = this.getResources().getDrawable(R.drawable.ic_adballoon);
		
		Thread thread = new Thread(this);
		thread.start();
	}
	
	@Override
	protected void onSizeChanged(int w, int h, int oldw , int oldh)
	{
		super.onSizeChanged(w, h, oldw, oldh);
		
		viewWidth = this.getWidth();
		viewHeight = this.getHeight();
		
		imageWidth = image.getIntrinsicWidth();
		imageHeight = image.getIntrinsicHeight();
		
		x = viewWidth/2 - imageWidth/2;
		y = viewHeight/3 - imageHeight/2;
	}
	
	@Override
	protected void onDraw(Canvas canvas)
	{
		super.onDraw(canvas);
		
		image.setBounds(x,y,x + imageWidth, y + imageHeight);
		image.draw(canvas);
	}

	@Override
	public void run()
	{
		// TODO Auto-generated method stub
		while(true)
		{
			for(int i=0 ; i<100 ; i++)
			{
				try
				{
					Thread.sleep(50);
					if((i%20)<=9){
						y -= 4;
					}
					else if((i%20)>=10){
						y += 4;
					}
					this.postInvalidate();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
		}
		
	}


}
