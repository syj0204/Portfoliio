package com.example.moveic;

import kbssm.hightech.adballoon.R;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.loadingpage);
		
		Intent intent = new Intent(getApplicationContext(), Loading.class);
		startActivity(intent);
	}
}