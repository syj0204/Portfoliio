package kbssm.hightech.adballoon;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.Signature;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentActivity;
import android.util.Base64;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.facebook.AppEventsLogger;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.UiLifecycleHelper;
import com.facebook.model.GraphUser;
import com.facebook.widget.FacebookDialog;
import com.facebook.widget.LoginButton;

public class Login extends FragmentActivity{
	
	private AdBalloon App;
	
	private UiLifecycleHelper uiHelper;
	
	private GraphUser user;
	
	private Dialog dialog;
	
	private ImageView adBalloon;
	private ViewGroup container;
	private View selectedItem;

	private boolean isFacebookInstalled = false;
	private float deltaX, deltaY;
	private boolean isTouched = false;
	
    private Session.StatusCallback callback = new Session.StatusCallback() {
        @Override
        public void call(Session session, SessionState state, Exception exception) {
            onSessionStateChange(session, state, exception);
        }
    };

    private FacebookDialog.Callback dialogCallback = new FacebookDialog.Callback() {
        @Override
        public void onError(FacebookDialog.PendingCall pendingCall, Exception error, Bundle data) {
            Log.d("Ad Balloon", String.format("Error: %s", error.toString()));
        }

        @Override
        public void onComplete(FacebookDialog.PendingCall pendingCall, Bundle data) {
            Log.d("Ad Balloon", "Success!");
        }
    };
	
	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		try {
            PackageInfo info = getPackageManager().getPackageInfo(
                    "kbssm.hightech.adballoon", 
                    PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.d("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT));
                }
        } catch (NameNotFoundException e) {

        } catch (NoSuchAlgorithmException e) {

        }
		
		uiHelper = new UiLifecycleHelper(this, callback);
        uiHelper.onCreate(savedInstanceState);
		
		setContentView(R.layout.login);

		Display display = ((WindowManager)getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
		deltaX = display.getWidth() * 0.5f;
		deltaY = display.getHeight() * 0.5f;
		
		final Animation trans = AnimationUtils.loadAnimation(Login.this, R.anim.slide_up);
		trans.setFillAfter(true);
		adBalloon = (ImageView)findViewById(R.id.img_intro_adballoon);

		final Button googlePlusLogin = (Button)findViewById(R.id.googleplus_login);
		
		LoginButton facebookLogin = (LoginButton)findViewById(R.id.authButton);
		final Button facebookLogin2 = (Button)findViewById(R.id.facebook_login2);
		
		//CheckPackage check = new CheckPackage();
		/*if(check.checkFacebook(getApplicationContext())){
			facebookLogin.setVisibility(View.VISIBLE);
			facebookLogin.setEnabled(true);
			facebookLogin2.setVisibility(View.VISIBLE);
			isFacebookInstalled = false;
		} else {*/
			facebookLogin.setVisibility(View.GONE);
			facebookLogin.setEnabled(true);
			facebookLogin2.setVisibility(View.VISIBLE);
			isFacebookInstalled = false;
			/*facebookLogin.setUserInfoChangedCallback(new LoginButton.UserInfoChangedCallback() {
	            @Override
	            public void onUserInfoFetched(GraphUser user) {
	                //TempFacebook.this.user = user;
	                //updateUI();
	                Log.d("setUserInfoChanged", "2");
	                if(user == null){
	                	Log.d("setUserInfoChanged", "null");
	                } else if(user != null){
	                	Log.d("setUserInfoChanged", "Name : "+user.getName());
	                	App = (AdBalloon)getApplication();
	                	App.setFacebookUser(user);
	                	
	                	//HttpSupport httpSupport = new HttpSupport();
	                	//httpSupport.loginConnect(getApplicationContext(), "http://112.108.40.157/MiniProject/join_control.jsp", user, null);
	                	
	                	Intent intent = new Intent(getApplicationContext(), MainMenu.class);
	                	startActivity(intent);
	                }
	            }
	        });*/
		//}
		
		facebookLogin2.setOnClickListener(buttonClick);
		
		/*facebookLogin.setUserInfoChangedCallback(new LoginButton.UserInfoChangedCallback() {
            @Override
            public void onUserInfoFetched(GraphUser user) {
                Login.this.user = user;
                //updateUI();
                Log.d("setUserInfoChanged", "2");
                if(user != null){
                	Log.d("setUserInfoChanged", "Name : "+user.getName());
                	App = (AdBalloon)getApplication();
                	App.setFacebookUser(user);
                	
                	Intent intent = new Intent(getApplicationContext(), MainMenu.class);
                	startActivity(intent);
                	finish();
                }
                // It's possible that we were waiting for this.user to be populated in order to post a
                // status update.
                //handlePendingAction();
            }
        });*/
		googlePlusLogin.setOnClickListener(buttonClick);
		final ImageButton managerLogin = (ImageButton)findViewById(R.id.manager_login);
		managerLogin.setOnClickListener(buttonClick);
		
		facebookLogin2.setAlpha(0.0f);
		googlePlusLogin.setAlpha(0.0f);
		managerLogin.setAlpha(0.0f);
		
		Handler introDelay = new Handler();
		introDelay.postDelayed(new Runnable() {	
			@Override
			public void run() {
				adBalloon.startAnimation(trans);
				
				facebookLogin2.setAlpha(1.0f);
				googlePlusLogin.setAlpha(1.0f);
				managerLogin.setAlpha(1.0f);
				
				Animation alpha = AnimationUtils.loadAnimation(Login.this, R.anim.intro_alpha);
				alpha.setFillAfter(true);
				facebookLogin2.startAnimation(alpha);
				googlePlusLogin.startAnimation(alpha);
				managerLogin.startAnimation(alpha);
			}
		}, 700);
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event){
		int x = (int)(event.getX() * -1 + deltaX);
		int y = (int)(event.getY() * -1 + deltaY);
		//adBalloon.scrollTo(x, y);
		return super.onTouchEvent(event);
	}
	
	OnClickListener buttonClick = new OnClickListener() {
		@Override
		public void onClick(View v) {
			Intent intent;
			/*PackageManager pm = getPackageManager();
        	PackageInfo pi;
        	CheckPackage check = new CheckPackage();*/
			switch(v.getId()){
			case R.id.facebook_login2:

					Intent intent2 = new Intent(getApplicationContext(), TempFacebook.class);
					startActivity(intent2);

				break;
			case R.id.googleplus_login:
            	/*try {
					pi = pm.getPackageInfo("com.google.android.apps.plus", PackageManager.GET_ACTIVITIES);
					
					intent = new Intent(getApplicationContext(), HelloActivity.class);
					intent.putExtra(HelloActivity.TYPE_KEY, HelloActivity.Type.FOREGROUND.name());
					startActivity(intent);
				} catch (NameNotFoundException e) {
					e.printStackTrace();
					final Intent googleplus_link = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.apps.plus"));
            		startActivity(googleplus_link);
            		Toast.makeText(getApplicationContext(), "Google+ ���� ��ġ�Ǿ� �־�� �մϴ�.", Toast.LENGTH_SHORT).show();
				}*/
				//if(check.checkGooglePlus(getApplicationContext())){
					intent = new Intent(getApplicationContext(), HelloActivity.class);
					intent.putExtra(HelloActivity.TYPE_KEY, HelloActivity.Type.FOREGROUND.name());
					startActivity(intent);
				/*} else {
					final Intent googleplus_link = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.google.android.apps.plus"));
            		startActivity(googleplus_link);
            		Toast.makeText(getApplicationContext(), "Google+ ���� ��ġ�Ǿ� �־�� �մϴ�.", Toast.LENGTH_SHORT).show();
				}*/
				break;
			case R.id.manager_login:
				/*WebViewDialog dialog = new WebViewDialog(Login.this, "http://112.108.40.157:8080/MiniProject/login_form.html");
				dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
				dialog.show();*/
				/*intent = new Intent(getApplicationContext(), LoginAdmin.class);
				startActivity(intent);*/
				final String SERVER_URL = "http://112.108.40.157:8080/MiniProject/";
				startWebView(SERVER_URL+"login_form.html");
				break;
			}
		}
	};
	
	private void startWebView(String url){
		Intent intent = new Intent(getApplicationContext(), LoadWebView.class);
		intent.putExtra("URL", url);
		startActivity(intent);
	}
	
	@Override
    protected void onResume() {
        super.onResume();
        uiHelper.onResume();

        App = (AdBalloon)getApplication();
        App.clearAll();
        // Call the 'activateApp' method to log an app event for use in analytics and advertising reporting.  Do so in
        // the onResume methods of the primary Activities that an app may be launched into.
        AppEventsLogger.activateApp(this);

        //updateUI();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        uiHelper.onSaveInstanceState(outState);

        //outState.putString(PENDING_ACTION_BUNDLE_KEY, pendingAction.name());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        uiHelper.onActivityResult(requestCode, resultCode, data, dialogCallback);
    }

    @Override
    public void onPause() {
        super.onPause();
        uiHelper.onPause();
    }
    
    @Override
    public void onStop() {
    	super.onPause();
    	uiHelper.onStop();
    	if(dialog != null){
    		dialog.dismiss();
    	}
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        uiHelper.onDestroy();
    }

    private void onSessionStateChange(Session session, SessionState state, Exception exception) {
        /*if (pendingAction != PendingAction.NONE &&
                (exception instanceof FacebookOperationCanceledException ||
                exception instanceof FacebookAuthorizationException)) {
                new AlertDialog.Builder(HelloFacebookSampleActivity.this)
                    .setTitle(R.string.cancelled)
                    .setMessage(R.string.permission_not_granted)
                    .setPositiveButton(R.string.ok, null)
                    .show();
            pendingAction = PendingAction.NONE;
        } else if (state == SessionState.OPENED_TOKEN_UPDATED) {
            handlePendingAction();
        }
        updateUI();*/
    	if(session.isOpened() && !isFacebookInstalled){
    		Log.d("onSessionState", "Session is Opened");
    		/*dialog = new Dialog(Login.this);
    		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
    		dialog.setContentView(R.layout.progress_dialog);
    		dialog.show();*/
    		//Log.d("onSessionState", "1");
    		//Toast.makeText(getApplicationContext(), "Name : "+user.getName(), Toast.LENGTH_SHORT).show();
    	} else if(session.isClosed()){
    		Log.d("onSessionState", "Session is Closed");
    		
    	}
    }
}