package kbssm.hightech.adballoon;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

public class WriteEvaluation extends Activity {
	
	private Button write;
	private EditText content;
	private Button loadImage;
	private RatingBar setRating;
	private TextView imageName;
	private ImageView image;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.write_evaluation);
		
		write = (Button)findViewById(R.id.write_evaluation);
		content = (EditText)findViewById(R.id.write_content);
		loadImage = (Button)findViewById(R.id.load_image);
		setRating = (RatingBar)findViewById(R.id.set_rating);
		//imageName = (TextView)findViewById(R.id.image_name);
		image = (ImageView)findViewById(R.id.ivImageSelected);
		
		write.setOnClickListener(buttonClick);
		loadImage.setOnClickListener(buttonClick);
	}
	
	private final int TAKE_GALLERY = 2;
	
	protected OnClickListener buttonClick = new OnClickListener() {
		@Override
		public void onClick(View v) {
			switch(v.getId()){
			case R.id.write_evaluation:
				
				break;
			case R.id.load_image:
				Intent intent = new Intent(Intent.ACTION_PICK);
				intent.setType(android.provider.MediaStore.Images.Media.CONTENT_TYPE);
				startActivityForResult(intent, TAKE_GALLERY);
				break;
			}
		}
	};

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		
		if(resultCode == RESULT_OK){
			if(requestCode == TAKE_GALLERY){
				Uri imageURI = data.getData();
				
				final String[] filePathColumn = {MediaStore.Images.Media.DATA};
		    	
		    	final Cursor imageCursor = this.getContentResolver().query(imageURI, filePathColumn, null, null, null);
		    	imageCursor.moveToFirst();
		    	
		    	final int columnIndex = imageCursor.getColumnIndex(filePathColumn[0]);
		    	final String imagePath = imageCursor.getString(columnIndex);
		    	imageCursor.close();
		    	
		    	final Bitmap bitmap = BitmapFactory.decodeFile(imagePath);

				image.setImageBitmap(bitmap);
			}
		}
	}
	
}