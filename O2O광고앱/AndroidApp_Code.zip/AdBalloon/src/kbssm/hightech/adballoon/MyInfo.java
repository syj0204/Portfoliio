package kbssm.hightech.adballoon;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.model.GraphUser;
import com.facebook.widget.ProfilePictureView;
import com.google.android.gms.plus.model.people.Person;

public class MyInfo extends Fragment{
	
	private AdBalloon App;
	
	private static final char ENTER = '\n';
	
	private View v;
	private ImageView personImage;
	private TextView myInfoText;
	
	private ImageView facebookIcon;
	private ImageView googleIcon;
	
	private URL personImageUrl;
	private ProfilePictureView profilePictureView;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
		View v = inflater.inflate(R.layout.my_info, container, false);
		this.v = v;
		
		App = (AdBalloon)getActivity().getApplication();
		Log.d("MyInfo", "App : "+App.toString());

		facebookIcon = (ImageView)v.findViewById(R.id.profileFacebookIcon);
		googleIcon = (ImageView)v.findViewById(R.id.profileGoogleIcon);
		
		personImage = (ImageView)v.findViewById(R.id.profileGoogle);
		try {
			if(App.getGoogleUser() != null){
				personImageUrl = new URL(App.getGoogleUser().getImage().getUrl());
				Bitmap imageBitmap = BitmapFactory.decodeStream(personImageUrl.openConnection().getInputStream());
				personImage.setImageBitmap(imageBitmap);
				googleIcon.setImageResource(R.drawable.icon_googleplus);
			} else {
				personImage.setImageResource(R.drawable.bg_no_profile_picture);
				googleIcon.setImageResource(R.drawable.icon_googleplus_gray);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		profilePictureView = (ProfilePictureView)v.findViewById(R.id.profilePicture);
		
		myInfoText = (TextView)v.findViewById(R.id.myInfoText);
		myInfoText.setText(getInfo(App));
		
		Button facebookCheck = (Button)v.findViewById(R.id.facebook_login_check);
		Button googleCheck = (Button)v.findViewById(R.id.google_login_check);
		facebookCheck.setOnClickListener(buttonClick);
		googleCheck.setOnClickListener(buttonClick);
		if(App.getFacebookUser() != null){
			profilePictureView.setProfileId(App.getFacebookUser().getId());
			facebookIcon.setImageResource(R.drawable.icon_facebook);
			facebookCheck.setEnabled(false);
		} else {
			profilePictureView.setProfileId(null);
			facebookIcon.setImageResource(R.drawable.icon_facebook_gray);
		}
		if(App.getGoogleUser() != null){
			googleIcon.setImageResource(R.drawable.icon_googleplus);
			googleCheck.setEnabled(false);
		} else {
			googleIcon.setImageResource(R.drawable.icon_googleplus_gray);
		}
		
		Button editInfo = (Button)v.findViewById(R.id.edit_info);
		editInfo.setEnabled(true);
		editInfo.setOnClickListener(buttonClick);
		
		Bundle args = getArguments();
		
		return v;
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		//setContentView(R.layout.my_info);
		
		
		
		
	}
	
	@Override
	public void onResume(){
		super.onResume();
		if(App.getFacebookUser() != null){
			((Button)v.findViewById(R.id.facebook_login_check)).setEnabled(false);
			profilePictureView.setProfileId(App.getFacebookUser().getId());
			facebookIcon.setImageResource(R.drawable.icon_facebook);
		} else {
			facebookIcon.setImageResource(R.drawable.icon_facebook_gray);
		}
		if(App.getGoogleUser() != null){
			((Button)v.findViewById(R.id.google_login_check)).setEnabled(false);
			try {
				personImageUrl = new URL(App.getGoogleUser().getImage().getUrl());
				Bitmap imageBitmap = BitmapFactory.decodeStream(personImageUrl.openConnection().getInputStream());
				personImage.setImageBitmap(imageBitmap);
				googleIcon.setImageResource(R.drawable.icon_googleplus);
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			googleIcon.setImageResource(R.drawable.icon_googleplus_gray);
		}
		App = (AdBalloon)getActivity().getApplication();
		if(myInfoText != null)
			myInfoText.setText(getInfo(App));
	}
	
	protected OnClickListener buttonClick = new OnClickListener() {
		@Override
		public void onClick(View v) {
			Intent intent;
			CheckPackage check = new CheckPackage();
			switch(v.getId()){
			case R.id.facebook_login_check:
				/*PackageManager pm = getPackageManager();
            	PackageInfo pi;
            	try {
					pi = pm.getPackageInfo("com.facebook.katana", PackageManager.GET_ACTIVITIES);
					
					Intent intent2 = new Intent(getApplicationContext(), TempFacebook.class);
					intent2.putExtra("Where", "MyInfo");
					startActivity(intent2);
				} catch (NameNotFoundException e) {
					e.printStackTrace();
					final Intent facebook_link = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.facebook.katana"));
            		startActivity(facebook_link);
            		Toast.makeText(getApplicationContext(), "Facebook ���� ��ġ�Ǿ� �־�� �մϴ�.", Toast.LENGTH_SHORT).show();
				}*/
				//if(check.checkFacebook(getApplicationContext())){
					Intent intent2 = new Intent(getActivity(), TempFacebook.class);
					intent2.putExtra("Where", "MyInfo");
					startActivity(intent2);
				/*} else {
					final Intent facebook_link = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.facebook.katana"));
            		startActivity(facebook_link);
            		Toast.makeText(getApplicationContext(), "Facebook ���� ��ġ�Ǿ� �־�� �մϴ�.", Toast.LENGTH_SHORT).show();
				}*/
				break;
			case R.id.google_login_check:
				intent = new Intent(getActivity(), HelloActivity.class);
				intent.putExtra("Where", "MyInfo");
				intent.putExtra(HelloActivity.TYPE_KEY, HelloActivity.Type.FOREGROUND.name());
				startActivity(intent);
				break;
			case R.id.edit_info:
				Toast.makeText(getActivity(), "Edit Info", Toast.LENGTH_SHORT).show();
				break;
			}
		}
	};
	
	protected String getInfo(AdBalloon app){
		String info = " Name : \n Age : \n Gender : \n HP : ";
		TextView infoText = (TextView)v.findViewById(R.id.myInfoText0);
		infoText.setText(info);
		String infoContent = "";
		
		TelephonyManager manager = (TelephonyManager)getActivity().getSystemService(Context.TELEPHONY_SERVICE);
		
		if(app.getGoogleUser() != null){
			Person person = app.getGoogleUser();
			
			infoContent = person.getDisplayName()+ENTER;
			if(person.getBirthday() == null){
				if(app.getFacebookUser() == null)
					infoContent += "No Information"+ENTER;
				else if(app.getFacebookUser().getBirthday() != null){
					Calendar c = Calendar.getInstance();
		        	 SimpleDateFormat format = new SimpleDateFormat("yyyy");
		        	 String formatDate = format.format(c.getTime());
		        	 Log.d("date : ", formatDate);
		        	 String birth = app.getFacebookUser().getBirthday().substring(6, 10);
		        	 Log.d("birth : ", birth);
		        	 int age = Integer.parseInt(formatDate) - Integer.parseInt(birth) + 1;
		        	 
		        	 infoContent += String.valueOf(age)+ENTER;
				}
			} else {
				info += person.getBirthday()+"(Birth)";
			}
			switch(person.getGender()){
			case 0:
				infoContent += "Male";
				break;
			case 1:
				infoContent += "Female";
				break;
			default:
				infoContent += "Other";
				break;
			}
		} else if(app.getFacebookUser() != null){
			GraphUser user = app.getFacebookUser();
			
			Calendar c = Calendar.getInstance();
	       	 SimpleDateFormat format = new SimpleDateFormat("yyyy");
	       	 String formatDate = format.format(c.getTime());
	       	 Log.d("date : ", formatDate);
	       	 if(user.getBirthday()!=null){
	       	 String birth = user.getBirthday().substring(6, 10);
	       	 Log.d("birth : ", birth);
	       	 
	       	 int age = Integer.parseInt(formatDate) - Integer.parseInt(birth) + 1;
	       	 
			infoContent = user.getName()+ENTER+String.valueOf(age);
	       	 } else {
	       		infoContent = user.getName()+ENTER+"No Information";
	       	 }
	       	 infoContent += ENTER+
					user.asMap().get("gender").toString();
		} else {
			infoContent = "No SNS UserInfo!";
		}
		infoContent += ENTER+manager.getLine1Number();
		
		return infoContent;
	}
}