package kbssm.hightech.adballoon;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class Intro extends Activity {
	
	private boolean isStop = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.intro);
		
		Handler introDelay = new Handler();
		introDelay.postDelayed(new Runnable() {	
			@Override
			public void run() {
				Intent intent = new Intent(getApplicationContext(), Login.class);
				if(!isStop){
					startActivity(intent);
					overridePendingTransition(R.anim.hold, R.anim.hold);
					finish();
				}
			}
		}, 3000);
		
		Animation alpha = AnimationUtils.loadAnimation(Intro.this, R.anim.intro_alpha);
		
		ImageView imgAdBalloon = (ImageView)findViewById(R.id.img_intro_adballoon);
		imgAdBalloon.startAnimation(alpha);
	}
	
	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		isStop = true;
		
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		if(isStop){
			
			Intent intent = new Intent(getApplicationContext(), Login.class);
			startActivity(intent);
			finish();
		}
	}
}