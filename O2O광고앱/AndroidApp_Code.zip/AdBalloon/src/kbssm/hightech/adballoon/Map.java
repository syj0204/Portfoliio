package kbssm.hightech.adballoon;

import java.io.IOException;
import java.util.List;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.Window;
import android.widget.Toast;

import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class Map extends FragmentActivity{
	
	GoogleMap mGoogleMap;
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.map);
		Log.d("test","10");
		init();
	}

	private void init(){
		 Intent getI = getIntent();
		  String title = getI.getStringExtra("title");
		  String address = getI.getStringExtra("ADDRESS");
		  Toast.makeText(getApplicationContext(), address, Toast.LENGTH_SHORT).show();
		  List<Address> listAddress;    
		  Geocoder geocoder;
		  Address AddrAddress;        
		  
		  double lon = 0;
		  double lat = 0;
		  
		  geocoder = new Geocoder(this);
		  try {
			listAddress = geocoder.getFromLocationName(address, 5);
			//Toast.makeText(getApplicationContext(), ""+listAddress.size(), Toast.LENGTH_SHORT).show();
			if(listAddress.size() > 0){
				  AddrAddress = listAddress.get(0);
				  lon = getI.getDoubleExtra("lon", AddrAddress.getLongitude());
				  lat = getI.getDoubleExtra("lat", AddrAddress.getLatitude());
			  }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		  // ���� �浵 �Ҽ��� 4�ڸ� ���� ������ ���� ��Ȯ
		  
		  LatLng position = new LatLng(lat, lon);
		  Log.d("Init", "?");
		  GooglePlayServicesUtil.isGooglePlayServicesAvailable(Map.this);
		  mGoogleMap = ((SupportMapFragment)getSupportFragmentManager().findFragmentById(R.id.google_map)).getMap();
		  //�� ��ġ�̵�.
		  mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(position, 15));
		  //��Ŀ ����.
		  mGoogleMap.addMarker(new MarkerOptions().position(position).title(title)).showInfoWindow();
		  //��Ŀ Ŭ�� ������
		  mGoogleMap.setOnMarkerClickListener(new OnMarkerClickListener() {
		   
		   @Override
		   public boolean onMarkerClick(Marker marker) {
		    
		    return false;
		   }
		  });
	}
}


