package kbssm.hightech.adballoon;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainMenu extends Activity{
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.main_menu);
		
		Button myInfo = (Button)findViewById(R.id.myInfo);
		Button myCategory = (Button)findViewById(R.id.myCategory);
		Button myFavorite = (Button)findViewById(R.id.myFavorite);
		Button startService = (Button)findViewById(R.id.startService);
		myInfo.setOnClickListener(buttonClick);
		myCategory.setOnClickListener(buttonClick);
		myFavorite.setOnClickListener(buttonClick);
		startService.setOnClickListener(buttonClick);
	}
	
	protected OnClickListener buttonClick = new OnClickListener() {
		Intent intent;
		@Override
		public void onClick(View v) {
			switch(v.getId()){
			case R.id.myInfo:
				intent = new Intent(getApplicationContext(), SwipeActivity.class);
				startActivity(intent);
				break;
			case R.id.myCategory:
				intent = new Intent(getApplicationContext(), MyCategory.class);
				startActivity(intent);
				break;
			case R.id.myFavorite:
				intent = new Intent(getApplicationContext(), MyFavorite.class);
				startActivity(intent);
				break;
			case R.id.startService:
				intent = new Intent(getApplicationContext(), StartService.class);
				startActivity(intent);
				break;
			}
		}
	};
}