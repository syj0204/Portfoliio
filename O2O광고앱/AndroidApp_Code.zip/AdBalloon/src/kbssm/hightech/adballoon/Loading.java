package kbssm.hightech.adballoon;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;

public class Loading extends Dialog {

	public Loading(Context context) {
		//super(context);
		super(context , android.R.style.Theme_Translucent_NoTitleBar);
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.loading);
	}
}