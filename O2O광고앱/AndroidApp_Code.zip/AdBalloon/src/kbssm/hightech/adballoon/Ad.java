package kbssm.hightech.adballoon;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.hardware.display.DisplayManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.FacebookException;
import com.facebook.FacebookOperationCanceledException;
import com.facebook.FacebookRequestError;
import com.facebook.HttpMethod;
import com.facebook.Request;
import com.facebook.RequestAsyncTask;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.UiLifecycleHelper;
import com.facebook.widget.FacebookDialog;
import com.facebook.widget.WebDialog;
import com.facebook.widget.WebDialog.OnCompleteListener;
import com.google.android.gms.plus.PlusShare;

public class Ad extends Activity{
	
	private AdBalloon App;
	private MyThread mMyThread;
	private ArrayList<String> adInfo;
	
	private static final int REQ_SELECT_PHOTO = 1;
	private static final int REQ_START_SHARE = 2;
	private static final String TAG = "AD";
	
	private String adCode = "";
	private String branchCode = "";
	
	private UiLifecycleHelper uiHelper;
	
	private Button goStore;
	private Button shareFacebook;
	private Button shareGooglePlus;
	
	private TextView adStoreName;
	private ImageView adImage;
	private TextView adContent;
	
	private HelpDialog noti;
	
	private Session.StatusCallback callback = new Session.StatusCallback() {
        @Override
        public void call(Session session, SessionState state, Exception exception) {
        	if(exception != null){
        		exception.printStackTrace();
        	}
            onSessionStateChange(session, state, exception);
        }
    };
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		if (savedInstanceState != null) {
		    pendingPublishReauthorization = 
		        savedInstanceState.getBoolean(PENDING_PUBLISH_KEY, false);
		}
		
		uiHelper = new UiLifecycleHelper(this, callback);
		uiHelper.onCreate(savedInstanceState);
		
		Intent intent = getIntent();
		adCode = intent.getStringExtra("AD_CODE");
		
		setContentView(R.layout.ad);
		
		goStore = (Button)findViewById(R.id.go_store);
		goStore.setOnClickListener(buttonClick);
		shareFacebook = (Button)findViewById(R.id.shareButton);
		shareFacebook.setOnClickListener(buttonClick);
		shareGooglePlus = (Button)findViewById(R.id.shareGoogle);
		shareGooglePlus.setOnClickListener(buttonClick);
		
		adStoreName = (TextView)findViewById(R.id.ad_store_name);
		adImage = (ImageView)findViewById(R.id.ad_img);
		adContent = (TextView)findViewById(R.id.ad_content);
		
		mMyThread = (MyThread)new MyThread().execute((Void)null);
	}
	
	private void onSessionStateChange(Session session, SessionState state, Exception exception) {
	    if (state.isOpened()) {
	    	shareFacebook.setVisibility(View.VISIBLE);
	    	if (pendingPublishReauthorization && 
	    	        state.equals(SessionState.OPENED_TOKEN_UPDATED)) {
	    	    pendingPublishReauthorization = false;
	    	    publishStory();
	    	}
	    } else if (state.isClosed()) {
	    	shareFacebook.setVisibility(View.INVISIBLE);
	    }
	}
	
	protected OnClickListener buttonClick = new OnClickListener() {
		@Override
		public void onClick(View v) {
			switch(v.getId()){
			case R.id.go_store:
				if(adStoreName.getText().equals("�ҷ����� ���Դϴ�.")){
					noti = new HelpDialog(Ad.this, "������ �ҷ����� ��", "������ �ҷ����� ���Դϴ�.\n��ø� ��ٷ��ּ���.", click);
					noti.show();
				} else {
					Intent intent = new Intent(getApplicationContext(), Store.class);
					intent.putExtra("BRANCH_CODE", branchCode);
					startActivity(intent);
				}
				break;
			case R.id.shareButton:
				App = (AdBalloon)getApplication();
				//Toast.makeText(getApplicationContext(), "Id : "+App.getFacebookUser(), Toast.LENGTH_SHORT).show();
				if(App.getFacebookUser() != null){
					//Toast.makeText(getApplicationContext(), "in if Id : "+App.getFacebookUser(), Toast.LENGTH_SHORT).show();
					/*FacebookDialog shareDialog = new FacebookDialog.ShareDialogBuilder(Ad.this)
			        .setLink("https://developers.facebook.com/android")
			        .build();
					uiHelper.trackPendingDialogCall(shareDialog.present());*/
					if (FacebookDialog.canPresentShareDialog(getApplicationContext(), 
	                        FacebookDialog.ShareDialogFeature.SHARE_DIALOG)) {
					// Publish the post using the Share Dialog
					/*FacebookDialog shareDialog = new FacebookDialog.ShareDialogBuilder(Ad.this)
					.setLink("https://developers.facebook.com/android")
					.build();
					uiHelper.trackPendingDialogCall(shareDialog.present());*/
					publishStory();
					} else {
					// Fallback. For example, publish the post using the Feed Dialog
						publishFeedDialog();
					}
					noti = new HelpDialog(Ad.this, "Facebook ����", adInfo.get(0)+" �� ������ Facebook�� ���� �����˴ϴ�.", click);
					noti.show();
				} else {
					Toast.makeText(getApplicationContext(), "�ش� ���� �α����� �ʿ��մϴ�.", Toast.LENGTH_SHORT).show();
				}
				break;
			case R.id.shareGoogle:
				App = (AdBalloon)getApplication();
				// Launch the Google+ share dialog with attribution to your app.
					if(App.getGoogleUser() != null){
						Intent shareIntent = new PlusShare.Builder(getApplicationContext())
				          .setType("text/plain")
				          .setText(adInfo.get(1) + " - " + adInfo.get(2) + "     " + adInfo.get(0))
				          .setContentUrl(Uri.parse(adInfo.get(3)))
				          .getIntent();
	
						startActivityForResult(shareIntent, 0);
					} else {
						Toast.makeText(getApplicationContext(), "�ش� ���� �α����� �ʿ��մϴ�.", Toast.LENGTH_SHORT).show();
					}
				break;
				// Read these fields using static methods on FacebookDialog.
				//boolean didCancel = FacebookDialog.getNativeDialogDidComplete(data);
				//String completionGesture = FacebookDialog.getNativeDialogCompletionGesture(data);
				//String postId = FacebookDialog.getNativeDialogPostId(data);
			}
		}
	};
	OnClickListener click = new OnClickListener() {
		@Override
		public void onClick(View v) {
			noti.dismiss();
		}
	};
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	    super.onActivityResult(requestCode, resultCode, data);

	    uiHelper.onActivityResult(requestCode, resultCode, data, new FacebookDialog.Callback() {
	        @Override
	        public void onError(FacebookDialog.PendingCall pendingCall, Exception error, Bundle data) {
	            Log.e("Activity", String.format("Error: %s", error.toString()));
	        }
	        @Override
	        public void onComplete(FacebookDialog.PendingCall pendingCall, Bundle data) {
	            Log.i("Activity", "Success!");
	        }
	    });
	}
	
	@Override
	protected void onResume() {
	    super.onResume();
	    uiHelper.onResume();
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
	    super.onSaveInstanceState(outState);
	    outState.putBoolean(PENDING_PUBLISH_KEY, pendingPublishReauthorization);
	    uiHelper.onSaveInstanceState(outState);
	}

	@Override
	public void onPause() {
	    super.onPause();
	    uiHelper.onPause();
	}

	@Override
	public void onDestroy() {
	    super.onDestroy();
	    uiHelper.onDestroy();
	}
	
	private void publishFeedDialog() {
	    Bundle params = new Bundle();
	    params.putString("name", "AdBalloon");
	    params.putString("caption", adInfo.get(1) + " - " + adInfo.get(2));
	    params.putString("description", adInfo.get(0));
	    //params.putString("link", "https://developers.facebook.com/android");
	    params.putString("picture", adInfo.get(3));

	    WebDialog feedDialog = (
	        new WebDialog.FeedDialogBuilder(this,
	            Session.getActiveSession(),
	            params))
	        .setOnCompleteListener(new OnCompleteListener() {

	            @Override
	            public void onComplete(Bundle values,
	                FacebookException error) {
	                if (error == null) {
	                    // When the story is posted, echo the success
	                    // and the post Id.
	                    final String postId = values.getString("post_id");
	                    if (postId != null) {
	                        Toast.makeText(getApplicationContext(),
	                            "Posted story, id: "+postId,
	                            Toast.LENGTH_SHORT).show();
	                    } else {
	                        // User clicked the Cancel button
	                        Toast.makeText(getApplicationContext().getApplicationContext(), 
	                            "Publish cancelled", 
	                            Toast.LENGTH_SHORT).show();
	                    }
	                } else if (error instanceof FacebookOperationCanceledException) {
	                    // User clicked the "x" button
	                    Toast.makeText(getApplicationContext().getApplicationContext(), 
	                        "Publish cancelled", 
	                        Toast.LENGTH_SHORT).show();
	                } else {
	                    // Generic, ex: network error
	                    Toast.makeText(getApplicationContext().getApplicationContext(), 
	                        "Error posting story", 
	                        Toast.LENGTH_SHORT).show();
	                }
	            }

	        })
	        .build();
	    feedDialog.show();
	}
	
	private static final List<String> PERMISSIONS = Arrays.asList("publish_actions");
	private static final String PENDING_PUBLISH_KEY = "pendingPublishReauthorization";
	private boolean pendingPublishReauthorization = false;
	
	private void publishStory() {
	    Session session = Session.getActiveSession();

	    if (session != null){

	        // Check for publish permissions    
	        List<String> permissions = session.getPermissions();
	        if (!isSubsetOf(PERMISSIONS, permissions)) {
	            pendingPublishReauthorization = true;
	            Session.NewPermissionsRequest newPermissionsRequest = new Session
	                    .NewPermissionsRequest(this, PERMISSIONS);
	        session.requestNewPublishPermissions(newPermissionsRequest);
	            return;
	        }

	        Bundle postParams = new Bundle();
	        postParams.putString("name", "AdBalloon");
	        postParams.putString("caption", adInfo.get(1) + " - " + adInfo.get(2));
	        postParams.putString("description", adInfo.get(0));
	        //postParams.putString("link", "https://developers.facebook.com/android");
	        postParams.putString("picture", adInfo.get(3));

	        Request.Callback callback= new Request.Callback() {
	            public void onCompleted(Response response) {
	                JSONObject graphResponse = response
	                                           .getGraphObject()
	                                           .getInnerJSONObject();
	                String postId = null;
	                try {
	                    postId = graphResponse.getString("id");
	                } catch (JSONException e) {
	                    Log.i(TAG,
	                        "JSON error "+ e.getMessage());
	                }
	                FacebookRequestError error = response.getError();
	                if (error != null) {
	                    Toast.makeText(getApplicationContext()
	                         .getApplicationContext(),
	                         error.getErrorMessage(),
	                         Toast.LENGTH_SHORT).show();
	                    } else {
	                        Toast.makeText(getApplicationContext()
	                             .getApplicationContext(), 
	                             postId,
	                             Toast.LENGTH_LONG).show();
	                }
	            }
	        };

	        Request request = new Request(session, "me/feed", postParams, 
	                              HttpMethod.POST, callback);

	        RequestAsyncTask task = new RequestAsyncTask(request);
	        task.execute();
	    }

	}
	
	private boolean isSubsetOf(Collection<String> subset, Collection<String> superset) {
	    for (String string : subset) {
	        if (!superset.contains(string)) {
	            return false;
	        }
	    }
	    return true;
	}
	
	public class MyThread extends AsyncTask<Void, Void, Void>{
		
		private ArrayList<String> adInfo = new ArrayList<String>();
		
		@Override
		protected Void doInBackground(Void... params) {
			HttpSupport http = new HttpSupport();
			// 0 : AdName  1 : AdBrandName  2 : AdStoreName  3 : AdImageRoot  4 : BranchCode
			adInfo = http.sendAdCode(getApplicationContext(), http.SERVER_URL+"adinfosend_control.jsp", adCode);
			Ad.this.adInfo = adInfo;
			branchCode = adInfo.get(4);
			Log.d("tag", adInfo.get(3)+adInfo.get(4));
				publishProgress((Void)null);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			return null;
		}
		
		@Override
		protected void onProgressUpdate(Void... values){
			//Toast.makeText(getApplicationContext(), "onBackground", Toast.LENGTH_SHORT).show();
			//Toast.makeText(getApplicationContext(), adInfo.toString(), Toast.LENGTH_SHORT).show();
			if(adInfo.size() == 5){
				adStoreName.setText(adInfo.get(1) + " - " + adInfo.get(2));
				adContent.setText(adInfo.get(0));
				Drawable image = ImageOperations(getBaseContext(), adInfo.get(3), "image.jpg");
				Bitmap bitmap = ((BitmapDrawable)image).getBitmap();
				DisplayMetrics displayMetrics = new DisplayMetrics();
				getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
				int deviceWidth = displayMetrics.widthPixels;
				int deviceHeight =displayMetrics.heightPixels;
				image = new BitmapDrawable(getResources(), Bitmap.createScaledBitmap(bitmap, deviceWidth-20, (int)((float)(deviceWidth-20)*(float)((float)deviceHeight/(float)deviceWidth)), true));
				adImage.setImageDrawable(image);
			}
			super.onProgressUpdate(values);
		}
		
		private Drawable ImageOperations(Context ctx, String url, String saveFilename) {
	        try {
	            URL imageUrl = new URL(url);
	            InputStream is = (InputStream) imageUrl.getContent();
	            Drawable d = Drawable.createFromStream(is, "src");
	            return d;
	        } catch (MalformedURLException e) {
	            e.printStackTrace();
	            return null;
	        } catch (IOException e) {
	            e.printStackTrace();
	            return null;
	        }
	    }
	}
}