package kbssm.hightech.adballoon;

import java.util.ArrayList;
import java.util.Arrays;

import android.accounts.AccountManager;
import android.annotation.SuppressLint;
import android.app.Application;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender.SendIntentException;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.FacebookRequestError;
import com.facebook.Request;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.UiLifecycleHelper;
import com.facebook.model.GraphObject;
import com.facebook.model.GraphObjectList;
import com.facebook.model.GraphUser;
import com.facebook.widget.LoginButton;
import com.google.android.gms.common.AccountPicker;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.plus.Plus;
import com.google.android.gms.plus.model.people.Person;

@SuppressLint("ValidFragment")
public class MainFragment extends Fragment {

	private static AdBalloon App;
	
	private static final String TAG = "MainFragment";
	private static final int RECEIVE_RESULT = 10;
	private static final char ENTER = '\n';
	
	private UiLifecycleHelper uiHelper;
	private GraphUser myInfo = null;
	
	private TextView userInfoTextView;
	private TextView result;
	
	private boolean isCancel = false;
	private String mResult = "";
	
	// Google+ Sign-In
	private String mEmail = "";
	/* Request code used to invoke sign in user interactions. */
	  private static final int RC_SIGN_IN = 0;
	  /* Client used to interact with Google APIs. */
	  private GoogleApiClient mGoogleApiClient;
	  /* A flag indicating that a PendingIntent is in progress and prevents
	   * us from starting further intents.
	   */
	  private boolean mIntentInProgress;
	  
	// Request code to use when launching the resolution activity
	    private static final int REQUEST_RESOLVE_ERROR = 1001;
	    // Unique tag for the error dialog fragment
	    private static final String DIALOG_ERROR = "dialog_error";
	    // Bool to track whether the app is already resolving an error
	    private static boolean mResolvingError = false;
	    
	    private boolean mSignInClicked;
	    private ConnectionResult mConnectionResult;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		uiHelper = new UiLifecycleHelper(getActivity(), callback);
        uiHelper.onCreate(savedInstanceState);
        
        //pickUserAccount();  

        /*mGoogleApiClient = new GoogleApiClient.Builder(getActivity())
        .addApi(Plus.API)
        .addScope(Plus.SCOPE_PLUS_LOGIN)
        .addConnectionCallbacks(this)
        .addOnConnectionFailedListener(this)
        .build();*/
        
        /*mResolvingError = savedInstanceState != null
                && savedInstanceState.getBoolean(STATE_RESOLVING_ERROR, false);*/
        //Toast.makeText(getActivity(), "mGoogleApiClient : "+mGoogleApiClient.toString(), Toast.LENGTH_SHORT).show();
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.main, container, false);
		
		view.findViewById(R.id.sign_in_button).setOnClickListener(buttonClick);
		
		LoginButton authButton = (LoginButton) view.findViewById(R.id.authButton);
		authButton.setFragment(this);
		//authButton.setOnClickListener(buttonClick);
		authButton.setReadPermissions(Arrays.asList("user_likes", "user_status", "user_about_me", "user_birthday"));
		
		Button sendRequest = (Button)view.findViewById(R.id.sendRequest);
		sendRequest.setOnClickListener(buttonClick);
		
		// Initialize
        userInfoTextView = (TextView)view.findViewById(R.id.userInfoTextView);
        result = (TextView)view.findViewById(R.id.result);
		
        authButton.performClick();
        
		return view;
	}
	
	private void onSessionStateChange(Session session, SessionState state, Exception exception){
		Log.d("?", "?");
    	if(state.isOpened()){
    		Log.i(TAG, "Logged in...");
    		userInfoTextView.setVisibility(View.VISIBLE);
    		// Request user data and show the results
    	    Request.newMeRequest(session, new Request.GraphUserCallback(){
    	    	@Override
    	        public void onCompleted(GraphUser user, Response response) {
    	            if (user != null) {
    	                // Display the parsed user info
    	                userInfoTextView.setText(buildUserInfoDisplay(user));
    	            } else {
    	            	Toast.makeText(getActivity(), "Error: user is null", Toast.LENGTH_SHORT).show();
    	            	FacebookRequestError error = response.getError();
    	                if (error != null) {
    	                	Toast.makeText(getActivity(), "Error: "+error.getErrorMessage(), Toast.LENGTH_SHORT).show();
    	                     Log.d(String.format("Error: %s"), error.getErrorMessage());
    	                }
                    }
    	        }
    	    }).executeAsync();
    	    
    	} else if(state.isClosed()){
    		/*if(!isCancel){
    			isCancel = true;
	    		final Intent facebook_link = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.facebook.katana"));
	    		startActivity(facebook_link);
	    		Toast.makeText(getActivity(), "Facebook ���� ��ġ�Ǿ� �־�� �մϴ�.", Toast.LENGTH_SHORT).show();
    		}*/
	    	Log.i(TAG, "Logged out...");
    		userInfoTextView.setVisibility(View.INVISIBLE);
    	}
    	Log.d("?", ""+state.toString());
    }
	
	private Session.StatusCallback callback = new Session.StatusCallback() {
	    @Override
	    public void call(Session session, SessionState state, Exception exception) {
	        onSessionStateChange(session, state, exception);
	    }
	};
	
	private OnClickListener buttonClick = new OnClickListener() {
		@Override
		public void onClick(View v) {
			switch(v.getId()){
			/*case R.id.sign_in_button:
				pickUserAccount();
				
				if(!mGoogleApiClient.isConnecting()){
					mSignInClicked = true;
					resolveSignInError();
				}
				break;*/
			case R.id.authButton:
				isCancel = false;
				break;
			/*case R.id.sendRequest:
				if(myInfo != null){
					final String myId = myInfo.getId();
					final String myName = myInfo.getName();
					final String myBirth = myInfo.getBirthday();
					TelephonyManager tMgr = (TelephonyManager)getActivity().getSystemService(Context.TELEPHONY_SERVICE);
					final String myHP = tMgr.getLine1Number();
					
					Intent intent = new Intent(getActivity(), NewProductActivity.class);
					startActivity(intent);
				}
				break;*/
			}
		}
	};
	
	@Override
	public void onResume() {
	    super.onResume();
	 // For scenarios where the main activity is launched and user
	    // session is not null, the session state change notification
	    // may not be triggered. Trigger it if it's open/closed.
	    Session session = Session.getActiveSession();
	    if (session != null &&
	           (session.isOpened() || session.isClosed()) ) {
	        onSessionStateChange(session, session.getState(), null);
	    }

	    uiHelper.onResume();
	}

	/*@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
	    super.onActivityResult(requestCode, resultCode, data);
	    //uiHelper.onActivityResult(requestCode, resultCode, data);
	    
	    if (requestCode == REQUEST_CODE_PICK_ACCOUNT) {
	        // Receiving a result from the AccountPicker
	        if (resultCode == FragmentActivity.RESULT_OK) {
	        	 
	            mEmail = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
	            Toast.makeText(getActivity(), "Email : "+mEmail, Toast.LENGTH_SHORT).show();
	            
	            mGoogleApiClient = new GoogleApiClient.Builder(getActivity())
		        .addApi(Plus.API)
		        .addScope(Plus.SCOPE_PLUS_LOGIN)
		        .setAccountName(mEmail)
		        .build();
	            
	            if(!mGoogleApiClient.isConnected() && !mGoogleApiClient.isConnecting()){
	            	mGoogleApiClient.connect();
	            }
	            if(mGoogleApiClient.isConnecting()){
	            	Toast.makeText(getActivity(), "is Connecting!", Toast.LENGTH_SHORT).show();
	            }
	            if(mGoogleApiClient.isConnected()){
	            	Toast.makeText(getActivity(), "is Connected!", Toast.LENGTH_SHORT).show();
	            }
	            // With the account name acquired, go get the auth token
	            //getUsername();
	        } else if (resultCode == FragmentActivity.RESULT_CANCELED) {
	            // The account picker dialog closed without selecting an account.
	            // Notify users that they must pick an account to proceed.
	            Toast.makeText(getActivity(), "Pick Account", Toast.LENGTH_SHORT).show();
	        }
	    }
	    
	    if (requestCode == REQUEST_RESOLVE_ERROR) {
	        mResolvingError = false;
	        if (resultCode == FragmentActivity.RESULT_OK) {
	            // Make sure the app is not already connected or attempting to connect
	            if (!mGoogleApiClient.isConnecting() &&
	                    !mGoogleApiClient.isConnected()) {
	                mGoogleApiClient.connect();
	            }
	        }
	    }
	    
	    if (requestCode == RC_SIGN_IN) {
	        mResolvingError = false;
	        if (resultCode != FragmentActivity.RESULT_OK) {
	            mSignInClicked = false;
	          }

	          mIntentInProgress = false;

	          if (!mGoogleApiClient.isConnecting()) {
	            mGoogleApiClient.connect();
	          }
	    }
	}*/

	@Override
	public void onPause() {
	    super.onPause();
	    uiHelper.onPause();
	}

	@Override
	public void onDestroy() {
	    super.onDestroy();
	    uiHelper.onDestroy();
	}

	private static final String STATE_RESOLVING_ERROR = "resolving_error";
	
	@Override
	public void onSaveInstanceState(Bundle outState) {
	    super.onSaveInstanceState(outState);
	    uiHelper.onSaveInstanceState(outState);
	    //outState.putBoolean(STATE_RESOLVING_ERROR, mResolvingError);
	}
	
	private String buildUserInfoDisplay(GraphUser user) {
	    StringBuilder userInfo = new StringBuilder("");
	    myInfo = user;

	    // Example: typed access (name)
	    // - no special permissions required
	    userInfo.append(String.format("Name: %s\n\n", 
	        user.getName()));
	    
	    userInfo.append(String.format("Id: %s\n\n", user.getId()));

	    // Example: typed access (birthday)
	    // - requires user_birthday permission
	    userInfo.append(String.format("Birthday: %s\n\n", 
	        user.getBirthday()));

	    // Example: partially typed access, to location field,
	    // name key (location)
	    // - requires user_location permission
	    userInfo.append(String.format("Location: %s\n\n", 
	        user.getLocation().getProperty("name")));

	    // Example: access via property name (locale)
	    // - no special permissions required
	    userInfo.append(String.format("Locale: %s\n\n", 
	        user.getProperty("locale")));

	 // Get a list of languages from an interface that
	 // extends the GraphUser interface and that returns
	 // a GraphObject list of MyGraphLanguage objects.
	 GraphObjectList<MyGraphLanguage> languages = 
	     (user.cast(MyGraphUser.class)).getLanguages();
	 if (languages.size() > 0) {
	     ArrayList<String> languageNames = new ArrayList<String> ();
	     // Iterate through the list of languages
	     for (MyGraphLanguage language : languages) {
	         // Add the language name to a list. Use the name
	         // getter method to get access to the name field.
	         languageNames.add(language.getName());
	     }                     
	                             
	        userInfo.append(String.format("Languages: %s\n\n", 
	        languageNames.toString()));
	    }

	    return userInfo.toString();
	}
	
	// MyGraphUser(GraphObject)
	private interface MyGraphUser extends GraphUser {
	    // Create a setter to enable easy extraction of the languages field
	    GraphObjectList<MyGraphLanguage> getLanguages();
	}
	
	// MyGraphLanguage(GraphObject)
		private interface MyGraphLanguage extends GraphObject {
			// Getter for the ID field
		    String getId();
		    // Getter for the Name field
		    String getName();
		}
		
		@SuppressLint("HandlerLeak")
		class ResultHandler extends Handler{
			@Override
			public void handleMessage(Message msg){
			super.handleMessage(msg);
			
				switch(msg.what){
				case RECEIVE_RESULT:
					result.setText("RequestResult : "+mResult);
					break;
				}
			}
		}

		public void onStart() {
		    super.onStart();
		    Log.d("Check", "onStart");
		    /*Toast.makeText(getActivity(), "mResolvingError : "+mResolvingError, Toast.LENGTH_SHORT).show();
		    if (!mResolvingError) {  // more about this later
	            mGoogleApiClient.connect();
	        }*/
		}

		public void onStop() {
		    super.onStop();
		    /*if (mGoogleApiClient.isConnected()) {
		        Plus.AccountApi.clearDefaultAccount(mGoogleApiClient);
		        mGoogleApiClient.disconnect();
		        mGoogleApiClient.connect();
		      }*/
		}
		
		/*@Override
		public void onConnectionFailed(ConnectionResult connectionResult) {
			// TODO Auto-generated method stub
			if (mResolvingError) {
	            // Already attempting to resolve an error.
	            return;
	        } else if (connectionResult.hasResolution()) {
	            mResolvingError = true;
				//connectionResult.startResolutionForResult(getActivity(), REQUEST_RESOLVE_ERROR);
				mGoogleApiClient.connect();
				Log.d("onConnectionFailed", "After Connect "+mGoogleApiClient.isConnecting()+" "+mGoogleApiClient.isConnected());
				
	        } else {
	            // Show dialog using GooglePlayServicesUtil.getErrorDialog()
	            showErrorDialog(connectionResult.getErrorCode());
	            mResolvingError = true;
	        }
			
			if (!mIntentInProgress) {
			    // Store the ConnectionResult so that we can use it later when the user clicks
			    // 'sign-in'.
			    mConnectionResult = connectionResult;

			    if (mSignInClicked) {
			      // The user has already clicked 'sign-in' so we attempt to resolve all
			      // errors until the user is signed in, or they cancel.
			      resolveSignInError();
			    }
			 }
		}*/
		
		private void showErrorDialog(int errorCode) {
	        // Create a fragment for the error dialog
	        ErrorDialogFragment dialogFragment = new ErrorDialogFragment();
	        // Pass the error that should be displayed
	        Bundle args = new Bundle();
	        args.putInt(DIALOG_ERROR, errorCode);
	        dialogFragment.setArguments(args);
	        dialogFragment.show(getActivity().getSupportFragmentManager(), "errordialog");
	    }
		public void onDialogDismissed() {
	        mResolvingError = false;
	    }
		
		public static class ErrorDialogFragment extends DialogFragment {
	        public ErrorDialogFragment() { }

	        @Override
	        public Dialog onCreateDialog(Bundle savedInstanceState) {
	            // Get the error code and retrieve the appropriate dialog
	            int errorCode = this.getArguments().getInt(DIALOG_ERROR);
	            return GooglePlayServicesUtil.getErrorDialog(errorCode,
	                    this.getActivity(), REQUEST_RESOLVE_ERROR);
	        }

	        @Override
	        public void onDismiss(DialogInterface dialog) {
	            //((MainFragment) getActivity()).onDialogDismissed();
	        	mResolvingError = false;
	        }
	    }

		/*@Override
		public void onConnected(Bundle arg0) {
			// TODO Auto-generated method stub
			mSignInClicked = false;
			  Toast.makeText(getActivity(), "User is connected!", Toast.LENGTH_SHORT).show();
			  
			  if(Plus.PeopleApi.getCurrentPerson(mGoogleApiClient)!=null){
				  Person currentPerson = Plus.PeopleApi.getCurrentPerson(mGoogleApiClient);
				  String personName = currentPerson.getDisplayName();
				  String personId = currentPerson.getId();
				  String personBirth = currentPerson.getBirthday();
				  
				  Toast.makeText(getActivity(), "Name : "+personName+ENTER+
						  "Id : "+personId+ENTER+"Birth : "+personBirth, Toast.LENGTH_SHORT).show();
				  
				  App = (AdBalloon)getActivity().getApplication();
				  App.setGoogleUser(currentPerson);
				  
				  Intent intent = new Intent(getActivity(), MainMenu.class);
				  startActivity(intent);
				  getActivity().finish();
			  }
			  getActivity().finish();
		}*/

		/*@Override
		public void onConnectionSuspended(int arg0) {
			// TODO Auto-generated method stub
			Log.d("Check", "onConnectionSuspended");
			mGoogleApiClient.connect();
		}*/
		
		static final int REQUEST_CODE_PICK_ACCOUNT = 1000;

		private void pickUserAccount() {
		    String[] accountTypes = new String[]{"com.google"};
		    Intent intent = AccountPicker.newChooseAccountIntent(null, null,
		            accountTypes, false, null, null, null, null);
		    startActivityForResult(intent, REQUEST_CODE_PICK_ACCOUNT);
		}
		
		private void resolveSignInError() {
			  if (mConnectionResult != null && mConnectionResult.hasResolution()) {
			    try {
			      mIntentInProgress = true;
			      //startIntentSenderForResult(mConnectionResult.getIntentSender(),
			      //    RC_SIGN_IN, null, 0, 0, 0);
			      mConnectionResult.startResolutionForResult(getActivity(), RC_SIGN_IN);
			    } catch (SendIntentException e) {
			      // The intent was canceled before it was sent.  Return to the default
			      // state and attempt to connect to get an updated ConnectionResult.
			      mIntentInProgress = false;
			      mGoogleApiClient.connect();
			    }
			}
		}
}