package kbssm.hightech.adballoon;

import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;

public class CheckPackage {
	
	public CheckPackage(){
		
	}
	
	protected boolean checkGooglePlus(Context context){
		final PackageManager pm = context.getPackageManager();
		List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_META_DATA);
		Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=com.google.android.apps.plus"));
		for(ApplicationInfo packageInfo : packages){
			if("com.google.android.apps.plus".equals(packageInfo.packageName)){
				return true;
			}
		}
		return false;
	}
	
	protected boolean checkFacebook(Context context){
		final PackageManager pm = context.getPackageManager();
		List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_META_DATA);
		Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=com.facebook.katana"));
		for(ApplicationInfo packageInfo : packages){
			if("com.facebook.katana".equals(packageInfo.packageName)){
				return true;
			}
		}
		return false;
	}
}