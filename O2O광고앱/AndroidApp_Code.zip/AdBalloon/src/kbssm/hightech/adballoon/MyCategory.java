package kbssm.hightech.adballoon;

import java.lang.reflect.Array;
import java.util.ArrayList;

import com.google.android.gcm.GCMRegistrar;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MyCategory extends Fragment {
	
	private AdBalloon App;
	
	private MyCustomAdapter dataAdapter = null;
	private HelpDialog help;
	
	private View v; 
	
	protected static final int[] CODE_LIST = 
		 {21, 23, 25, 26, 24, 22, 21};
	 
	 @Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
			View v = inflater.inflate(R.layout.my_category, container, false);
			this.v = v;
			
			App = (AdBalloon)getActivity().getApplication();
			
			Button startService = (Button)v.findViewById(R.id.start_service);
			startService.setOnClickListener(buttonClick);
			Button helpDialog = (Button)v.findViewById(R.id.btn_help);
			helpDialog.setOnClickListener(buttonClick);
			
			
			
			//Generate list View from ArrayList
			  displayListView();
			
			Bundle args = getArguments();
			
			return v;
		}
	 
	 @Override
	 public void onCreate(Bundle savedInstanceState) {
	  super.onCreate(savedInstanceState);
	  //setContentView(R.layout.my_category);
	 
	  GCMRegistrar.checkDevice(getActivity());
      GCMRegistrar.checkManifest(getActivity());
      final String regId = GCMRegistrar.getRegistrationId(getActivity());
      if("".equals(regId))
      	GCMRegistrar.register(getActivity(),  "952870349256");
      else
      	Log.d("=====", regId);
	 
	  //checkButtonClick();
	 
	 }
	 
	 private void displayListView() {
	 
	  //Array list of countries
	  ArrayList<Category> categoryList = new ArrayList<Category>();
	  MainCategory.addCategoryList(categoryList);
	 
	  //create an ArrayAdaptar from the String Array
	  dataAdapter = new MyCustomAdapter(getActivity(),
	    R.layout.category_info, categoryList);
	  ListView listView = (ListView) v.findViewById(R.id.listView1);
	  // Assign adapter to ListView
	  listView.setAdapter(dataAdapter);
	 
	 
	  listView.setOnItemClickListener(new OnItemClickListener() {
	   public void onItemClick(AdapterView<?> parent, View view,
	     int position, long id) {
	    // When clicked, show a toast with the TextView text
	    Category category = (Category) parent.getItemAtPosition(position);
	    /*Toast.makeText(getActivity(),
	      "Clicked on Row: " + category.getCode(), 
	      Toast.LENGTH_SHORT).show();*/
	    
	    // HTTP
	    HttpSupport http = new HttpSupport();
	    App = (AdBalloon)getActivity().getApplication();
	    ArrayList<String> response = http.sendCategory(getActivity(), http.SERVER_URL+"brandsend_control.jsp", App.getCustomerId(), String.valueOf(CODE_LIST[position])/*category.getCode()*/);
	    //App.setSubList(response);
	    //http.sendTest(getActivity());
	    //Toast.makeText(getActivity(), response + "?", Toast.LENGTH_SHORT).show();
	    
	    ArrayList<String> name = new ArrayList<String>();
	    ArrayList<String> code = new ArrayList<String>();
	    ArrayList<String> check = new ArrayList<String>();
	    
	    for(int i=0;i<response.size();i++){
	    	switch(i%3){
	    	case 0:
	    		name.add(response.get(i));
	    		break;
	    	case 1:
	    		code.add(response.get(i));
	    		break;
	    	case 2:
	    		check.add(response.get(i));
	    		break;
	    	}
	    }
	    App = (AdBalloon)getActivity().getApplication();
	    MySubCategory dialog = new MySubCategory(getActivity(), code, name, check, App.getCustomerId());
	    dialog.show();
	   }
	  });
	 }
	 
	 protected OnClickListener buttonClick = new OnClickListener() {
		@Override
		public void onClick(View v) {
			switch(v.getId()){
			case R.id.start_service:
				Intent intent = new Intent(getActivity(), StartService.class);
				startActivity(intent);
				break;
			case R.id.btn_help:
				final String title = "�����׸� ����";
				final String content = "�з� �� �����׸��� �����س����� ���ϴ� ������ ������ ������ �� �ֽ��ϴ�.";
				help = new HelpDialog(getActivity(), title, content, closeListener);
				help.show();
				break;
			}
		}
	};
	 
	private View.OnClickListener closeListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			help.dismiss();
		}
	};
	
	 private class MyCustomAdapter extends ArrayAdapter<Category> {
	 
	  private ArrayList<Category> categoryList;
	 
	  public MyCustomAdapter(Context context, int textViewResourceId, 
	    ArrayList<Category> categoryList) {
	   super(context, textViewResourceId, categoryList);
	   this.categoryList = new ArrayList<Category>();
	   this.categoryList.addAll(categoryList);
	  }
	 
	  private class ViewHolder {
	   TextView code;
	   CheckBox name;
	  }
	 
	  @Override
	  public View getView(int position, View convertView, ViewGroup parent) {
	 
	   ViewHolder holder = null;
	   Log.v("ConvertView", String.valueOf(position));
	 
	   if (convertView == null) {
	   LayoutInflater vi = (LayoutInflater)getActivity().getSystemService(
	     Context.LAYOUT_INFLATER_SERVICE);
	   convertView = vi.inflate(R.layout.category_info, null);
	 
	   holder = new ViewHolder();
	   holder.code = (TextView) convertView.findViewById(R.id.code);
	   //holder.name = (CheckBox) convertView.findViewById(R.id.checkBox1);
	   convertView.setTag(holder);
	 
	   
	    /*holder.name.setOnClickListener( new View.OnClickListener() {  
	     public void onClick(View v) {  
	      CheckBox cb = (CheckBox) v ;  
	      Category category = (Category) cb.getTag();  
	      Toast.makeText(getApplicationContext(),
	       "Clicked on Checkbox: " + cb.getText() +
	       " is " + cb.isChecked(), 
	       Toast.LENGTH_LONG).show();
	      category.setSelected(cb.isChecked());
	     }  
	    });  */
	   } 
	   else {
	    holder = (ViewHolder) convertView.getTag();
	   }
	 
	   Category category = categoryList.get(position);
	   holder.code.setText(category.getCode());
	   /*holder.name.setText(category.getSub());
	   holder.name.setChecked(category.isSelected());
	   holder.name.setTag(category);*/
	 
	   return convertView;
	 
	  }
	 
	 }

	 private static class MainCategory{
		 protected static final String MAIN = "MAINCATEGORY";
		 protected static final String CAFE = "����";
		 protected static final String THEATER = "��ȭ��";
		 protected static final String CONVENIENCE = "������";
		 protected static final String RESTAURANT = "�йи��������";
		 protected static final String COSMETIC = "�ڽ���ƽ";
		 protected static final String FASTFOOD = "�н�ƮǪ��";
		 protected static final String ETC = "ETC";
		 
		 protected static final String[] CategoryList = 
			 {CAFE, THEATER, CONVENIENCE, RESTAURANT, COSMETIC, FASTFOOD, ETC};
		 
		 protected static void addCategoryList(ArrayList<Category> categoryList){
			 if(categoryList != null){
				 for(int i=0;i<CategoryList.length;i++){
					 categoryList.add(new Category(CategoryList[i], MainCategory.MAIN, false));
				 }
			 }
		 }
	 }
	 
	 private static class Cafe{
		 protected static final String CAFE = "CAFE";
		 protected static final String STARBUCKS = "STARBUCKS COFFEE";
		 protected static final String TOMNTOMS = "TOM N TOMS COFFEE";
		 protected static final String HOLLYS = "HOLLYS COFFEE";
		 protected static final String CAFFEBENE = "Caffebene";
		 protected static final String ANGELINUS = "Angel in-us Coffee";
		 protected static final String EDIYA = "EDIYA COFFEE";
		 protected static final String PASCUCCI = "CAFFE PASCUCCI";
		 protected static final String TWOSOMEPLACE = "A TWOSOME PLACE";
		 protected static final String TIAMO = "caffe Ti-amo";
		 protected static final String COFFEEBEAN = "The Coffee Bean";
		 protected static final String COFFINEGURUNARU = "COFFINE GURUNARU";
		 protected static final String ETC = "ETC";
		 
		 protected static final String[] CafeList = 
			 {STARBUCKS, TOMNTOMS, HOLLYS, CAFFEBENE, ANGELINUS, EDIYA, PASCUCCI, TWOSOMEPLACE, TIAMO, COFFEEBEAN, COFFINEGURUNARU, ETC};
		 
		 protected static void addCafeList(ArrayList<Category> categoryList){
			 if(categoryList != null){
				 for(int i=0;i<CafeList.length;i++){
					 categoryList.add(new Category(Cafe.CAFE, CafeList[i], false));
				 }
			 }
		 }
	 }
	}