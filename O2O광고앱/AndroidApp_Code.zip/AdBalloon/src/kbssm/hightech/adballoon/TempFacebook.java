package kbssm.hightech.adballoon;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.acl.Permission;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.facebook.AppEventsLogger;
import com.facebook.FacebookException;
import com.facebook.FacebookOperationCanceledException;
import com.facebook.Request;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionDefaultAudience;
import com.facebook.SessionLoginBehavior;
import com.facebook.SessionState;
import com.facebook.SharedPreferencesTokenCachingStrategy;
import com.facebook.UiLifecycleHelper;
import com.facebook.model.GraphUser;
import com.facebook.widget.FacebookDialog;
import com.facebook.widget.LoginButton;
import com.facebook.widget.WebDialog;
import com.facebook.widget.WebDialog.OnCompleteListener;

public class TempFacebook extends FragmentActivity{
	
	private AdBalloon App;

	private UiLifecycleHelper uiHelper;
	private Session mSession;
	private List<String> mPermissions;
	
	private GraphUser user;
	private LoginButton facebookLogin;
	
	private String extra = "";
	private boolean isClicked = false;

    private Session.StatusCallback callback = new Session.StatusCallback() {
        @Override
        public void call(Session session, SessionState state, Exception exception) {
        	if(exception != null){
        		exception.printStackTrace();
        	}
            onSessionStateChange(session, state, exception);
        }
    };

    private FacebookDialog.Callback dialogCallback = new FacebookDialog.Callback() {
        @Override
        public void onError(FacebookDialog.PendingCall pendingCall, Exception error, Bundle data) {
            Log.d("Ad Balloon", String.format("Error: %s", error.toString()));
        }

        @Override
        public void onComplete(FacebookDialog.PendingCall pendingCall, Bundle data) {
            Log.d("Ad Balloon", "Success!");
        }
    };
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		/*if(savedInstanceState == null){
			mainFragment = new MainFragment();
			getSupportFragmentManager().beginTransaction().
			add(android.R.id.content, mainFragment).commit();
		} else {
			mainFragment = (MainFragment)getSupportFragmentManager().
					findFragmentById(android.R.id.content);
		}*/
		
		/*mSession = new Session.Builder(this).setTokenCachingStrategy(new SharedPreferencesTokenCachingStrategy(this)).build();
		Session.OpenRequest openRequest = new Session.OpenRequest(this);
		openRequest.setLoginBehavior(SessionLoginBehavior.SUPPRESS_SSO);
		openRequest.setRequestCode(Session.DEFAULT_AUTHORIZE_ACTIVITY_CODE);
		mSession.openForRead(openRequest); 
		
		mPermissions = Arrays.asList("publish_actions", "user_videos", "read_stream", "share_item");*/

		
    	Intent intentInfo = getIntent();
    	extra = intentInfo.getStringExtra("Where");
		
		try {
            PackageInfo info = getPackageManager().getPackageInfo(
                    "kbssm.hightech.adballoon", 
                    PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.d("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT));
                }
        } catch (NameNotFoundException e) {

        } catch (NoSuchAlgorithmException e) {

        }
		
		uiHelper = new UiLifecycleHelper(this, callback);
        uiHelper.onCreate(savedInstanceState);
		
		setContentView(R.layout.facebook_loading);
		
		facebookLogin = (LoginButton)findViewById(R.id.facebook_login);
		//facebookLogin.setLoginBehavior(SessionLoginBehavior.SUPPRESS_SSO);
		Button googlePlusLogin = (Button)findViewById(R.id.googleplus_login);
		
		Button facebookLogin2 = (Button)findViewById(R.id.facebook_login2);
		facebookLogin.setUserInfoChangedCallback(new LoginButton.UserInfoChangedCallback() {
            @Override
            public void onUserInfoFetched(GraphUser user) {
                TempFacebook.this.user = user;
                //updateUI();
                Log.d("setUserInfoChanged", "user : "+user);
                if(user == null){
                	if(!isClicked){
	                	facebookLogin.performClick();
	            		Log.d("FacebookLogin", "pressed");
	            		isClicked = true;
                	}
                	/*PackageManager pm = getPackageManager();
                	PackageInfo pi;
                	try {
						pi = pm.getPackageInfo("com.facebook.katana", PackageManager.GET_ACTIVITIES);
					} catch (NameNotFoundException e) {
						e.printStackTrace();
						final Intent facebook_link = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.facebook.katana"));
	            		startActivity(facebook_link);
	            		Toast.makeText(getApplicationContext(), "Facebook ���� ��ġ�Ǿ� �־�� �մϴ�.", Toast.LENGTH_SHORT).show();
					}*/

                	Log.d("setUserInfoChanged", "null");
                } else if(user != null){
                	Log.d("setUserInfoChanged", "Name : "+user.getName());
                	App = (AdBalloon)getApplication();
                	App.setFacebookUser(user);
                	
                	
                	
                	if(extra != null && extra.equals("MyInfo")){
                		finish();
                	} else {
                		HttpSupport http = new HttpSupport();
                		String id = http.loginConnect(getApplicationContext(), "http://112.108.40.157:8080/MiniProject/android_customer_login_control.jsp", user, null);
                		//Toast.makeText(getApplicationContext(), "id : "+id, Toast.LENGTH_SHORT).show();
                		App = (AdBalloon)getApplication();
                		App.setCustomerId(id);
        				/*String id = http.selectData(getApplicationContext(), "http://112.108.40.157:8080/MiniProject/android_customer_login_control.jsp", user.getId());

        					Toast.makeText(getApplicationContext(), "id : "+id, Toast.LENGTH_SHORT).show();*/
                		
                		Intent intent = new Intent(getApplicationContext(), SwipeActivity.class);
                    	startActivity(intent);
                    	
                    	finish();
                	}
                }
                // It's possible that we were waiting for this.user to be populated in order to post a
                // status update.
                //handlePendingAction();
            }
        });
		
	}
	
	@Override
    protected void onResume() {
        super.onResume();
        uiHelper.onResume();

        // Call the 'activateApp' method to log an app event for use in analytics and advertising reporting.  Do so in
        // the onResume methods of the primary Activities that an app may be launched into.
        AppEventsLogger.activateApp(this);

        //updateUI();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        uiHelper.onSaveInstanceState(outState);

        //outState.putString(PENDING_ACTION_BUNDLE_KEY, pendingAction.name());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        uiHelper.onActivityResult(requestCode, resultCode, data, dialogCallback);
        Session.getActiveSession().onActivityResult(this, requestCode, resultCode, data);
    }

    @Override
    public void onPause() {
        super.onPause();
        uiHelper.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        uiHelper.onDestroy();
    }

    private void onSessionStateChange(Session session, SessionState state, Exception exception) {
        /*if (pendingAction != PendingAction.NONE &&
                (exception instanceof FacebookOperationCanceledException ||
                exception instanceof FacebookAuthorizationException)) {
                new AlertDialog.Builder(HelloFacebookSampleActivity.this)
                    .setTitle(R.string.cancelled)
                    .setMessage(R.string.permission_not_granted)
                    .setPositiveButton(R.string.ok, null)
                    .show();
            pendingAction = PendingAction.NONE;
        } else if (state == SessionState.OPENED_TOKEN_UPDATED) {
            handlePendingAction();
        }
        updateUI();*/

    	if(session.isOpened()){
    		Log.d("onSessionStateChange", "Session is Opened");
    		//Log.d("onSessionState", "1");
    		//Toast.makeText(getApplicationContext(), "Name : "+user.getName(), Toast.LENGTH_SHORT).show();
    	} else if(session.isClosed()){
    		Log.d("onSessionStateChange", "Session is Closed");
    		/*Intent intent = new Intent(getApplicationContext(), MainMenu.class);
    		startActivity(intent);*/
            
    		Toast.makeText(getApplicationContext(), "Login Failed", Toast.LENGTH_SHORT).show();
    		finish();
    	} else if(session.getApplicationId() == null){
    		final Intent facebook_link = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.facebook.katana"));
    		startActivity(facebook_link);
    		Toast.makeText(getApplicationContext(), "Facebook ���� ��ġ�Ǿ� �־�� �մϴ�.", Toast.LENGTH_SHORT).show();
    	}
    }
}