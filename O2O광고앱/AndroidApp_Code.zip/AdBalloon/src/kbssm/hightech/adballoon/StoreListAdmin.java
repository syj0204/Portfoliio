package kbssm.hightech.adballoon;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class StoreListAdmin extends Activity{
	
	private MyCustomAdapter dataAdapter = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.store_list_admin);
		
		displayListView();
	}
	
	private void displayListView() {
		 
		  //Array list of countries
		  ArrayList<StoreInfo> storeList = new ArrayList<StoreInfo>();
		  MyStore.addStoreList(storeList);
		 
		  //create an ArrayAdaptar from the String Array
		  dataAdapter = new MyCustomAdapter(this,
		    R.layout.store_info, storeList);
		  ListView listView = (ListView) findViewById(R.id.listView1);
		  // Assign adapter to ListView
		  listView.setAdapter(dataAdapter);
		 
		  listView.setOnItemClickListener(new OnItemClickListener() {
		   public void onItemClick(AdapterView<?> parent, View view,
		     int position, long id) {
		    // When clicked, show a toast with the TextView text
		    StoreInfo storeInfo = (StoreInfo) parent.getItemAtPosition(position);
		    Toast.makeText(getApplicationContext(),
		      "Clicked on Row: " + storeInfo.getName(), 
		      Toast.LENGTH_SHORT).show();
		    
		    if(storeInfo.getCode().equals("1000")){
		    	Intent storePage = new Intent(getApplicationContext(), Store.class);
		    	startActivity(storePage);
		    }
		    
		    /*MySubCategory dialog = new MySubCategory(MyCategory.this, category.getCategory());
			dialog.show();*/
		   }
		  });
	 }
	
	private class MyCustomAdapter extends ArrayAdapter<StoreInfo> {
		 
		  private ArrayList<StoreInfo> storeList;
		 
		  public MyCustomAdapter(Context context, int textViewResourceId, 
		    ArrayList<StoreInfo> storeList) {
		   super(context, textViewResourceId, storeList);
		   this.storeList = new ArrayList<StoreInfo>();
		   this.storeList.addAll(storeList);
		  }
		 
		  private class ViewHolder {
		   TextView name;
		  }
		 
		  @Override
		  public View getView(int position, View convertView, ViewGroup parent) {
		 
			   ViewHolder holder = null;
			   Log.v("ConvertView", String.valueOf(position));
			 
			   if (convertView == null) {
				   LayoutInflater vi = (LayoutInflater)getSystemService(
				     Context.LAYOUT_INFLATER_SERVICE);
				   convertView = vi.inflate(R.layout.store_info, null);
				 
				   holder = new ViewHolder();
				   holder.name = (TextView) convertView.findViewById(R.id.name);
				   //holder.name = (CheckBox) convertView.findViewById(R.id.checkBox1);
				   convertView.setTag(holder);
			   } else {
				   holder = (ViewHolder) convertView.getTag();
			   }
		 
			   StoreInfo storeInfo = storeList.get(position);
			   holder.name.setText(storeInfo.getName()+" (" +  storeInfo.getCode() + ")");
			   /*holder.name.setText(category.getSub());
			   holder.name.setChecked(category.isSelected());
			   holder.name.setTag(category);*/
		 
			   return convertView;
		 
		  }
	 }
	
	private static class MyStore{
		 protected static final String STORE1 = "Store1";
		 protected static final String STORE2 = "Store2";
		 protected static final String STORE3 = "Store3";
		 protected static final String STORE4 = "Store4";
		 protected static final String STORE5 = "Store5";
		 
		 protected static final String[] StoreList = 
			 {STORE1, STORE2, STORE3, STORE4, STORE5};
		 
		 protected static void addStoreList(ArrayList<StoreInfo> storeList){
			 if(storeList != null){
				 for(int i=0;i<StoreList.length;i++){
					 storeList.add(new StoreInfo(StoreList[i], "1000"));
				 }
			 }
		 }
	 }
}