package kbssm.hightech.adballoon;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import android.graphics.drawable.Drawable;

public class Evaluation {
	  
	 private String name = null;
	 private float rating = 0.0f;
	 private String content = null;
	 private String imageUrl = null;
	  
	 public Evaluation(String name, float rating, String content, String imageUrl) {
		 super();
		 this.name = name;
		 this.rating = rating;
		 this.content = content;
		 this.imageUrl = imageUrl;
	 }
	  
	 public String getName() {
		 return name;
	 }
	 public void setName(String name) {
		 this.name = name;
	 }
	 
	 public float getRating() {
		 return rating;
	 }
	 public void setRating(float rating) {
		 this.rating = rating;
	 }
	 
	 public String getContent() {
		 return content;
	 }
	 public void setConent(String content) {
		 this.content = content;
	 }
	 
	 public Drawable getImage() {
		 URL imageUrl;
		 if(this.imageUrl != null){
			try {
				imageUrl = new URL(this.imageUrl);
				InputStream is = (InputStream) imageUrl.getContent();
				Drawable image = Drawable.createFromStream(is, "src");
				return image;
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}
		 } else {
			 return null;
		 }
	 }
	 public void setImageUrl(String imageUrl) {
		 this.imageUrl = imageUrl;
	 }
}