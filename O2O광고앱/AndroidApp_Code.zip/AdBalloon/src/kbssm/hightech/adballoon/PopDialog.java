package kbssm.hightech.adballoon;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

 
public class PopDialog extends Dialog{
	
	private AdBalloon App;
	
    @Override
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         
        WindowManager.LayoutParams lpWindow = new WindowManager.LayoutParams();    
        lpWindow.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        lpWindow.dimAmount = 0.8f;
        getWindow().setAttributes(lpWindow);
         
        setContentView(R.layout.popdialog);
         
        setLayout();
        this.mTitleView.setText(mTitle);
        this.mContentView.setText(mContent);
        //setContent(mContent);
        setClickListener(mLeftClickListener , mRightClickListener);
    }
     
    public PopDialog(Context context) {
        // Dialog ����� ���� ó�� ���ش�.
        super(context , android.R.style.Theme_Translucent_NoTitleBar);
    }
     
    public PopDialog(Context context , String title , 
            View.OnClickListener singleListener) {
        super(context , android.R.style.Theme_Translucent_NoTitleBar);
        this.mTitle = title;
        this.mLeftClickListener = singleListener;
    }
     
    public PopDialog(Context context , String title , String content , 
            View.OnClickListener leftListener , View.OnClickListener rightListener, AdBalloon App) {
        super(context , android.R.style.Theme_Translucent_NoTitleBar);
        this.mTitle = title;
        this.mContent = content;
        this.mLeftClickListener = leftListener;
        this.mRightClickListener = rightListener;
        this.App = App;
    }
    
    @Override
    public void onBackPressed() {
    	// TODO Auto-generated method stub
    	super.onBackPressed();
    	if(App.getPop() != null)
    		App.setPop(null);
    }
    /* 
    private void setTitle(String title){
        mTitleView.setText(title);
    }
     
    private void setContent(String content){
        mContentView.setText(content);
    }
    */
    
    private void setClickListener(View.OnClickListener left , View.OnClickListener right){
        if(left!=null && right!=null){
            mLeftButton.setOnClickListener(left);
            mRightButton.setOnClickListener(right);
        }else if(left!=null && right==null){
            mLeftButton.setOnClickListener(left);
        }else {
             
        }
    }
     
    private TextView mTitleView;
    private TextView mContentView;
    //private ImageView mImageView;
    private Button mLeftButton;
    private Button mRightButton;
    private String mTitle;
    private String mContent;
     
    private View.OnClickListener mLeftClickListener;
    private View.OnClickListener mRightClickListener;
     
    /*
     * Layout
     */
    private void setLayout(){
        mTitleView = (TextView) findViewById(R.id.popup_title);
        mContentView = (TextView) findViewById(R.id.popup_content);
    	//mImageView = (ImageView) findViewById(R.id.popup_img);
        mLeftButton = (Button) findViewById(R.id.connect_bnt);
        mRightButton = (Button) findViewById(R.id.close_bnt);
    }
     
}