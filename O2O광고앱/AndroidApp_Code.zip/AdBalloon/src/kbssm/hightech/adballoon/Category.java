package kbssm.hightech.adballoon;

public class Category {
	  
	 String code = null;
	 String subcategory = null;
	 boolean selected = false;
	  
	 public Category(String code, String subcategory, boolean selected) {
	  super();
	  this.code = code;
	  this.subcategory = subcategory;
	  this.selected = selected;
	 }
	  
	 public String getCode() {
	  return code;
	 }
	 public void setCode(String code) {
	  this.code = code;
	 }
	 public String getSub() {
	  return subcategory;
	 }
	 public void setSub(String subcategory) {
	  this.subcategory = subcategory;
	 }
	 
	 public boolean isSelected() {
	  return selected;
	 }
	 public void setSelected(boolean selected) {
	  this.selected = selected;
	 }
	  
	}