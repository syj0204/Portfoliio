package kbssm.hightech.adballoon;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;

public class MyFavorite extends Fragment {
	
	private AdBalloon App;
	
	private View v;
	private HelpDialog help;
	
	 @Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
			View v = inflater.inflate(R.layout.my_favorite, container, false);
			this.v = v;
			
			App = (AdBalloon)getActivity().getApplication();
			Button helpDialog = (Button)v.findViewById(R.id.btn_help);
			helpDialog.setOnClickListener(buttonClick);
			
			Bundle args = getArguments();
			
			return v;
		}
	
	 private OnClickListener buttonClick = new OnClickListener() {
		@Override
		public void onClick(View v) {
			switch(v.getId()){
			case R.id.btn_help:
				final String title = "���ã�� ����";
				final String content = "������ ���ã��� �����ϸ� �ش� ���忡 ���� ���� ��𼭵� ������ ������ �� �ֽ��ϴ�.";
				help = new HelpDialog(getActivity(), title, content, closeListener);
				help.show();
			}
		}
	};
	
	private View.OnClickListener closeListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			help.dismiss();
		}
	};
	 
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		//setContentView(R.layout.my_favorite);
	}
}