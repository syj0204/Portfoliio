package kbssm.hightech.adballoon;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class StartService extends Activity{
	
	private AdBalloon App;
	
	private static final int SCAN = 0;
	private static final int STOP = 1;
	private static final int LIST_ENABLE = 10;
	private static final int LIST_DISABLE = 11;
	private int instruction = SCAN;
	private int selectedPosition = -1;
	
	private MyThread mMyThread;
	
	/** called when the activity is first created/ */
	private ListView maclist;
	
	//private ArrayList<String> Mac_Address = new ArrayList<String>();
	//private ArrayList<String> AP_Name = new ArrayList<String>();
	//private ArrayList<String> Store_Name = new ArrayList<String>();
	private ArrayList<String> Event = new ArrayList<String>();
	private ArrayList<String> maclist_contents = new ArrayList<String>();
	
	private ArrayList<AdInfo> adList = new ArrayList<AdInfo>();
	
	public PopDialog mCustomDialog;
	private Loading openLoading;

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_manager);
		
		Log.d("test","0");
		maclist = (ListView)findViewById(R.id.maclist);
		/*getCurrentMacAddress();
		maclist.setAdapter(new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1,maclist_contents));*/
		maclist.setOnItemClickListener(listener);
		/*
		Button button = (Button)findViewById(R.id.btn);
		button.setOnClickListener(buttonClick);
		*/
		
		//mHandler.sendEmptyMessage(instruction);
		/*TimerTask scanTask = new TimerTask(){
			public void run(){
				Toast.makeText(getApplicationContext(), "SCAN", Toast.LENGTH_SHORT).show();
			}
		};
		Timer timer = new Timer();
		timer.schedule(scanTask, 100, 5000);*/
		mMyThread = (MyThread)new MyThread().execute((Void)null);
	}
	Handler mHandler = new Handler(){
		public void handleMessage(Message msg){
			if(msg.what == SCAN){
				mMyThread = (MyThread)new MyThread().execute((Void)null);
				Log.d("HAndler", "handleMessage");
			} else if(msg.what == LIST_ENABLE){
				maclist.setEnabled(true);
				openLoading.dismiss();
			} else if(msg.what == LIST_DISABLE){
				maclist.setEnabled(false);
				openLoading = new Loading(StartService.this);
				openLoading.show();
			}
		}
	};

	/*private class TimerHandler extends Handler{
		@Override
		public void handleMessage(Message msg){
			super.handleMessage(msg);
			switch(msg.what){
			case SCAN:
				Toast.makeText(getApplicationContext(), "SCAN", Toast.LENGTH_SHORT).show();
				timerHandler.sendEmptyMessageAtTime(SCAN, 3000);
				break;
			}
		}
	}*/
	
	@Override
	protected void onResume() {
		super.onResume();
		mMyThread = (MyThread)new MyThread().execute((Void)null);
		Log.d("onResume", "resume");
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		instruction = STOP;
		if(mMyThread!=null)
			mMyThread.cancel(true);
		Log.d("onPause", "pause");
	}
	
	@Override
	protected void onStop() {
		super.onStop();
		instruction = STOP;
		if(mMyThread!=null)
		mMyThread.cancel(true);
		Log.d("onStop", "stop");
	}
	
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
		instruction = STOP;
	}
	
	public void getCurrentMacAddress(){
		
		mHandler.sendEmptyMessage(LIST_DISABLE);
		
		Event.clear();
		maclist_contents.clear();
		adList.clear();
		
		instruction = SCAN;
		
		WifiManager wifiManager = (WifiManager)getSystemService(Context.WIFI_SERVICE);
		wifiManager.startScan();
		List<ScanResult> sr = wifiManager.getScanResults();
		Log.d("isEmpty?", ""+sr.isEmpty());
		
		if(sr.isEmpty()){
			maclist_contents.clear();
			wifiManager.setWifiEnabled(true);
			wifiManager.startScan();
			sr = wifiManager.getScanResults();
			HttpSupport http = new HttpSupport();
			App = (AdBalloon)getApplication();
			ArrayList<String> ad = new ArrayList<String>();
			for(ScanResult r:sr){
				ad = http.sendMacAddress(getApplicationContext(), http.SERVER_URL+"adsend_control.jsp", App.getCustomerId(), r.BSSID);
				adList.add(new AdInfo(ad.get(0)+" - "+ad.get(1), ad.get(2), ad.get(3)));
				maclist_contents.add("["+ad.get(0)+" - "+ad.get(1)+"]" + "\n - " + ad.get(2));
			}
		} else {
			maclist_contents.clear();
			//Toast.makeText(getApplicationContext(), "Content : "+sr.toString(), Toast.LENGTH_SHORT).show();
			HttpSupport http = new HttpSupport();
			App = (AdBalloon)getApplication();
			ArrayList<String> ad = new ArrayList<String>();
			for(ScanResult r:sr){
				ad = http.sendMacAddress(getApplicationContext(), http.SERVER_URL+"adsend_control.jsp", App.getCustomerId(), r.BSSID);
				if(ad != null && ad.size() != 0){
					if(!ad.get(0).equals("false")){
						adList.add(new AdInfo(ad.get(0)+" - "+ad.get(1), ad.get(2), ad.get(3)));
						maclist_contents.add("["+ad.get(0)+" - "+ad.get(1)+"]" + "\n - " + ad.get(2));
					}
				}
			}
		}
		
		mHandler.sendEmptyMessage(LIST_ENABLE);
		//int string_counter = 0;
		//int string_counter1 = 0;
		/*for(ScanResult r:sr)
		{
			Mac_Address.add(r.BSSID);
			AP_Name.add("["+r.SSID+"]"+ r.BSSID);
			
			if(r.BSSID.equalsIgnoreCase("00:26:66:c4:d6:dc"))
			{
				Store_Name.add("[����ŷ]");
				Event.add("(2/17~2/21)LOVE PACK");
				adList.add(new AdInfo("����ŷ", "(2/17 ~ 2/21) LOVE PACK", adList.size()));
				maclist_contents.add("[����ŷ]"+"(2/17~2/21)LOVE PACK");
				
			}

			else
			{
				if(!r.SSID.isEmpty()){
					maclist_contents.add(r.SSID+" - "+r.BSSID);
					Store_Name.add(r.SSID);
				}
			}
		}*/
		
		/*maclist.setAdapter(new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1,maclist_contents));*/
	}
	
	//Adapterview
	AdapterView.OnItemClickListener listener =
			new AdapterView.OnItemClickListener()
			{
				public void onItemClick(AdapterView<?> list, View view, int position, long id) {
					 //if(Mac_Address.get(position).equalsIgnoreCase("00:26:66:c4:d6:dc")){
						 //Show(view);	view ����
						 Toast.makeText(getApplicationContext(), maclist_contents.get(position), Toast.LENGTH_SHORT).show();
						 Log.d("onItemClick", "Dialog Create");
						 App = (AdBalloon)getApplication();
						 if(App.getPop() == null)
							 mCustomDialog = null;
						 if(mCustomDialog == null){
							 selectedPosition = position;
						 mCustomDialog = new PopDialog(StartService.this, 
				                    adList.get(position).getStoreName(),
				                    adList.get(position).getAdTitle(),
				                    leftClickListener, 
				                    rightClickListener, App);
				            mCustomDialog.show();
				            App.setPop(mCustomDialog);
						 }
					//}
					
					//String s = "KBSSM";
					//Toast.makeText(ManagerActivity.this,s,Toast.LENGTH_SHORT).show();
				}
			};
			
	private View.OnClickListener leftClickListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			//Intent Start_store_class = new Intent(StartService.this, Store.class);
			//startActivity(Start_store_class);
			Intent startAd = new Intent(getApplicationContext(), Ad.class);
			startAd.putExtra("AD_CODE", adList.get(selectedPosition).getCode());
			//Toast.makeText(getApplicationContext(), adList.get(selectedPosition).getCode(), Toast.LENGTH_SHORT).show();
			startActivity(startAd);
		}
	};
	
	private View.OnClickListener rightClickListener = new View.OnClickListener() {
	    @Override
	    public void onClick(View v) {
	    	selectedPosition = -1;
	    	mCustomDialog.dismiss();
	    	getCurrentMacAddress();
	    	mCustomDialog = null;
		}
	};
	// Popup
	
	public class MyThread extends AsyncTask<Void, Void, Void>{
		@Override
		protected Void doInBackground(Void... params) {
		
			if(instruction == SCAN){
				
				getCurrentMacAddress();
				publishProgress((Void)null);
				try {
					Thread.sleep(10000);
					mHandler.sendEmptyMessage(instruction);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				//mHandler.sendEmptyMessageDelayed(instruction, 20000);
				Log.d("HAndler", "handleMessage");
			} else {
				//Toast.makeText(getApplicationContext(), "STOP SCAN", Toast.LENGTH_SHORT).show();
			}
			
			
			return null;
		}
		
		@Override
		protected void onProgressUpdate(Void... values){
			//Toast.makeText(getApplicationContext(), "SCAN", Toast.LENGTH_SHORT).show();
			maclist.setAdapter(new ArrayAdapter<String>(StartService.this,
					android.R.layout.simple_list_item_1,maclist_contents));
			super.onProgressUpdate(values);
		}
	}
}