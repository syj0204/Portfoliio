package kbssm.hightech.adballoon;

import java.util.ArrayList;

import org.apache.http.protocol.HTTP;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MySubCategory extends Dialog {
	
	private AdBalloon App;
	
	private String main;
	private Category sub;
	private ArrayList<Category> subList = new ArrayList<Category>();
	private String id;
	
	public MySubCategory(Context context, ArrayList<String> codeList, ArrayList<String> subList, ArrayList<String> checkList, String id) {
		super(context, android.R.style.Theme_Translucent_NoTitleBar);
		this.id = id;
		if(subList!=null && subList.size() != 0){
			for(int i=0;i<subList.size();i++){
				boolean check = false;
				if(checkList.get(i).equals("true"))
					check = true;
				else
					check = false;
				Category category = new Category(codeList.get(i), subList.get(i), check);
				//Toast.makeText(getContext(), "check : "+check, Toast.LENGTH_SHORT).show();
				this.subList.add(category);
			}
		}
	}

	MyCustomAdapter dataAdapter = null;
	 
	 @Override
	 public void onCreate(Bundle savedInstanceState) {
	  super.onCreate(savedInstanceState);
	  setContentView(R.layout.my_subcategory);
	 
	  //Generate list View from ArrayList
	  displayListView();
	 
	  checkButtonClick();
	 
	 }
	 
	 private void displayListView() {
	 
	  //Array list of countries
	  //ArrayList<Category> categoryList = new ArrayList<Category>();
	  ArrayList<Category> subCategoryList = new ArrayList<Category>();

	  subCategoryList.addAll(subList);
	  /*
	  if(subCategory.equals(MainCategory.CAFE)){
		  Cafe.addCafeList(subCategoryList);
	  } else if(subCategory.equals(MainCategory.RESTAURANT)){
		  Cafe.addCafeList(subCategoryList);
	  } else if(subCategory.equals(MainCategory.THEATER)){
		  Theater.addTheaterList(subCategoryList);
	  } else if(subCategory.equals(MainCategory.ETC)){
		  Cafe.addCafeList(subCategoryList);
	  }*/
	  
	 
	  //create an ArrayAdaptar from the String Array
	  dataAdapter = new MyCustomAdapter(getContext(),
	    R.layout.subcategory_info, subCategoryList);
	  ListView listView = (ListView) findViewById(R.id.listView1);
	  // Assign adapter to ListView
	  listView.setAdapter(dataAdapter);
	 
	 
	  listView.setOnItemClickListener(new OnItemClickListener() {
	   public void onItemClick(AdapterView<?> parent, View view,
	     int position, long id) {
	    // When clicked, show a toast with the TextView text
	    Category category = (Category) parent.getItemAtPosition(position);
		//   String sub = (String) parent.getItemAtPosition(position);
	    //Toast.makeText(getContext(),
	    //  "Clicked on Row: " + subList.get(position).getSub() + " " + subList.get(position).getCode(), 
	     // Toast.LENGTH_SHORT).show();
	   }
	  });
	 
	 }
	 
	 private class MyCustomAdapter extends ArrayAdapter<Category> {
	 
	  private ArrayList<Category> subList;
	 
	  public MyCustomAdapter(Context context, int textViewResourceId, 
	    ArrayList<Category> subList) {
	   super(context, textViewResourceId, subList);
	   this.subList = new ArrayList<Category>();
	   this.subList.addAll(subList);
	  }
	 
	  private class ViewHolder {
	   TextView code;
	   CheckBox name;
	  }
	 
	  @Override
	  public View getView(int position, View convertView, ViewGroup parent) {
	 
	   ViewHolder holder = null;
	   Log.v("ConvertView", String.valueOf(position));
	 
	   if (convertView == null) {
	   LayoutInflater vi = (LayoutInflater)getContext().getSystemService(
	     Context.LAYOUT_INFLATER_SERVICE);
	   convertView = vi.inflate(R.layout.subcategory_info, null);
	 
	   holder = new ViewHolder();
	   holder.code = (TextView) convertView.findViewById(R.id.code);
	   holder.name = (CheckBox) convertView.findViewById(R.id.checkBox1);
	   convertView.setTag(holder);
	 
	    holder.name.setOnClickListener( new View.OnClickListener() {  
	     public void onClick(View v) {  
	      CheckBox cb = (CheckBox) v ;  
	      Category category = (Category) cb.getTag();  
	      /*Toast.makeText(getContext(),
	       "Clicked on Checkbox: " + cb.getText() +
	       " is " + cb.isChecked(), 
	       Toast.LENGTH_LONG).show();*/
	      category.setSelected(cb.isChecked());
	     }  
	    });  
	   } 
	   else {
	    holder = (ViewHolder) convertView.getTag();
	   }
	 
	   Category sub = subList.get(position);
	   holder.code.setText(" (" + sub.getCode() + ")");
	   holder.name.setText(sub.getSub());
	   holder.name.setChecked(sub.isSelected());
	   holder.name.setTag(sub);
	 
	   return convertView;
	 
	  }
	 
	 }
	 
	 private void checkButtonClick() {
	 
	  /*Button myButton = (Button) findViewById(R.id.findSelected);
	  myButton.setOnClickListener(new View.OnClickListener() {
	   @Override
	   public void onClick(View v) {
	 
	    StringBuffer responseText = new StringBuffer();
	    responseText.append("The following were selected...\n");
	 
	    ArrayList<Category> categoryList = dataAdapter.categoryList;
	    for(int i=0;i<categoryList.size();i++){
	     Category category = categoryList.get(i);
	     if(category.isSelected()){
	      responseText.append("\n" + category.getSub());
	     }
	    }
	 
	    Toast.makeText(getContext(),
	      responseText, Toast.LENGTH_LONG).show();
	    
	   }
	  });*/
		 Button selectButton = (Button)findViewById(R.id.selectAll);
		 Button deselectButton = (Button)findViewById(R.id.deselectAll);
		 Button completeButton = (Button)findViewById(R.id.complete);
		 selectButton.setOnClickListener(buttonClick);
		 deselectButton.setOnClickListener(buttonClick);
		 completeButton.setOnClickListener(buttonClick);
	 
	 }
	 
	 View.OnClickListener buttonClick = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			ArrayList<Category> categoryList = dataAdapter.subList;
			Category category;
			switch(v.getId()){
			case R.id.selectAll:
				for(int i=0;i<categoryList.size();i++){
					category = categoryList.get(i);
					category.setSelected(true);
					dataAdapter.notifyDataSetChanged();
				}
				break;
			case R.id.deselectAll:
				for(int i=0;i<categoryList.size();i++){
					category = categoryList.get(i);
					category.setSelected(false);
					dataAdapter.notifyDataSetChanged();
				}
				break;
			case R.id.complete:
				HttpSupport http = new HttpSupport();
				for(int i=0;i<categoryList.size();i++){
					category = categoryList.get(i);
					if(category.isSelected()){
						// selected item�� ����
						ArrayList<String> temp = http.sendSelectedCode(getContext(), http.SERVER_URL+"getSelectedBrandValue.jsp", id, subList.get(i).getCode(), "true");
					} else {
						ArrayList<String> temp = http.sendSelectedCode(getContext(), http.SERVER_URL+"getSelectedBrandValue.jsp", id, subList.get(i).getCode(), "false");
					}
				}
				//Toast.makeText(getContext(), "Send End Code", Toast.LENGTH_SHORT).show();
				MySubCategory.this.dismiss();
				break;
			}
		}
	};
	 private static class MainCategory{
		 protected static final String MAIN = "MAINCATEGORY";
		 protected static final String CAFE = "����";
		 protected static final String THEATER = "��ȭ��";
		 protected static final String MART = "������Ʈ";
		 protected static final String CONVENIENCE = "������";
		 protected static final String RESTAURANT = "�йи��������";
		 protected static final String COSMETIC = "�ڽ���ƽ";
		 protected static final String FASTFOOD = "�н�ƮǪ��";
		 protected static final String ETC = "ETC";
		 
		 protected static final String[] CategoryList = 
			 {CAFE, THEATER, MART, CONVENIENCE, RESTAURANT, COSMETIC, FASTFOOD, ETC};
		 
		 protected static void addCategoryList(ArrayList<Category> categoryList){
			 if(categoryList != null){
				 for(int i=0;i<CategoryList.length;i++){
					 categoryList.add(new Category(MainCategory.MAIN, CategoryList[i], false));
				 }
			 }
		 }
	 }
	 
	 private static class Cafe{
		 protected static final String CAFE = "CAFE";
		 protected static final String STARBUCKS = "STARBUCKS COFFEE";
		 protected static final String TOMNTOMS = "TOM N TOMS COFFEE";
		 protected static final String HOLLYS = "HOLLYS COFFEE";
		 protected static final String CAFFEBENE = "Caffebene";
		 protected static final String ANGELINUS = "Angel in-us Coffee";
		 protected static final String EDIYA = "EDIYA COFFEE";
		 protected static final String PASCUCCI = "CAFFE PASCUCCI";
		 protected static final String TWOSOMEPLACE = "A TWOSOME PLACE";
		 protected static final String TIAMO = "caffe Ti-amo";
		 protected static final String COFFEEBEAN = "The Coffee Bean";
		 protected static final String COFFINEGURUNARU = "COFFINE GURUNARU";
		 protected static final String ETC = "ETC";
		 
		 protected static final String[] CafeList = 
			 {STARBUCKS, TOMNTOMS, HOLLYS, CAFFEBENE, ANGELINUS, EDIYA, PASCUCCI, TWOSOMEPLACE, TIAMO, COFFEEBEAN, COFFINEGURUNARU, ETC};
		 
		 protected static void addCafeList(ArrayList<Category> categoryList){
			 if(categoryList != null){
				 for(int i=0;i<CafeList.length;i++){
					 categoryList.add(new Category(Cafe.CAFE, CafeList[i], false));
				 }
			 }
		 }
	 }
	 
	 private static class Theater{
		 protected static final String THEATER = "THEATER";
		 protected static final String CGV = "CGV";
		 protected static final String LOTTECINEMA = "LOTTE CINEMA";
		 protected static final String MEGABOX = "MEGABOX";
		 protected static final String ETC = "ETC";
		 
		 protected static final String[] TheaterList = 
			 {CGV, LOTTECINEMA, MEGABOX, ETC};
		 
		 protected static void addTheaterList(ArrayList<Category> categoryList){
			 if(categoryList != null){
				 for(int i=0;i<TheaterList.length;i++){
					 categoryList.add(new Category(Theater.THEATER, TheaterList[i], false));
				 }
			 }
		 }
	 }
}