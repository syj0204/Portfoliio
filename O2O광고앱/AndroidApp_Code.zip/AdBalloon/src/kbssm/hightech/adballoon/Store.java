package kbssm.hightech.adballoon;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import kbssm.hightech.adballoon.Ad.MyThread;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class Store extends Activity{
	
	private AdBalloon App;
	private MyThread mMyThread;
	
	private String branchCode;
	private boolean favoriteCheck = false;
	
	private TextView branchStoreName;
	private RatingBar branchRating;
	private TextView branchScore;
	private ImageView branchIsFavorite;
	private ImageView branchImage;
	private TextView branchAddress;
	private TextView branchPhone;
	
	private ArrayList<String> branchInfo = new ArrayList<String>();
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.store_information);
		
		Intent intent = getIntent();
		branchCode = intent.getStringExtra("BRANCH_CODE");
		
		branchRating = (RatingBar) findViewById(R.id.ratingbar);
		branchRating.setStepSize((float) 0.5);         //�� ������ 1ĭ���پ��� �þ 0.5���ϸ� ��ĭ�� ��
		branchRating.setRating((float) 0);     		 // ó�������ٶ�(������ �Ѱ�������) default ���� 0  �̴�
		branchRating.setIsIndicator(true);			 //true - ������ ǥ�� ����ڰ� ���� �Ұ� , false - ����ڰ� ���氡��
		branchStoreName = (TextView)findViewById(R.id.store_main_name);
		branchIsFavorite = (ImageView)findViewById(R.id.favorite);
		branchScore = (TextView)findViewById(R.id.store_score);
		branchImage = (ImageView)findViewById(R.id.store_img);
		branchAddress = (TextView)findViewById(R.id.store_address);
		branchPhone = (TextView)findViewById(R.id.store_phone);
        /*
        rating.setOnRatingBarChangeListener(new OnRatingBarChangeListener() {
			
			@Override
			public void onRatingChanged(RatingBar ratingBar, float rating,
					boolean fromUser) {
								
			}
		});*/

        final ImageView favorite = (ImageView)findViewById(R.id.favorite);
        if(favoriteCheck){
        	favorite.setImageResource(R.drawable.btn_star_filled);
        } else {
        	favorite.setImageResource(R.drawable.btn_star_empty);
        }
        
        favorite.setOnClickListener(new OnClickListener(){
        	public void onClick(View v){
        		favoriteCheck=!favoriteCheck;
        		if(favoriteCheck){
        			favorite.setImageResource(R.drawable.btn_star_filled);
        			Toast.makeText(getApplicationContext(), "���ã��� ����Ͽ����ϴ�.", Toast.LENGTH_SHORT).show();
        		} else {
        			favorite.setImageResource(R.drawable.btn_star_empty);
        			Toast.makeText(getApplicationContext(), "���ã�⿡�� �����Ǿ����ϴ�.", Toast.LENGTH_SHORT).show();
        		}
        	}
        });
        
        Button Map_btn = (Button)findViewById(R.id.map_bnt);
        Map_btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				//Toast.makeText(Store.this,"Google",Toast.LENGTH_SHORT).show();
				Intent Start_Map_class = new Intent(Store.this, Map.class);
				Start_Map_class.putExtra("ADDRESS", branchInfo.get(2));
				startActivity(Start_Map_class);
			}
		});
        
        Button evaluation_btn = (Button)findViewById(R.id.evaluation_bnt);
        evaluation_btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				//Toast.makeText(Store.this,"Evaluation",Toast.LENGTH_SHORT).show();
				Intent Start_Evaluation_class = new Intent(Store.this, StoreEvaluation.class);
				startActivity(Start_Evaluation_class);
			}
		});
        
        mMyThread = (MyThread)new MyThread().execute((Void)null);
	}
	
public class MyThread extends AsyncTask<Void, Void, Void>{
		
		private ArrayList<String> branchInfo = new ArrayList<String>();
		
		@Override
		protected Void doInBackground(Void... params) {
			HttpSupport http = new HttpSupport();
			App = (AdBalloon)getApplication();
			// 0 : AdName  1 : AdBrandName  2 : AdStoreName  3 : AdImageRoot  4 : BranchCode
			branchInfo = http.sendBranchCode(getApplicationContext(), http.SERVER_URL+"branchinfosend_control.jsp", App.getCustomerId(), branchCode);
			Store.this.branchInfo = branchInfo;
			//branchCode = branchInfo.get(4);
				publishProgress((Void)null);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			return null;
		}
		
		@Override
		protected void onProgressUpdate(Void... values){
			//if(branchInfo != null)
			//Toast.makeText(getApplicationContext(), branchInfo.toString(), Toast.LENGTH_SHORT).show();
			if(branchInfo.size() >= 6){
				// 0:BranchName  1:BrandName  2:BranchAddress  3:BranchPhone  4:BranchImage  5:BranchFavorite  6:BranchScore
				branchStoreName.setText(branchInfo.get(1) + " - " + branchInfo.get(0));
				branchAddress.setText("�����ּ� : "+branchInfo.get(2));
				Drawable image = ImageOperations(getBaseContext(), branchInfo.get(4), "image.jpg");
				Bitmap bitmap = ((BitmapDrawable)image).getBitmap();
				DisplayMetrics displayMetrics = new DisplayMetrics();
				getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
				int deviceWidth = displayMetrics.widthPixels;
				int deviceHeight =displayMetrics.heightPixels;
				image = new BitmapDrawable(getResources(), Bitmap.createScaledBitmap(bitmap, deviceWidth-20, (int)((float)(deviceWidth-20)*(float)((float)deviceHeight/(float)deviceWidth)), true));
				branchImage.setImageDrawable(image);
				branchPhone.setText("��ȭ��ȣ : "+branchInfo.get(3));
				if(branchInfo.get(5).equals("true")){
		        	branchIsFavorite.setImageResource(R.drawable.btn_star_filled);
		        } else {
		        	branchIsFavorite.setImageResource(R.drawable.btn_star_empty);
		        }
				if(branchInfo.size() >= 7){
					branchRating.setRating(Float.parseFloat(branchInfo.get(6)));
					branchScore.setText(branchInfo.get(6));
				} else {
					branchScore.setText("0");
				}
			}
			super.onProgressUpdate(values);
		}
		
		private Drawable ImageOperations(Context ctx, String url, String saveFilename) {
	        try {
	            URL imageUrl = new URL(url);
	            InputStream is = (InputStream) imageUrl.getContent();
	            Drawable d = Drawable.createFromStream(is, "src");
	            return d;
	        } catch (MalformedURLException e) {
	            e.printStackTrace();
	            return null;
	        } catch (IOException e) {
	            e.printStackTrace();
	            return null;
	        }
	    }
	}
}