package kbssm.hightech.adballoon;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.PagerTitleStrip;
import android.support.v4.view.ViewPager;
import android.util.Log;

import com.google.android.gcm.GCMRegistrar;

@SuppressLint("NewApi")
public class SwipeActivity extends FragmentActivity {

	// When requested, this adapter returns a DemoObjectFragment,
    // representing an object in the collection.
    DemoCollectionPagerAdapter mDemoCollectionPagerAdapter;
    ViewPager mViewPager;
    PagerTitleStrip mTitleStrip;

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final ActionBar actionBar = getActionBar();
        
        
        
        setContentView(R.layout.activity_swipe);
        
     // Specify that tabs should be displayed in the action bar.
        //actionBar.setNavigationMode(ActionBar.DISPLAY_SHOW_TITLE);

        // ViewPager and its adapters use support library
        // fragments, so use getSupportFragmentManager.
        mDemoCollectionPagerAdapter =
                new DemoCollectionPagerAdapter(
                        getSupportFragmentManager());
        mViewPager = (ViewPager) findViewById(R.id.pager);
        mViewPager.setAdapter(mDemoCollectionPagerAdapter);
        mViewPager.setCurrentItem(1);
        
     // Create a tab listener that is called when the user changes tabs.
        ActionBar.TabListener tabListener = new ActionBar.TabListener() {
            /*public void onTabSelected(ActionBar.Tab tab, FragmentTransaction ft) {
                // show the given tab
            	
            	// When the tab is selected, switch to the
                // corresponding page in the ViewPager.
                mViewPager.setCurrentItem(tab.getPosition());
            }

            public void onTabUnselected(ActionBar.Tab tab, FragmentTransaction ft) {
                // hide the given tab
            }

            public void onTabReselected(ActionBar.Tab tab, FragmentTransaction ft) {
                // probably ignore this event
            }*/

			@Override
			public void onTabReselected(Tab tab, FragmentTransaction ft) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onTabSelected(Tab tab, FragmentTransaction ft) {
				// TODO Auto-generated method stub
				// When the tab is selected, switch to the
                // corresponding page in the ViewPager.
                mViewPager.setCurrentItem(tab.getPosition());
			}

			@Override
			public void onTabUnselected(Tab tab, FragmentTransaction ft) {
				// TODO Auto-generated method stub
				
			}
        };
        

        // Add 3 tabs, specifying the tab's text and TabListener
        /*for (int i = 0; i < 3; i++) {
            actionBar.addTab(
                    actionBar.newTab()
                            .setText("Tab " + (i + 1))
                            .setTabListener(tabListener));
        }*/
    }

 // Since this is an object collection, use a FragmentStatePagerAdapter,
 // and NOT a FragmentPagerAdapter.
 public class DemoCollectionPagerAdapter extends FragmentStatePagerAdapter {
     public DemoCollectionPagerAdapter(FragmentManager fm) {
         super(fm);
     }

     @Override
     public Fragment getItem(int i) {
	         /*Fragment fragment = new DemoObjectFragment();
	         Bundle args = new Bundle();
	         // Our object is just an integer :-P
	         args.putInt(DemoObjectFragment.ARG_OBJECT, i + 1);
	         fragment.setArguments(args);*/
    	 Fragment fragment = new MyCategory();
    	 Bundle args = new Bundle();
    	 switch(i){
    	 case 0:
    		 fragment = new MyInfo();
    		 args.putInt("NUMBER", 0);
    		 fragment.setArguments(args);
    		 break;
    	 case 1:
    		 fragment = new MyCategory();
    		 args.putInt("NUMBER", 1);
    		 fragment.setArguments(args);
    		 break;
    	 case 2:
    		 fragment = new MyFavorite();
    		 args.putInt("NUMBER", 2);
    		 fragment.setArguments(args);
    		 break;
		 default:
    		 break;
    	 }
    	 
         return fragment;
     }

     @Override
     public int getCount() {
         return 3;
     }

     @Override
     public CharSequence getPageTitle(int position) {
    	 switch(position){
    	 case 0:
    		 return "�� ����";
    	 case 1:
    		 return "�� �����׸�";
    	 case 2:
    		 return "�� ���ã��";
    	 }
		return "No Title";
     }
 }

 /*// Instances of this class are fragments representing a single
 // object in our collection.
 public static class DemoObjectFragment extends Fragment {
     public static final String ARG_OBJECT = "object";

     @Override
     public View onCreateView(LayoutInflater inflater,
             ViewGroup container, Bundle savedInstanceState) {
         // The last two arguments ensure LayoutParams are inflated
         // properly.
         View rootView = inflater.inflate(
                 R.layout.layout1, container, false);
         Bundle args = getArguments();

         return rootView;
     }
 }*/
}
