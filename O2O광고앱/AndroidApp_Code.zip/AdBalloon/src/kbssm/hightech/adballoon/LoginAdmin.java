package kbssm.hightech.adballoon;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

@SuppressLint("SetJavaScriptEnabled")
public class LoginAdmin extends Activity{
	
	private static final String SERVER_URL = "http://112.108.40.157:8080/MiniProject/";
	
	private EditText editId, editPw;
	private Button loginAdmin, findId, findPw, signUp;
	
	private String id="", pw="";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.login_admin);
		
		editId = (EditText)findViewById(R.id.inputId);
		editPw = (EditText)findViewById(R.id.inputPw);
		
		loginAdmin = (Button)findViewById(R.id.btn_login_admin);
		loginAdmin.setOnClickListener(buttonClick);
		findId = (Button)findViewById(R.id.find_id);
		findId.setOnClickListener(buttonClick);
		findPw = (Button)findViewById(R.id.find_pw);
		findPw.setOnClickListener(buttonClick);
		signUp = (Button)findViewById(R.id.sign_up);
		signUp.setOnClickListener(buttonClick);
	
	}
	
	private OnClickListener buttonClick = new OnClickListener() {
		@Override
		public void onClick(View v) {
			switch(v.getId()){
			case R.id.btn_login_admin:
				if(editId.getText().toString()!=null){
					id = editId.getText().toString();
				} else id = "";
				if(editPw.getText().toString()!=null){
					pw = editPw.getText().toString();
				} else pw = "";
				// ID, PW ó��
				//Toast.makeText(getApplicationContext(), "id : "+id+" pw : "+pw, Toast.LENGTH_SHORT).show();
				
				HttpSupport http = new HttpSupport();
				
				if(http.adminLogin(getApplicationContext(), "http://112.108.40.157:8080/MiniProject/android_marketer_login_control.jsp", id, pw)){
					/*Intent intent = new Intent(getApplicationContext(), StoreListAdmin.class);
					startActivity(intent);*/
					startWebView(SERVER_URL+"marketer_branch_list.jsp");
				} else {
					Toast.makeText(getApplicationContext(), "Login Failed", Toast.LENGTH_SHORT).show();
				}
				break;
			case R.id.find_id:
				startWebView(SERVER_URL+"find_id_form.html");
				break;
			case R.id.find_pw:
				startWebView(SERVER_URL+"find_pw_form.html");
				break;
			case R.id.sign_up:
				startWebView(SERVER_URL+"join_form.html");
				//startWebView("http://fd.naver.com");
				break;
			}
		}
	};
	
	private void startWebView(String url){
		Intent intent = new Intent(getApplicationContext(), LoadWebView.class);
		intent.putExtra("URL", url);
		startActivity(intent);
	}
}