package kbssm.hightech.adballoon;

import java.util.ArrayList;

import android.app.Application;

import com.facebook.model.GraphUser;
import com.google.android.gms.internal.cu;
import com.google.android.gms.plus.model.people.Person;

public class AdBalloon extends Application{
	private GraphUser facebookUser;
	private Person googleUser;
	private String customerId;
	private ArrayList<String> subList = new ArrayList<String>();
	private PopDialog pop = null;
	
	protected synchronized void setFacebookUser(GraphUser fbUser){
		this.facebookUser = fbUser;
	}
	protected synchronized GraphUser getFacebookUser(){
		return this.facebookUser;
	}
	
	protected synchronized void setGoogleUser(Person ggUser){
		this.googleUser = ggUser;
	}
	protected synchronized Person getGoogleUser(){
		return this.googleUser;
	}
	
	protected synchronized void setCustomerId(String customerId){
		this.customerId = customerId;
	}
	protected synchronized String getCustomerId(){
		return this.customerId;
	}
	
	protected synchronized void setSubList(ArrayList<String> subList){
		this.subList.addAll(subList);
	}
	protected synchronized ArrayList<String> getSubList(){
		return this.subList;
	}
	
	protected synchronized void setPop(PopDialog pop){
		this.pop = pop;
	}
	protected synchronized PopDialog getPop(){
		return this.pop;
	}
	
	// All Information Clear
	protected synchronized void clearAll(){
		this.facebookUser = null;
		this.googleUser = null;
		this.customerId = null;
	}
}