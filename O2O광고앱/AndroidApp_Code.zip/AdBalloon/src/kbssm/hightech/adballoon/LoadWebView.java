package kbssm.hightech.adballoon;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

@SuppressLint("SetJavaScriptEnabled")
public class LoadWebView extends Activity {
	private WebView mWebView;
	private Button mClose;
    
	private String targetUrl;
	
	protected void setUrl(String url){
		if(url != null)
		this.targetUrl = url;
	}
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.webview);
         
        setLayout();
         
        Intent intent = getIntent();
        setUrl(intent.getStringExtra("URL"));
        
        // ���信�� �ڹٽ�ũ��Ʈ���డ��
        mWebView.getSettings().setJavaScriptEnabled(true); 
        // ����Ȩ������ ����
        mWebView.loadUrl(targetUrl);
        // WebViewClient ����
        mWebView.setWebViewClient(new WebViewClientClass());  
         
        mClose.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
        
    }
     
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) { 
        if ((keyCode == KeyEvent.KEYCODE_BACK) && mWebView.canGoBack()) { 
            mWebView.goBack(); 
            return true; 
        } 
        return super.onKeyDown(keyCode, event);
    }
     
    private class WebViewClientClass extends WebViewClient { 
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) { 
            view.loadUrl(url); 
            return true; 
        } 
    }
     
    /*
     * Layout
     */
    private void setLayout(){
        mWebView = (WebView) findViewById(R.id.webview);
        mClose = (Button)findViewById(R.id.close_webview);
    }
}