package kbssm.hightech.adballoon;

public class AdInfo {
	
	private String storeName;
	private String adTitle;
	private String code;
	
	public AdInfo(){
		
	}
	
	public AdInfo(String storeName, String adTitle, String code){
		this.storeName = storeName;
		this.adTitle = adTitle;
		this.code = code;
	}
	
	protected void setStoreName(String storeName){
		this.storeName = storeName;
	}
	protected String getStoreName(){
		return this.storeName;
	}
	
	protected void setAdTitle(String adTitle){
		this.adTitle = adTitle;
	}
	protected String getAdTitle(){
		return this.adTitle;
	}
	
	protected void setCode(String code){
		this.code = code;
	}
	protected String getCode(){
		return this.code;
	}
}