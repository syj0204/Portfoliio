package kbssm.hightech.adballoon;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;

import android.content.Context;
import android.os.StrictMode;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import com.facebook.model.GraphUser;
import com.google.android.gms.plus.model.people.Person;

public class HttpSupport {
	
	protected final String SERVER_URL = "http://112.108.40.157:8080/MiniProject/";
	
	protected HttpSupport(){
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
        .permitAll().build();
		StrictMode.setThreadPolicy(policy);
	}
	
	protected boolean adminLogin(Context context, String url, String id, String pw){
		HttpClient http = new DefaultHttpClient();
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("marketer_id", id));
		nameValuePairs.add(new BasicNameValuePair("pw", pw));
		
		HttpParams params = http.getParams();
        HttpConnectionParams.setConnectionTimeout(params, 5000);
        HttpConnectionParams.setSoTimeout(params, 5000);
        try {
	        HttpPost httpPost = new HttpPost(url);
	        UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(
	              nameValuePairs, "UTF-8");
	        httpPost.setEntity(entityRequest);
	        HttpResponse responsePost = http.execute(httpPost);
	        HttpEntity resEntity = responsePost.getEntity();
        
	        String response = EntityUtils.toString(resEntity);
	        String loginResponse = response.substring(response.indexOf("<<")+2, response.indexOf(">>"));
	        
			//Toast.makeText(context, loginResponse, Toast.LENGTH_SHORT).show();
	        if(loginResponse.equals("true")){
	        	return true;
	        } else if(loginResponse.equals("false")){
	        	return false;
	        }
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return false;
	}
	
	protected String insertData(Context context, String url, String data){
		HttpClient http = new DefaultHttpClient();
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("insert", data));
		
		HttpParams params = http.getParams();
        HttpConnectionParams.setConnectionTimeout(params, 5000);
        HttpConnectionParams.setSoTimeout(params, 5000);
        try {
	        HttpPost httpPost = new HttpPost(url);
	        UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(
	              nameValuePairs, "UTF-8");
	        httpPost.setEntity(entityRequest);
	        HttpResponse responsePost = http.execute(httpPost);
	        HttpEntity resEntity = responsePost.getEntity();
	        
	        String response = EntityUtils.toString(resEntity);
	        String insertResponse = response.substring(response.indexOf("<<")+2, response.indexOf(">>"));
	        
			//Toast.makeText(context, insertResponse, Toast.LENGTH_SHORT).show();
			return insertResponse;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return null;
	}
	
	protected String deleteData(Context context, String url, String data){
		HttpClient http = new DefaultHttpClient();
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("delete", data));
		
		HttpParams params = http.getParams();
        HttpConnectionParams.setConnectionTimeout(params, 5000);
        HttpConnectionParams.setSoTimeout(params, 5000);
        try {
	        HttpPost httpPost = new HttpPost(url);
	        UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(
	              nameValuePairs, "UTF-8");
	        httpPost.setEntity(entityRequest);
	        HttpResponse responsePost = http.execute(httpPost);
	        HttpEntity resEntity = responsePost.getEntity();
        
	        String response = EntityUtils.toString(resEntity);
	        String deleteResponse = response.substring(response.indexOf("<<")+2, response.indexOf(">>"));
	        
			//Toast.makeText(context, deleteResponse, Toast.LENGTH_SHORT).show();
			return deleteResponse;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return null;
	}
	
	protected void updateData(Context context, String url, String data){
		HttpClient http = new DefaultHttpClient();
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("update", "HighTech"));
		
		HttpParams params = http.getParams();
        HttpConnectionParams.setConnectionTimeout(params, 5000);
        HttpConnectionParams.setSoTimeout(params, 5000);
        try {
	        HttpPost httpPost = new HttpPost(url);
	        UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(
	              nameValuePairs, "UTF-8");
	        httpPost.setEntity(entityRequest);
	        HttpResponse responsePost = http.execute(httpPost);
	        HttpEntity resEntity = responsePost.getEntity();
        
			//Toast.makeText(context, EntityUtils.toString(resEntity), Toast.LENGTH_SHORT).show();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	protected String selectData(Context context, String url, String data){
		HttpClient http = new DefaultHttpClient();
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("select", data));
		
		HttpParams params = http.getParams();
        HttpConnectionParams.setConnectionTimeout(params, 5000);
        HttpConnectionParams.setSoTimeout(params, 5000);
        try {
	        HttpPost httpPost = new HttpPost(url);
	        UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(
	              nameValuePairs, "UTF-8");
	        httpPost.setEntity(entityRequest);
	        HttpResponse responsePost = http.execute(httpPost);
	        HttpEntity resEntity = responsePost.getEntity();
        
	        String response = EntityUtils.toString(resEntity);
	        String selectResponse = response.substring(response.indexOf("<<")+2, response.indexOf(">>"));
	        
			//Toast.makeText(context, selectResponse, Toast.LENGTH_SHORT).show();
			return selectResponse;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return null;
	}
	
	protected String loginConnect(Context context, String url, GraphUser user, Person person){
		//String url = "http://112.108.40.157:8080/MiniProject/login_control.jsp";
	      HttpClient http = new DefaultHttpClient();
	      TelephonyManager manager = (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
	      try {
	         ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
	         if(user != null){
	        	 Calendar c = Calendar.getInstance();
	        	 SimpleDateFormat format = new SimpleDateFormat("yyyy");
	        	 String formatDate = format.format(c.getTime());
	        	 Log.d("date : ", formatDate);
	        	 int age = 0;
	        	 if(user.getBirthday()!=null){
	        	 String birth = user.getBirthday().substring(6, 10);
	        	 Log.d("birth : ", birth);
	        	 age = Integer.parseInt(formatDate) - Integer.parseInt(birth) + 1;
	        	 }
		         nameValuePairs.add(new BasicNameValuePair("name", user.getName()));
		         nameValuePairs.add(new BasicNameValuePair("phone", manager.getLine1Number()));
		         nameValuePairs.add(new BasicNameValuePair("age", String.valueOf(age)));
		         nameValuePairs.add(new BasicNameValuePair("facebookid", user.getId()));
		         nameValuePairs.add(new BasicNameValuePair("googleid", null));
		         nameValuePairs.add(new BasicNameValuePair("kakaoid", null));
		         Log.d("check", "facebookid : "+user.getId()+"\nage : "+String.valueOf(age)+"\nphone : "+manager.getLine1Number());
	         } else if(person != null){
	        	 //Calendar c = Calendar.getInstance();
	        	 //SimpleDateFormat format = new SimpleDateFormat("yyyy");
	        	 //String formatDate = format.format(c.getTime());
	        	 //String birth = user.getBirthday().substring(0, 4);
	        	 //int age = Integer.parseInt(formatDate) - Integer.parseInt(birth) + 1;
		         nameValuePairs.add(new BasicNameValuePair("name", person.getDisplayName()));
		         nameValuePairs.add(new BasicNameValuePair("phone", manager.getLine1Number()));
		         nameValuePairs.add(new BasicNameValuePair("age", "0"));
		         nameValuePairs.add(new BasicNameValuePair("facebookid", null));
		         nameValuePairs.add(new BasicNameValuePair("googleid", person.getId()));
		         nameValuePairs.add(new BasicNameValuePair("kakaoid", null));
		         Log.d("check", "googleid : "+person.getId()+"\nphone : "+manager.getLine1Number());
	         }
	         
	         //Toast.makeText(context, "facebookid : "+user.getId()+"\ngoogleid : "+person.getId()+"\nphone : "+manager.getLine1Number(), Toast.LENGTH_SHORT).show();
	         
	         Log.d("1", "1");
	         HttpParams params = http.getParams();
	         HttpConnectionParams.setConnectionTimeout(params, 3000);
	         HttpConnectionParams.setSoTimeout(params, 3000);
	         Log.d("2", "2");
	         HttpPost httpPost = new HttpPost(url);
	         UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(
	               nameValuePairs, "UTF-8");
	         httpPost.setEntity(entityRequest);
	         Log.d("3", "3");
	         HttpResponse responsePost = http.execute(httpPost);
	         HttpEntity resEntity = responsePost.getEntity();
	         //tv_post.setText(EntityUtils.toString(resEntity));
	         Log.d("4", "4");
	         String response = EntityUtils.toString(resEntity);
	         //Toast.makeText(context, "Response : "+response, Toast.LENGTH_SHORT).show();
	        String idResponse = response.substring(response.indexOf("<<")+2, response.indexOf(">>"));
	        
			//Toast.makeText(context, "ID Response : "+idResponse, Toast.LENGTH_SHORT).show();
			
			return idResponse;
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	      return null;
	}
	
	protected ArrayList<String> sendCategory(Context context, String url, String id, String category){
		HttpClient http = new DefaultHttpClient();
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("customer_id", id));
		nameValuePairs.add(new BasicNameValuePair("categorycode", category));
		nameValuePairs.add(new BasicNameValuePair("action", "select"));
		//nameValuePairs.add(new BasicNameValuePair("brandname", "UNIQLO"));
		//nameValuePairs.add(new BasicNameValuePair("action", "select"));
		
		HttpParams params = http.getParams();
        HttpConnectionParams.setConnectionTimeout(params, 5000);
        HttpConnectionParams.setSoTimeout(params, 5000);
        try {
	        HttpPost httpPost = new HttpPost(url);
	        UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(
	              nameValuePairs, "UTF-8");
	        httpPost.setEntity(entityRequest);
	        HttpResponse responsePost = http.execute(httpPost);
	        HttpEntity resEntity = responsePost.getEntity();
        
	        String response = EntityUtils.toString(resEntity);
	        //String selectResponse = response.substring(response.indexOf("<<")+2, response.indexOf(">>"));
	        //Toast.makeText(context, response, Toast.LENGTH_SHORT).show();
	        ArrayList<String> responseList = new ArrayList<String>();
	        
	        int temp_index = 0;
	        while(true){
	        	if(temp_index<response.length()-2 && response.indexOf("<<", temp_index) != -1){
		        	String listItem = response.substring(response.indexOf("<<", temp_index)+2, response.indexOf(">>", temp_index+2));
		        	temp_index = response.indexOf(">>", temp_index+2);
		        	if(listItem != null){
		        		//Toast.makeText(context, "listItem : "+listItem, Toast.LENGTH_SHORT).show();
		        		responseList.add(listItem);
		        	} else
		        		break;
	        	} else 
	        		break;
	        }
			return responseList;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return null;
	}
	
	protected ArrayList<String> sendSelectedCode(Context context, String url, String id, String code, String check){
		HttpClient http = new DefaultHttpClient();
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("customer_id", id));
		nameValuePairs.add(new BasicNameValuePair("brandcode", code));
		nameValuePairs.add(new BasicNameValuePair("check", check));
		
		HttpParams params = http.getParams();
        HttpConnectionParams.setConnectionTimeout(params, 5000);
        HttpConnectionParams.setSoTimeout(params, 5000);
        try {
	        HttpPost httpPost = new HttpPost(url);
	        UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(
	              nameValuePairs, "UTF-8");
	        httpPost.setEntity(entityRequest);
	        HttpResponse responsePost = http.execute(httpPost);
	        HttpEntity resEntity = responsePost.getEntity();
        
	        String response = EntityUtils.toString(resEntity);
	        //String selectResponse = response.substring(response.indexOf("<<")+2, response.indexOf(">>"));
	        //Toast.makeText(context, response, Toast.LENGTH_SHORT).show();
	        ArrayList<String> responseList = new ArrayList<String>();
	        
	        int temp_index = 0;
	        while(true){
	        	if(temp_index<response.length()-2 && response.indexOf("<<", temp_index) != -1){
		        	String listItem = response.substring(response.indexOf("<<", temp_index)+2, response.indexOf(">>", temp_index+2));
		        	temp_index = response.indexOf(">>", temp_index+2);
		        	if(listItem != null){
		        		//Toast.makeText(context, "listItem : "+listItem, Toast.LENGTH_SHORT).show();
		        		responseList.add(listItem);
		        	} else
		        		break;
	        	} else 
	        		break;
	        }
			return responseList;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return null;
	}
	
	protected ArrayList<String> sendMacAddress(Context context, String url, String id, String mac){
		HttpClient http = new DefaultHttpClient();
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("customer_id", id));
		nameValuePairs.add(new BasicNameValuePair("macaddress", mac));
		
		HttpParams params = http.getParams();
        HttpConnectionParams.setConnectionTimeout(params, 4000);
        HttpConnectionParams.setSoTimeout(params, 4000);
        try {
	        HttpPost httpPost = new HttpPost(url);
	        UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(
	              nameValuePairs, "UTF-8");
	        httpPost.setEntity(entityRequest);
	        HttpResponse responsePost = http.execute(httpPost);
	        HttpEntity resEntity = responsePost.getEntity();
        
	        String response = EntityUtils.toString(resEntity);
	        //String selectResponse = response.substring(response.indexOf("<<")+2, response.indexOf(">>"));
	        //Toast.makeText(context, response, Toast.LENGTH_SHORT).show();
	        ArrayList<String> responseList = new ArrayList<String>();
	        
	        int temp_index = 0;
	        while(true){
	        	if(temp_index<response.length()-2 && response.indexOf("<<", temp_index) != -1){
		        	String listItem = response.substring(response.indexOf("<<", temp_index)+2, response.indexOf(">>", temp_index+2));
		        	temp_index = response.indexOf(">>", temp_index+2);
		        	if(listItem != null){
		        		//Toast.makeText(context, "listItem : "+listItem, Toast.LENGTH_SHORT).show();
		        		responseList.add(listItem);
		        	} else
		        		break;
	        	} else 
	        		break;
	        }
			return responseList;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return null;
	}
	
	protected ArrayList<String> sendAdCode(Context context, String url, String adCode){
		HttpClient http = new DefaultHttpClient();
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("adcode", adCode));
		
		HttpParams params = http.getParams();
        HttpConnectionParams.setConnectionTimeout(params, 4000);
        HttpConnectionParams.setSoTimeout(params, 4000);
        try {
	        HttpPost httpPost = new HttpPost(url);
	        UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(
	              nameValuePairs, "UTF-8");
	        httpPost.setEntity(entityRequest);
	        HttpResponse responsePost = http.execute(httpPost);
	        HttpEntity resEntity = responsePost.getEntity();
        
	        String response = EntityUtils.toString(resEntity);
	        ArrayList<String> responseList = new ArrayList<String>();
	        
	        int temp_index = 0;
	        while(true){
	        	if(temp_index<response.length()-2 && response.indexOf("<<", temp_index) != -1){
		        	String listItem = response.substring(response.indexOf("<<", temp_index)+2, response.indexOf(">>", temp_index+2));
		        	temp_index = response.indexOf(">>", temp_index+2);
		        	if(listItem != null){
		        		//Toast.makeText(context, "listItem : "+listItem, Toast.LENGTH_SHORT).show();
		        		responseList.add(listItem);
		        	} else
		        		break;
	        	} else 
	        		break;
	        }
			return responseList;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return null;
	}
	
	protected ArrayList<String> sendBranchCode(Context context, String url, String id, String branchCode){
		HttpClient http = new DefaultHttpClient();
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("customer_id", id));
		nameValuePairs.add(new BasicNameValuePair("branchcode", branchCode));
		
		HttpParams params = http.getParams();
        HttpConnectionParams.setConnectionTimeout(params, 4000);
        HttpConnectionParams.setSoTimeout(params, 4000);
        try {
	        HttpPost httpPost = new HttpPost(url);
	        UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(
	              nameValuePairs, "UTF-8");
	        httpPost.setEntity(entityRequest);
	        HttpResponse responsePost = http.execute(httpPost);
	        HttpEntity resEntity = responsePost.getEntity();
        
	        String response = EntityUtils.toString(resEntity);
	        ArrayList<String> responseList = new ArrayList<String>();
	        
	        int temp_index = 0;
	        while(true){
	        	if(temp_index<response.length()-2 && response.indexOf("<<", temp_index) != -1){
		        	String listItem = response.substring(response.indexOf("<<", temp_index)+2, response.indexOf(">>", temp_index+2));
		        	temp_index = response.indexOf(">>", temp_index+2);
		        	if(listItem != null){
		        		//Toast.makeText(context, "listItem : "+listItem, Toast.LENGTH_SHORT).show();
		        		responseList.add(listItem);
		        	} else
		        		break;
	        	} else 
	        		break;
	        }
			return responseList;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return null;
	}
	
	protected void sendTest(Context context){
		HttpClient http = new DefaultHttpClient();
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("macaddress", "123456789"));
		nameValuePairs.add(new BasicNameValuePair("customer_id", "customer_id2"));
		
		HttpParams params = http.getParams();
        HttpConnectionParams.setConnectionTimeout(params, 5000);
        HttpConnectionParams.setSoTimeout(params, 5000);
        try {
	        HttpPost httpPost = new HttpPost(SERVER_URL+"adsend_control.jsp");
	        UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(
	              nameValuePairs, "UTF-8");
	        httpPost.setEntity(entityRequest);
	        HttpResponse responsePost = http.execute(httpPost);
	        HttpEntity resEntity = responsePost.getEntity();
        
	        String response = EntityUtils.toString(resEntity);
	        //String selectResponse = response.substring(response.indexOf("<<")+2, response.indexOf(">>"));
	        
	        ArrayList<String> responseList = new ArrayList<String>();

	        	String listItem = response.substring(response.indexOf("<<")+2, response.indexOf(">>"));
	        		//Toast.makeText(context, "listItem : "+listItem, Toast.LENGTH_SHORT).show();
	       
	        
			//Toast.makeText(context, selectResponse, Toast.LENGTH_SHORT).show();
			//return responseList;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        //return null;
	}
}