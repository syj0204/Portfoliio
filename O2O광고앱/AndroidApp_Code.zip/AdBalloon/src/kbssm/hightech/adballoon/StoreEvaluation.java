package kbssm.hightech.adballoon;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class StoreEvaluation extends Activity{
	
	private MyCustomAdapter dataAdapter = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.store_evaluation);
		
		Button write = (Button)findViewById(R.id.write_evaluation);
		write.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(getApplicationContext(), WriteEvaluation.class);
				startActivity(intent);
			}
		});
		
		displayListView();
	}
	
	private void displayListView() {
		 
		  //Array list of countries
		  ArrayList<Evaluation> evaluationList = new ArrayList<Evaluation>();
		  MyEvaluation.addEvaluationList(evaluationList);
		 
		  //create an ArrayAdaptar from the String Array
		  dataAdapter = new MyCustomAdapter(this,
		    R.layout.evaluation_info, evaluationList);
		  ListView listView = (ListView) findViewById(R.id.evaluation_list);
		  // Assign adapter to ListView
		  listView.setAdapter(dataAdapter);
		 
		  listView.setOnItemClickListener(new OnItemClickListener() {
		   public void onItemClick(AdapterView<?> parent, View view,
		     int position, long id) {
		    // When clicked, show a toast with the TextView text
		    Evaluation evaluation = (Evaluation) parent.getItemAtPosition(position);
		    Toast.makeText(getApplicationContext(),
		      "Clicked on Row: " + evaluation.getName(), 
		      Toast.LENGTH_SHORT).show();
		    
		    /*if(evaluation.getCode().equals("1000")){
		    	Intent evaluationPage = new Intent(getApplicationContext(), Sto.class);
		    	startActivity(storePage);
		    }*/
		    
		    /*MySubCategory dialog = new MySubCategory(MyCategory.this, category.getCategory());
			dialog.show();*/
		   }
		  });
	 }
	
	private class MyCustomAdapter extends ArrayAdapter<Evaluation> {
		 
		  private ArrayList<Evaluation> evaluationList;
		 
		  public MyCustomAdapter(Context context, int textViewResourceId, 
		    ArrayList<Evaluation> evaluationList) {
		   super(context, textViewResourceId, evaluationList);
		   this.evaluationList = new ArrayList<Evaluation>();
		   this.evaluationList.addAll(evaluationList);
		  }
		 
		  private class ViewHolder {
		   TextView name;
		   RatingBar ratingBar;
		   TextView content;
		   ImageView image;
		  }
		 
		  @Override
		  public View getView(int position, View convertView, ViewGroup parent) {
		 
			   ViewHolder holder = null;
			   Log.v("ConvertView", String.valueOf(position));
			 
			   if (convertView == null) {
				   LayoutInflater vi = (LayoutInflater)getSystemService(
				     Context.LAYOUT_INFLATER_SERVICE);
				   convertView = vi.inflate(R.layout.evaluation_info, null);
				 
				   holder = new ViewHolder();
				   holder.name = (TextView) convertView.findViewById(R.id.name);
				   holder.ratingBar = (RatingBar) convertView.findViewById(R.id.rating);
				   holder.content = (TextView) convertView.findViewById(R.id.content);
				   holder.image = (ImageView) convertView.findViewById(R.id.image);
				   //holder.name = (CheckBox) convertView.findViewById(R.id.checkBox1);
				   convertView.setTag(holder);
			   } else {
				   holder = (ViewHolder) convertView.getTag();
			   }
		 
			   Evaluation evaluation = evaluationList.get(position);
			   holder.name.setText(evaluation.getName());
			   holder.ratingBar.setRating(evaluation.getRating());
			   holder.content.setText(evaluation.getContent());
			   holder.image.setImageDrawable(evaluation.getImage());
			   /*holder.name.setText(category.getSub());
			   holder.name.setChecked(category.isSelected());
			   holder.name.setTag(category);*/
		 
			   return convertView;
		 
		  }
	 }
	
	private static class MyEvaluation{
		 protected static final String PERSON1 = "1";
		 protected static final String PERSON2 = "2";
		 protected static final String PERSON3 = "3";
		 
		 protected static final String[] NameList = 
			 {PERSON1, PERSON2, PERSON3};
		 protected static final String[] ContentList = 
			 {"����", "����", "����"};
		 
		 protected static void addEvaluationList(ArrayList<Evaluation> evaluationList){
			 if(evaluationList != null){
				 for(int i=0;i<NameList.length;i++){
					 evaluationList.add(new Evaluation(NameList[i], 4, ContentList[i], null));
				 }
			 }
		 }
	 }
}