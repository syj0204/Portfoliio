package ad;

public class Ad {
	
	private int adcode;
	private String adname;
	private String adwriter;
	private int brandcode;
	private int branchcode;
	private String adimagepath;
	
	public int getAdcode() {
		return adcode;
	}
	public void setAdcode(int adcode) {
		this.adcode = adcode;
	}
	public String getAdname() {
		return adname;
	}
	public void setAdname(String adname) {
		this.adname = adname;
	}
	public String getAdwriter() {
		return adwriter;
	}
	public void setAdwriter(String adwriter) {
		this.adwriter = adwriter;
	}
	public int getBrandcode() {
		return brandcode;
	}
	public void setBrandcode(int brandcode) {
		this.brandcode = brandcode;
	}
	public int getBranchcode() {
		return branchcode;
	}
	public void setBranchcode(int branchcode) {
		this.branchcode = branchcode;
	}
	public String getAdimagepath() {
		return adimagepath;
	}
	public void setAdimagepath(String adimagepath) {
		this.adimagepath = adimagepath;
	}
	
}
