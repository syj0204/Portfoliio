package member;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CustomerBean {
	// �����ͺ��̽� ������� ���� ����
	Connection conn = null;
	PreparedStatement pstmt = null;

	// �����ͺ��̽� ������������� ���ڿ��� ����
	String jdbc_driver = "oracle.jdbc.driver.OracleDriver";
	String jdbc_url = "jdbc:oracle:thin:@localhost:1521:orcl";

	// �����ͺ��̽� ���� �޼���
	void connect() {
		// JDBC ����̹� �ε�
		try {
			Class.forName(jdbc_driver);
			// �����ͺ��̽� ���������� �̿��� Connection �ν��Ͻ� Ȯ��
			conn = DriverManager.getConnection(jdbc_url, "kon", "kon");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// �����ͺ��̽� ���� ���� �޼���
	void disconnect() {
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// �Ϲݰ���ȸ�� ���� ���(ȸ������)
	public boolean insertDB(Customer customer) throws SQLException {
		connect();
		
		String strSQL = "select * from customer_member";
		PreparedStatement pstmt1 = conn.prepareStatement(strSQL, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
		ResultSet rs = pstmt1.executeQuery();
		rs.last();
		//System.out.println(rs.getString("customer_id"));

		/*String strSQL = "select last(customer_id) from customer_member";
		PreparedStatement pstmt1 = conn.prepareStatement(strSQL);
		ResultSet rs = pstmt1.executeQuery();
		rs.next();*/
		String customer_id = rs.getString("customer_id");
		int num = Integer.parseInt(customer_id.substring(11)) + 2;
		System.out.println("abc   "+num + "  " + customer.getName());

		String sql = "insert into customer_member(customer_id,name,age,phone,facebookid,googleid,kakaoid) values(?,?,?,?,?,?,?)";
		System.out.println("�ǳĵǳĵǳ�1???   "+num);
		try {
			System.out.println("�ǳĵǳĵǳ�2???   "+num);
			pstmt = conn.prepareStatement(sql);
			System.out.println("�ǳĵǳĵǳ�3???   "+num);
			pstmt.setString(1, "customer_id" + num);
			System.out.println("�ǳĵǳĵǳ�4???   "+num);
			pstmt.setString(2, customer.getName());
			System.out.println("�ǳĵǳĵǳ�5???   "+num);
			pstmt.setInt(3, customer.getAge());
			System.out.println("�ǳĵǳĵǳ�6???   "+num);
			pstmt.setString(4, customer.getPhone());
			System.out.println("�ǳĵǳĵǳ�7???   "+num);
			pstmt.setString(5, customer.getFacebookid());
			System.out.println("�ǳĵǳĵǳ�8 ---- ???   "+customer.getGoogleid());
			pstmt.setString(6, customer.getGoogleid());
			System.out.println("�ǳĵǳĵǳ�9???   "+num);
			pstmt.setString(7, customer.getKakaoid());
			System.out.println("�ǳĵǳĵǳ�10???   "+num);
			pstmt.executeUpdate();
			System.out.println("�ǳĵǳĵǳ�11???   "+num);
			
			System.out.println("�ǳĵǳĵǳ�12???   "+num);
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	/*
	 * ȸ�� ���� ���(ȸ������) public boolean insertDB(Member member) { connect();
	 * 
	 * String sql =
	 * "insert into member(id,pw,name,phone,email,title) values(?,?,?,?,?,?)";
	 * 
	 * try { pstmt = conn.prepareStatement(sql); pstmt.setString(1,
	 * member.getId()); pstmt.setString(2, member.getPw()); pstmt.setString(3,
	 * member.getName()); pstmt.setString(4, member.getPhone());
	 * pstmt.setString(5, member.getEmail()); pstmt.setString(6, "marketer");//
	 * ���� �߰��ؾ�~~, �� title�� �������� pstmt.executeUpdate(); } catch (SQLException e)
	 * { e.printStackTrace(); return false; } finally { disconnect(); } return
	 * true; }
	 */

	/*
	 * ȸ�� ���� ���(ȸ������) public boolean insertDB(Member member) { connect();
	 * 
	 * String sql = "insert into member(id,pw,name) values(?,?,?)";
	 * 
	 * try { pstmt = conn.prepareStatement(sql); pstmt.setString(1,
	 * member.getId()); pstmt.setString(2, member.getPw()); pstmt.setString(3,
	 * member.getName());// ���� �߰��ؾ�~~, �� title�� �������� pstmt.executeUpdate(); }
	 * catch (SQLException e) { e.printStackTrace(); return false; } finally {
	 * disconnect(); } return true; }
	 */

	// �Ϲݰ���ȸ�� ���� �Ѱ� ��ȸ
	public Customer getDB(String customer_id) {
		connect();

		String sql = "select * from customer_member where customer_id=?";
		Customer customer = new Customer();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, customer_id);
			ResultSet rs = pstmt.executeQuery();

			rs.next();
			customer.setCustomer_id(customer_id);
			customer.setName(rs.getString("name"));
			customer.setAge(rs.getInt("age"));
			customer.setPhone(rs.getString("phone"));
			customer.setFacebookid(rs.getString("facebookid"));
			customer.setGoogleid(rs.getString("googleid"));
			customer.setKakaoid(rs.getString("kakaoid"));
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return customer;
	}

	// �Ϲݰ���ȸ�� ���� ��ü ��ȸ
	public ArrayList<Customer> getDBList() {
		connect();

		ArrayList<Customer> datas = new ArrayList<Customer>();

		String sql = "select * from customer_member";
		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Customer customer = new Customer();
				customer.setCustomer_id(rs.getString("customer_id"));
				customer.setName(rs.getString("name"));
				customer.setPhone(rs.getString("phone"));
				customer.setFacebookid(rs.getString("facebookid"));
				customer.setGoogleid(rs.getString("googleid"));
				customer.setKakaoid(rs.getString("googleid"));
				datas.add(customer);
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		// ó���� ���� ArrayList �� ������.
		return datas;
	}

	// �Ϲݰ���ȸ�� ���� �Ѱ� ������Ʈ
	public boolean updateDB(Customer customer) {
		connect();

		String sql = "update customer_member set name=?, age=?, phone=?, facebookid=?, googleid=?, kakaoid=? where customer_id=?";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, customer.getName());
			pstmt.setInt(2, customer.getAge());
			pstmt.setString(3, customer.getPhone());
			pstmt.setString(4, customer.getFacebookid());
			pstmt.setString(5, customer.getGoogleid());
			pstmt.setString(6, customer.getKakaoid());
			pstmt.setString(7, customer.getCustomer_id());

			pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	// �Ϲݰ���ȸ�� ���� �Ѱ� ����
	public boolean deleteDB(String customer_id) {
		connect();

		String sql = "delete from customer_member where customer_id=?";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, customer_id);
			pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	/*
	 * // ȸ�� ���� ��� ���� ����(���̵�ã��, �ߺ�Ȯ�� ��) public boolean getDBInfo(String name,
	 * String idnum) { connect();
	 * 
	 * String sql = "select * from member where name=? and idnum=?"; Member
	 * member = new Member();
	 * 
	 * try { pstmt = conn.prepareStatement(sql); pstmt.setString(1, name);
	 * pstmt.setString(2, idnum); ResultSet rs = pstmt.executeQuery();
	 * 
	 * if (rs != null) return true; else return false;
	 * 
	 * rs.next(); member.setName(rs.getString("name"));
	 * member.setIdnum(rs.getString("idnum"));
	 * member.setEmail(rs.getString("email")); member.setId(rs.getString("id"));
	 * member.setPw(rs.getString("pw")); member.setPhone(rs.getString("phone"));
	 * member.setTitle(rs.getString("title"));// ���� �߰��ؾ�~~ rs.close(); } catch
	 * (SQLException e) { e.printStackTrace(); return false; } finally {
	 * disconnect(); } return true; }
	 */

	// ȸ�� ���� ��� ���� ����(���̵�ã��, �ߺ�Ȯ�� ��)
	/*
	 * public boolean getDBInfo(String name, String idnum) throws SQLException {
	 * connect();
	 * 
	 * String sql = "select * from member where name=? and idnum=?";
	 * 
	 * pstmt = conn.prepareStatement(sql); pstmt.setString(1, name);
	 * pstmt.setString(2, idnum); ResultSet rs = pstmt.executeQuery();
	 * 
	 * if (rs != null) return true; else return false; }
	 */

	// ȸ�� ���� ��� ���� ����(���̵�ã��, �ߺ�Ȯ�� ��)
	/*
	 * public boolean getDBInfo2(String id, String idnum) throws SQLException {
	 * connect();
	 * 
	 * String sql = "select * from member where id=? and idnum=?";
	 * 
	 * pstmt = conn.prepareStatement(sql); pstmt.setString(1, id);
	 * pstmt.setString(2, idnum); ResultSet rs = pstmt.executeQuery();
	 * 
	 * if (rs != null) return true; else return false; }
	 */

	// �Ϲݰ���ȸ�� ���� ��� ���� ����(���̵�ã��, �ߺ�Ȯ�� ��)
	public String getIDInfo(String phone) throws SQLException {
		connect();

		String sql = "select * from customer_member where phone=?";

		String marketer_id = null;
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, phone);
		ResultSet rs = pstmt.executeQuery();

		if (rs != null) {
			while (rs.next()) {
				marketer_id = rs.getString("marketer_id");
			}
			return marketer_id;
		} else
			return null;
	}

	public boolean isExist(String phone, String name) throws SQLException {
		connect();
		String sql = "select * from customer_member where name=? and phone=?";

		boolean result = false;
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, name);
		pstmt.setString(2, phone);
		ResultSet rs = pstmt.executeQuery();

		if (rs != null) {
			result = true;
		} else
			result = false;

		return result;
	}

	public boolean fbIdIsExist(String facebookid) throws SQLException {
		connect();
		String sql = "select * from customer_member where facebookid=?";
		String customer_id = null;

		boolean result = false;
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, facebookid);
		ResultSet rs = pstmt.executeQuery();

		if (rs != null) {
			while (rs.next()) {
				customer_id = rs.getString("customer_id");
			}
		}
		if (customer_id == null)
			result = false;
		else
			result = true;
		return result;
	}

	public boolean ggIdIsExist(String googleid) throws SQLException {
		System.out.println("why not in/?/????--- " + googleid);
		
		connect();
		String sql = "select * from customer_member where googleid=?";
		String customer_id = null;

		System.out.println("exist--- " + googleid);
		
		boolean result = false;
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, googleid);
		ResultSet rs = pstmt.executeQuery();

		if (rs != null) {
			while (rs.next()) {
				customer_id = rs.getString("customer_id");
			}
		}
		if (customer_id == null)
			result = false;
		else if (customer_id.equals(""))
			result = false;
		else
			result = true;
		return result;
	}

	public boolean kkoIdIsExist(String kakaoid) throws SQLException {
		connect();
		String sql = "select * from customer_member where kakaoid=?";
		String customer_id = null;

		boolean result = false;
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, kakaoid);
		ResultSet rs = pstmt.executeQuery();

		if (rs != null) {
			while (rs.next()) {
				customer_id = rs.getString("customer_id");
			}
		}
		if (customer_id == null)
			result = false;
		else
			result = true;
		return result;
	}

	// ��Ͼ��̵�� ���վ��̵� ����
	public String getIDthFBID(String facebookid) throws SQLException {
		connect();

		String sql = "select * from customer_member where facebookid=?";
		String customer_id = null;

		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, facebookid);
		ResultSet rs = pstmt.executeQuery();

		if (rs != null) {
			while (rs.next()) {
				customer_id = rs.getString("customer_id");
			}
			return customer_id;
		} else
			return null;
	}

	// īī�����̵�� ���վ��̵� ����
	public String getIDthKKOID(String kakaoid) throws SQLException {
		connect();

		String sql = "select * from customer_member where kakaoid=?";
		String customer_id = null;

		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, kakaoid);
		ResultSet rs = pstmt.executeQuery();

		if (rs != null) {
			while (rs.next()) {
				customer_id = rs.getString("customer_id");
			}
			return customer_id;
		} else
			return null;
	}

	// ���۾��̵�� ���վ��̵� ����
	public String getIDthGGID(String googleid) throws SQLException {
		connect();

		String sql = "select * from customer_member where googleid=?";
		String customer_id = null;

		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, googleid);
		ResultSet rs = pstmt.executeQuery();

		if (rs != null) {
			while (rs.next()) {
				customer_id = rs.getString("customer_id");
			}
			return customer_id;
		} else
			return null;
	}

}
