package login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MemberBean {
	// �����ͺ��̽� ������� ���� ����
	Connection conn = null;
	PreparedStatement pstmt = null;

	// �����ͺ��̽� ������������� ���ڿ��� ����
	String jdbc_driver = "oracle.jdbc.driver.OracleDriver";
	String jdbc_url = "jdbc:oracle:thin:@localhost:1521:orcl";

	// �����ͺ��̽� ���� �޼���
	void connect() {
		// JDBC ����̹� �ε�
		try {
			Class.forName(jdbc_driver);
			// �����ͺ��̽� ���������� �̿��� Connection �ν��Ͻ� Ȯ��
			conn = DriverManager.getConnection(jdbc_url, "kon", "kon");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// �����ͺ��̽� ���� ���� �޼���
	void disconnect() {
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// ȸ�� ���� ���(ȸ������)
	public boolean insertDB(Member member) throws SQLException {
		connect();
		
		String strSQL = "select last(id) from member";
		PreparedStatement pstmt1 = conn.prepareStatement(strSQL);
		ResultSet rs = pstmt1.executeQuery();
		rs.next();
		String id = rs.getString("id");
		int  num = Integer.parseInt(id.substring(2)) + 1;

		String sql = "insert into member(id,pw,name,age,phone,title,facebookid,googleid,kakaoid,companynumber) values(?,?,?,?,?,?,?,?,?,?)";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "id"+num);
			pstmt.setString(2, member.getPw());
			pstmt.setString(3, member.getName());
			pstmt.setInt(4, member.getAge());
			pstmt.setString(5, member.getPhone());
			pstmt.setString(6, member.getTitle());
			pstmt.setString(7, member.getFacebookid());
			pstmt.setString(8, member.getGoogleid());
			pstmt.setString(9, member.getKakaoid());
			pstmt.setString(10, member.getCompanynumber());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}
	
	/*ȸ�� ���� ���(ȸ������)
		public boolean insertDB(Member member) {
			connect();

			String sql = "insert into member(id,pw,name,phone,email,title) values(?,?,?,?,?,?)";

			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, member.getId());
				pstmt.setString(2, member.getPw());
				pstmt.setString(3, member.getName());
				pstmt.setString(4, member.getPhone());
				pstmt.setString(5, member.getEmail());
				pstmt.setString(6, "marketer");// ���� �߰��ؾ�~~, �� title�� ��������
				pstmt.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			} finally {
				disconnect();
			}
			return true;
		}*/

	/*
	 * ȸ�� ���� ���(ȸ������) public boolean insertDB(Member member) { connect();
	 * 
	 * String sql = "insert into member(id,pw,name) values(?,?,?)";
	 * 
	 * try { pstmt = conn.prepareStatement(sql); pstmt.setString(1,
	 * member.getId()); pstmt.setString(2, member.getPw()); pstmt.setString(3,
	 * member.getName());// ���� �߰��ؾ�~~, �� title�� �������� pstmt.executeUpdate(); }
	 * catch (SQLException e) { e.printStackTrace(); return false; } finally {
	 * disconnect(); } return true; }
	 */

	// ȸ�� ���� �Ѱ� ��ȸ
	public Member getDB(String id) {
		connect();

		String sql = "select * from member where id=?";
		Member member = new Member();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();

			rs.next();
			member.setPw(rs.getString("pw"));
			member.setName(rs.getString("name"));
			member.setAge(rs.getInt("age"));
			member.setPhone(rs.getString("phone"));
			member.setTitle(rs.getString("title"));
			member.setFacebookid(rs.getString("facebookid"));
			member.setGoogleid(rs.getString("googleid"));
			member.setKakaoid(rs.getString("kakaoid"));
			member.setCompanynumber(rs.getString("companynumber"));
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return member;
	}

	// ȸ�� ���� ��ü ��ȸ
	public ArrayList<Member> getDBList() {
		connect();

		ArrayList<Member> datas = new ArrayList<Member>();

		String sql = "select * from member order by membercode desc";
		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Member member = new Member();
				member.setPw(rs.getString("pw"));
				member.setName(rs.getString("name"));
				member.setAge(rs.getInt("age"));
				member.setPhone(rs.getString("phone"));
				member.setTitle(rs.getString("title"));
				member.setFacebookid(rs.getString("facebookid"));
				member.setGoogleid(rs.getString("googleid"));
				member.setKakaoid(rs.getString("kakaoid"));
				member.setCompanynumber(rs.getString("companynumber"));
				datas.add(member);
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		// ó���� ���� ArrayList �� ������.
		return datas;
	}

	// ȸ�� ���� �Ѱ� ������Ʈ
	public boolean updateDB(Member member) {
		connect();

		String sql = "update member set pw=?, name=?, age=?, phone=?, title=?, facebookid=?, googleid=?, kakaoid=?, companynumber=? where id=?";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.getPw());
			pstmt.setString(2, member.getName());
			pstmt.setInt(3, member.getAge());
			pstmt.setString(4, member.getPhone());
			pstmt.setString(5, member.getTitle());
			pstmt.setString(6, member.getFacebookid());
			pstmt.setString(7, member.getGoogleid());
			pstmt.setString(8, member.getKakaoid());
			pstmt.setString(9, member.getCompanynumber());
			pstmt.setString(10, member.getId());
			
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	// ȸ�� ���� �Ѱ� ����
	public boolean deleteDB(String id) {
		connect();

		String sql = "delete from member where id=?";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	/*
	 * // ȸ�� ���� ��� ���� ����(���̵�ã��, �ߺ�Ȯ�� ��) public boolean getDBInfo(String name,
	 * String idnum) { connect();
	 * 
	 * String sql = "select * from member where name=? and idnum=?"; Member
	 * member = new Member();
	 * 
	 * try { pstmt = conn.prepareStatement(sql); pstmt.setString(1, name);
	 * pstmt.setString(2, idnum); ResultSet rs = pstmt.executeQuery();
	 * 
	 * if (rs != null) return true; else return false;
	 * 
	 * rs.next(); member.setName(rs.getString("name"));
	 * member.setIdnum(rs.getString("idnum"));
	 * member.setEmail(rs.getString("email")); member.setId(rs.getString("id"));
	 * member.setPw(rs.getString("pw")); member.setPhone(rs.getString("phone"));
	 * member.setTitle(rs.getString("title"));// ���� �߰��ؾ�~~ rs.close(); } catch
	 * (SQLException e) { e.printStackTrace(); return false; } finally {
	 * disconnect(); } return true; }
	 */

	// ȸ�� ���� ��� ���� ����(���̵�ã��, �ߺ�Ȯ�� ��)
	/*
	 * public boolean getDBInfo(String name, String idnum) throws SQLException {
	 * connect();
	 * 
	 * String sql = "select * from member where name=? and idnum=?";
	 * 
	 * pstmt = conn.prepareStatement(sql); pstmt.setString(1, name);
	 * pstmt.setString(2, idnum); ResultSet rs = pstmt.executeQuery();
	 * 
	 * if (rs != null) return true; else return false; }
	 */

	// ȸ�� ���� ��� ���� ����(���̵�ã��, �ߺ�Ȯ�� ��)
	/*
	 * public boolean getDBInfo2(String id, String idnum) throws SQLException {
	 * connect();
	 * 
	 * String sql = "select * from member where id=? and idnum=?";
	 * 
	 * pstmt = conn.prepareStatement(sql); pstmt.setString(1, id);
	 * pstmt.setString(2, idnum); ResultSet rs = pstmt.executeQuery();
	 * 
	 * if (rs != null) return true; else return false; }
	 */

	// ȸ�� ���� ��� ���� ����(���̵�ã��, �ߺ�Ȯ�� ��) -> ��� �ٽ� ������ ��
	public String getIDInfo(String name, String companynumber) throws SQLException {
		connect();

		String sql = "select * from member where name=? and companynumber=?"; //���̵� ã�� ��� �ٽ� ������ ��
		String id = null;

		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, name);
		pstmt.setString(2, companynumber);
		ResultSet rs = pstmt.executeQuery();

		if (rs != null) {
			while (rs.next()) {
				id = rs.getString("id");
			}
			return id;
		} else
			return null;
	}

	// ��й�ȣ ã��
	public String getPWInfo(String id, String companynumber) throws SQLException {
		connect();

		String sql = "select * from member where id=? and companynumber=?";
		String pw = null;

		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		pstmt.setString(2, companynumber);
		ResultSet rs = pstmt.executeQuery();

		if (rs != null) {
			while (rs.next()) {
				pw = rs.getString("pw");
			}
			return pw;
		} else
			return null;
	}
	
    // �α��� ó��
	public boolean loginControl(String id, String pw) throws SQLException {
		connect();

		String sql = "select * from member where id=?";
		boolean result = false;

		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		ResultSet rs = pstmt.executeQuery();
		if (rs != null) {
			while (rs.next()) {
				if (rs.getString("pw").equals(pw))
					result = true;
				else
					result = false;
			}
		}
		// if (rs != null) return true;
		// else return false;
		return result;
	}

}
