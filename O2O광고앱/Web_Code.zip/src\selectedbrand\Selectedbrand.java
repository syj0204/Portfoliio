package selectedbrand;

public class Selectedbrand {
	
	private String customer_id;
	private int brandcode;
	
	public int getBrandcode() {
		return brandcode;
	}
	public void setBrandcode(int brandcode) {
		this.brandcode = brandcode;
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
}
