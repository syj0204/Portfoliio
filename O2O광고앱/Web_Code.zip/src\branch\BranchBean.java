package branch;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class BranchBean {
	// �����ͺ��̽� ������� ���� ����
	Connection conn = null;
	PreparedStatement pstmt = null;

	// �����ͺ��̽� ������������� ���ڿ��� ����
	String jdbc_driver = "oracle.jdbc.driver.OracleDriver";
	String jdbc_url = "jdbc:oracle:thin:@localhost:1521:orcl";

	// �����ͺ��̽� ���� �޼���
	void connect() {
		// JDBC ����̹� �ε�
		try {
			Class.forName(jdbc_driver);
			// �����ͺ��̽� ���������� �̿��� Connection �ν��Ͻ� Ȯ��
			conn = DriverManager.getConnection(jdbc_url, "kon", "kon");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// �����ͺ��̽� ���� ���� �޼���
	void disconnect() {
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// ���� ���� ���
	public boolean insertDB(Branch branch) {
		connect();

		String sql = "insert into branch(branchcode,branchname,brandcode,branchhost,macaddress,branchaddress,branchphone,branchimagepath,branchwriter,score) values(branch_seq.nextval,?,?,?,?,?,?,?,?,?)";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, branch.getBranchname());// ���� ��� ���� �����ؾ�~~ �ڵ� �ٽ�
														// �ۼ��� ��
			pstmt.setInt(2, branch.getBrandcode());// brandcode set�� �� get
			pstmt.setString(3, branch.getBranchhost());
			pstmt.setString(4, branch.getMacaddress());
			pstmt.setString(5, branch.getBranchaddress());
			pstmt.setString(6, branch.getBranchphone());
			pstmt.setString(7, branch.getBranchimagepath());// �̹��� ���ε� ��� �ϴ� ��
															// �˾ƺ� ��
			pstmt.setString(8, branch.getBranchwriter());// id�� session �Ӽ���
			pstmt.setString(9, branch.getScore());
			// set�� �� get
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	// ���� ���� �Ѱ� ��ȸ
	public Branch getDB(int branchcode) {
		connect();

		String sql = "select * from branch where branchcode=?";
		Branch branch = new Branch();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, branchcode);
			ResultSet rs = pstmt.executeQuery();

			rs.next();
			branch.setBranchcode(branchcode);
			branch.setBranchname(rs.getString("branchname"));
			branch.setBrandcode(rs.getInt("brandcode"));
			branch.setBranchhost(rs.getString("branchhost"));
			branch.setMacaddress(rs.getString("macaddress"));
			branch.setBranchaddress(rs.getString("branchaddress"));
			branch.setBranchphone(rs.getString("branchphone"));
			branch.setBranchimagepath(rs.getString("branchimagepath"));
			branch.setBranchwriter(rs.getString("branchwriter"));
			branch.setScore(rs.getString("score"));
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return branch;
	}

	// ���� ���� ��ü ��ȸ
	public ArrayList<Branch> getDBList() {
		connect();

		ArrayList<Branch> datas = new ArrayList<Branch>();

		String sql = "select * from branch order by branchcode";
		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Branch branch = new Branch();
				branch.setBranchcode(rs.getInt("branchcode"));
				branch.setBranchname(rs.getString("branchname"));
				branch.setBrandcode(rs.getInt("brandcode"));
				branch.setBranchhost(rs.getString("branchhost"));
				branch.setMacaddress(rs.getString("macaddress"));
				branch.setBranchaddress(rs.getString("branchaddress"));
				branch.setBranchphone(rs.getString("branchphone"));
				branch.setBranchimagepath(rs.getString("branchimagepath"));
				branch.setBranchwriter(rs.getString("branchwriter"));
				branch.setScore(rs.getString("score"));
				datas.add(branch);
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		// ó���� ���� ArrayList �� ������.
		return datas;
	}

	// ���� ���� ��ü ��ȸ
	public ArrayList<Branch> getDBList(String marketer_id) {
		connect();

		ArrayList<Branch> datas = new ArrayList<Branch>();

		String sql = "select * from branch where branchwriter=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, marketer_id);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Branch branch = new Branch();
				branch.setBranchcode(rs.getInt("branchcode"));
				branch.setBranchname(rs.getString("branchname"));
				branch.setBrandcode(rs.getInt("brandcode"));
				branch.setBranchhost(rs.getString("branchhost"));
				branch.setMacaddress(rs.getString("macaddress"));
				branch.setBranchaddress(rs.getString("branchaddress"));
				branch.setBranchphone(rs.getString("branchphone"));
				branch.setBranchimagepath(rs.getString("branchimagepath"));
				branch.setBranchwriter(marketer_id);
				branch.setScore(rs.getString("score"));
				datas.add(branch);
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		// ó���� ���� ArrayList �� ������.
		return datas;
	}

	// Ư�� �귣���� ���� ���� ��ü ��ȸ
	public ArrayList<Branch> getBranchList(int brandcode) {
		connect();

		ArrayList<Branch> datas = new ArrayList<Branch>();

		String sql = "select * from branch where brandcode=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, brandcode);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Branch branch = new Branch();
				branch.setBranchcode(rs.getInt("branchcode"));
				branch.setBranchname(rs.getString("branchname"));
				branch.setBrandcode(rs.getInt("brandcode"));
				branch.setBranchhost(rs.getString("branchhost"));
				branch.setMacaddress(rs.getString("macaddress"));
				branch.setBranchaddress(rs.getString("branchaddress"));
				branch.setBranchphone(rs.getString("branchphone"));
				branch.setBranchimagepath(rs.getString("branchimagepath"));
				branch.setBranchwriter(rs.getString("branchwriter"));
				branch.setScore(rs.getString("score"));
				datas.add(branch);
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		// ó���� ���� ArrayList �� ������.
		return datas;
	}

	/*
	 * �־��� macaddress�� �ش��ϴ� ���� ���� ��ü ��ȸ public ArrayList<Branch>
	 * getBranchList(String macaddress) { connect();
	 * 
	 * ArrayList<Branch> datas = new ArrayList<Branch>();
	 * 
	 * String sql = "select * from branch where macaddress=?"; try { pstmt =
	 * conn.prepareStatement(sql); pstmt.setString(1, macaddress); ResultSet rs
	 * = pstmt.executeQuery();
	 * 
	 * while (rs.next()) { Branch branch = new Branch();
	 * branch.setBranchcode(rs.getInt("branchcode"));
	 * branch.setBranchname(rs.getString("branchname"));
	 * branch.setBrandcode(rs.getInt("brandcode"));
	 * branch.setBranchhost(rs.getString("branchhost"));
	 * branch.setMacaddress(rs.getString("macaddress"));
	 * branch.setBranchaddress(rs.getString("branchaddress"));
	 * branch.setBranchphone(rs.getString("branchphone"));
	 * branch.setBranchimagepath(rs.getString("branchimagepath"));
	 * branch.setBranchwriter(rs.getString("branchwriter")); datas.add(branch);
	 * } rs.close();
	 * 
	 * } catch (SQLException e) { e.printStackTrace(); } finally { disconnect();
	 * } // ó���� ���� ArrayList �� ������. return datas; }
	 */

	// �־��� macaddress�� �ش��ϴ� ���� ���� ��ü ��ȸ
	public Branch getDB(String macaddress) {
		connect();

		String sql = "select * from branch where macaddress=?";
		Branch branch = new Branch();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, macaddress);
			ResultSet rs = pstmt.executeQuery();

			rs.next();
			branch.setBranchcode(rs.getInt("branchcode"));
			branch.setBranchname(rs.getString("branchname"));
			branch.setBrandcode(rs.getInt("brandcode"));
			branch.setBranchhost(rs.getString("branchhost"));
			branch.setMacaddress(macaddress);
			branch.setBranchaddress(rs.getString("branchaddress"));
			branch.setBranchphone(rs.getString("branchphone"));
			branch.setBranchimagepath(rs.getString("branchimagepath"));
			branch.setBranchwriter(rs.getString("branchwriter"));
			branch.setScore(rs.getString("score"));
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return branch;
	}

	// ���� ���� �Ѱ� ������Ʈ
	public boolean updateDB(Branch branch) {
		connect();

		String sql = "update branch set branchname=?, brandcode=?, branchhost=?, macaddress=?, branchaddress=?, branchphone=?, branchimagepath=?, branchwriter=?, score=? where branchcode=?";

		System.out.println("sql seq " + sql);

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, branch.getBranchname());
			pstmt.setInt(2, branch.getBrandcode());
			pstmt.setString(3, branch.getBranchhost());
			pstmt.setString(4, branch.getMacaddress());
			pstmt.setString(5, branch.getBranchaddress());
			pstmt.setString(6, branch.getBranchphone());
			pstmt.setString(7, branch.getBranchimagepath());
			pstmt.setString(8, branch.getBranchwriter());
			pstmt.setString(9, branch.getScore());
			pstmt.setInt(10, branch.getBranchcode());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	// ���� ���� �Ѱ� ����
	public boolean deleteDB(int branchcode) {
		connect();

		String sql = "delete from branch where branchcode=?";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, branchcode);
			pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	// �����̸� �ߺ� Ȯ��
	public Boolean isBranchExist(String branchname, int brandcode)
			throws SQLException {
		connect();

		String sql = "select * from branch where brandcode=?";
		boolean result = false;

		pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, brandcode);
		ResultSet rs = pstmt.executeQuery();

		if (rs != null) {
			while (rs.next()) {
				if (rs.getString("branchname").equals(branchname))
					result = true;
				else
					result = false;
			}
		}
		return result;
	}

	// �ش� ���ּҰ� �ִ� ���� ���� Ȯ��
	public Boolean isBranchExist(String macaddress) throws SQLException {
		connect();

		String sql = "select * from branch where macaddress=?";
		boolean result = false;

		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, macaddress);
		ResultSet rs = pstmt.executeQuery();
		
		if (rs != null){
			while (rs.next()) {
				if (rs.getString("macaddress").equals(macaddress))
					result = true;
				else
					result = false;
			}
		}
		return result;
	}

	// Ư�� ������ �귣���ڵ� ��ȸ
	public int getBrandcode(int branchcode) throws SQLException {
		connect();

		String sql = "select * from branch where branchcode=?";
		int brandcode = 0;

		pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, branchcode);
		ResultSet rs = pstmt.executeQuery();

		if (rs != null) {
			while (rs.next()) {
				brandcode = Integer.parseInt(rs.getString("brandcode"));
			}
			return brandcode;
		} else
			return 0;
	}

}
