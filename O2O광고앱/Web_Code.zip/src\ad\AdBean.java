package ad;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class AdBean {
	// �����ͺ��̽� ������� ���� ����
	Connection conn = null;
	PreparedStatement pstmt = null;

	// �����ͺ��̽� ������������� ���ڿ��� ����
	String jdbc_driver = "oracle.jdbc.driver.OracleDriver";
	String jdbc_url = "jdbc:oracle:thin:@localhost:1521:orcl";

	// �����ͺ��̽� ���� �޼���
	void connect() {
		// JDBC ����̹� �ε�
		try {
			Class.forName(jdbc_driver);
			// �����ͺ��̽� ���������� �̿��� Connection �ν��Ͻ� Ȯ��
			conn = DriverManager.getConnection(jdbc_url, "kon", "kon");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// �����ͺ��̽� ���� ���� �޼���
	void disconnect() {
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// ���� ���� ���
	public boolean insertDB(Ad ad) {
		connect();

		String sql = "insert into ad(adcode,adname,adwriter,brandcode,branchcode,adimagepath) values(ad_seq.nextval,?,?,?,?,?)";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, ad.getAdname());
			pstmt.setString(2, ad.getAdwriter());// id�� session �Ӽ��� set�� �� get
			pstmt.setInt(3, ad.getBrandcode());
			pstmt.setInt(4, ad.getBranchcode());
			pstmt.setString(5, ad.getAdimagepath());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	// ���� ���� �Ѱ� ��ȸ
	public Ad getDB(int adcode) {
		connect();

		String sql = "select * from ad where adcode=?";
		Ad ad = new Ad();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, adcode);
			ResultSet rs = pstmt.executeQuery();

			rs.next();
			ad.setAdcode(adcode);
			ad.setAdname(rs.getString("adname"));
			ad.setAdwriter(rs.getString("adwriter"));
			ad.setBrandcode(rs.getInt("brandcode"));
			ad.setBranchcode(rs.getInt("branchcode"));
			ad.setAdimagepath(rs.getString("adimagepath"));
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return ad;
	}

	// ���� ���� ��ü ��ȸ
	public ArrayList<Ad> getDBList() {
		connect();

		ArrayList<Ad> datas = new ArrayList<Ad>();

		String sql = "select * from ad order by adcode";
		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Ad ad = new Ad();
				ad.setAdcode(rs.getInt("adcode"));
				ad.setAdname(rs.getString("adname"));
				ad.setAdwriter(rs.getString("adwriter"));
				ad.setBrandcode(rs.getInt("brandcode"));
				ad.setBranchcode(rs.getInt("branchcode"));
				ad.setAdimagepath(rs.getString("adimagepath"));
				datas.add(ad);
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		// ó���� ���� ArrayList �� ������.
		return datas;
	}

	// ���� ���� �Ѱ� ������Ʈ
	public boolean updateDB(Ad ad) {
		connect();

		String sql = "update ad set adname=?, adwriter=?, brandcode=?, branchcode=?, adimagepath=? where adcode=?";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, ad.getAdname());
			pstmt.setString(2, ad.getAdwriter());
			pstmt.setInt(3, ad.getBrandcode());
			pstmt.setInt(4, ad.getBranchcode());
			pstmt.setString(5, ad.getAdimagepath());
			pstmt.setInt(6, ad.getAdcode());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	// ���� ���� �Ѱ� ����
	public boolean deleteDB(int adcode) {
		connect();

		String sql = "delete from ad where adcode=?";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, adcode);
			pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	public int getBrandCode(int adcode) throws SQLException {
		connect();

		String sql = "select * from ad where adcode=?";
		int brandcode = 0;

		pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, adcode);
		ResultSet rs = pstmt.executeQuery();

		if (rs != null) {
			while (rs.next()) {
				brandcode = rs.getInt("brandcode");
			}
			return brandcode;
		} else
			return 0;

	}

	// Ư�� ������ ���� ���� ��ü ��ȸ
	public ArrayList<Ad> getDBList(int branchcode) {
		connect();

		ArrayList<Ad> datas = new ArrayList<Ad>();

		String sql = "select * from ad where branchcode=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, branchcode);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Ad ad = new Ad();
				ad.setAdcode(rs.getInt("adcode"));
				ad.setAdname(rs.getString("adname"));
				ad.setAdwriter(rs.getString("adwriter"));
				ad.setBrandcode(rs.getInt("brandcode"));
				ad.setBranchcode(branchcode);
				ad.setAdimagepath(rs.getString("adimagepath"));
				datas.add(ad);
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		// ó���� ���� ArrayList �� ������.
		return datas;
	}

	// Ư�� �귣���� ���� ���� ��ü ��ȸ
	public ArrayList<Ad> getADList(int brandcode) {
		connect();

		ArrayList<Ad> datas = new ArrayList<Ad>();

		String sql = "select * from ad where brandcode=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, brandcode);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Ad ad = new Ad();
				ad.setAdcode(rs.getInt("adcode"));
				ad.setAdname(rs.getString("adname"));
				ad.setAdwriter(rs.getString("adwriter"));
				ad.setBrandcode(brandcode);
				ad.setBranchcode(rs.getInt("branchcode"));
				ad.setAdimagepath(rs.getString("adimagepath"));
				datas.add(ad);
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		// ó���� ���� ArrayList �� ������.
		return datas;
	}

	// Ư�� ������ ���� �ֱ� ���� ��ȸ
	public Ad getTheRecentAd(int brandcode) {
		connect();

		String sql = "select * from ad where brandcode=?";
		Ad ad = new Ad();

		try {

			pstmt = conn.prepareStatement(sql,
					ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_UPDATABLE);
			pstmt.setInt(1, brandcode);
			ResultSet rs = pstmt.executeQuery();
			rs.last();

			ad.setAdcode(rs.getInt("adcode"));
			ad.setAdname(rs.getString("adname"));
			ad.setAdwriter(rs.getString("adwriter"));
			ad.setBrandcode(brandcode);
			ad.setBranchcode(rs.getInt("branchcode"));
			ad.setAdimagepath(rs.getString("adimagepath"));
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		// ó���� ���� ArrayList �� ������.
		return ad;
	}

	// �����̸� �ߺ� Ȯ��
	public Boolean isAdExist(String adname, int brandcode, int branchcode)
			throws SQLException {
		connect();

		String sql = "select * from ad where adname=? and brandcode=? and branchcode=?";
		boolean result = false;

		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, adname);
		pstmt.setInt(2, brandcode);
		pstmt.setInt(3, branchcode);
		ResultSet rs = pstmt.executeQuery();

		if (rs != null) {
			while (rs.next()) {
				if (rs.getString("adname").equals(adname)
						&& rs.getInt("brandcode") == brandcode
						&& rs.getInt("branchcode") == branchcode)
					result = true;
				else
					result = false;
			}
		}
		return result;
	}
}
