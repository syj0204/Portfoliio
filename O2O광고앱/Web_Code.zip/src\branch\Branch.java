package branch;

public class Branch {
	
	private int branchcode;
	private String branchname;
	private int brandcode;
	private String branchhost;
	private String macaddress;
	private String branchaddress;
	private String branchphone;
	private String branchimagepath;
	private String branchwriter;
	private String score;
	
	public int getBranchcode() {
		return branchcode;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	public void setBranchcode(int branchcode) {
		this.branchcode = branchcode;
	}
	public String getBranchname() {
		return branchname;
	}
	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}
	public int getBrandcode() {
		return brandcode;
	}
	public void setBrandcode(int brandcode) {
		this.brandcode = brandcode;
	}
	public String getBranchhost() {
		return branchhost;
	}
	public void setBranchhost(String branchhost) {
		this.branchhost = branchhost;
	}
	public String getMacaddress() {
		return macaddress;
	}
	public void setMacaddress(String macaddress) {
		this.macaddress = macaddress;
	}
	public String getBranchaddress() {
		return branchaddress;
	}
	public void setBranchaddress(String branchaddress) {
		this.branchaddress = branchaddress;
	}
	public String getBranchphone() {
		return branchphone;
	}
	public void setBranchphone(String branchphone) {
		this.branchphone = branchphone;
	}
	public String getBranchimagepath() {
		return branchimagepath;
	}
	public void setBranchimagepath(String branchimagepath) {
		this.branchimagepath = branchimagepath;
	}
	public String getBranchwriter() {
		return branchwriter;
	}
	public void setBranchwriter(String branchwriter) {
		this.branchwriter = branchwriter;
	}
}
