package brand;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import category.CategoryBean;
import login.Member;

public class BrandBean {
	// �����ͺ��̽� ������� ���� ����
	Connection conn = null;
	PreparedStatement pstmt = null;

	// �����ͺ��̽� ������������� ���ڿ��� ����
	String jdbc_driver = "oracle.jdbc.driver.OracleDriver";
	String jdbc_url = "jdbc:oracle:thin:@localhost:1521:orcl";

	// �����ͺ��̽� ���� �޼���
	void connect() {
		// JDBC ����̹� �ε�
		try {
			Class.forName(jdbc_driver);
			// �����ͺ��̽� ���������� �̿��� Connection �ν��Ͻ� Ȯ��
			conn = DriverManager.getConnection(jdbc_url, "kon", "kon");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// �����ͺ��̽� ���� ���� �޼���
	void disconnect() {
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// �귣�� ���(ȸ������)
	public boolean insertDB(Brand brand) {
		connect();

		String sql = "insert into brand(brandcode,brandname,categorycode) values(brand_seq.nextval,?,?)";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, brand.getBrandname());
			pstmt.setInt(2, brand.getCategorycode());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	// �귣�� ���� �Ѱ� ��ȸ
	public Brand getDB(int brandcode) {
		connect();

		String sql = "select * from brand where brandcode=?";
		Brand brand = new Brand();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, brandcode);
			ResultSet rs = pstmt.executeQuery();

			rs.next();
			brand.setBrandcode(brandcode);
			brand.setBrandname(rs.getString("brandname"));
			brand.setCategorycode(rs.getInt("categorycode"));// control����������
																// Category Ŭ����
																// ����� ��ü ����
																// rs.getInt("categoryCode");����
																// �Ķ���ͷ� �Ѱ�
																// �귣����� ����� ��
																// �ֵ��� �� ��
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return brand;
	}

	// �귣�� ���� ��ü ��ȸ
	public ArrayList<Brand> getDBList() {
		connect();

		ArrayList<Brand> datas = new ArrayList<Brand>();

		String sql = "select * from brand";
		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Brand brand = new Brand();
				brand.setBrandcode(rs.getInt("brandcode"));
				brand.setBrandname(rs.getString("brandname"));
				brand.setCategorycode(rs.getInt("categorycode"));
				datas.add(brand);
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		// ó���� ���� ArrayList �� ������.
		return datas;
	}

	// Ư�� ī�װ��� ���� �귣�� ���� ��ü ��ȸ
	public ArrayList<Brand> getBrandListInCategory(int categorycode) {
		connect();

		ArrayList<Brand> datas = new ArrayList<Brand>();

		String sql = "select * from brand where categorycode=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, categorycode);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Brand brand = new Brand();
				brand.setBrandcode(rs.getInt("brandcode"));
				brand.setBrandname(rs.getString("brandname"));
				brand.setCategorycode(categorycode);
				datas.add(brand);
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		// ó���� ���� ArrayList �� ������.
		return datas;
	}

	// �귣���ڵ� ��ȸ
	public int getBrandCode(String brandname, int categorycode) {
		connect();

		String sql = "select * from brand where categorycode=?";
		int brandcode = 0;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, categorycode);
			ResultSet rs = pstmt.executeQuery();
			if (rs != null) {
				while (rs.next()) {
					if (rs.getString("brandname").equals(brandname))
						brandcode = rs.getInt("brandcode");
					else
						brandcode = 0;

				}
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return brandcode;
	}

	// ī�װ����ڵ� ��ȸ
	public int getCategoryCode(String brandname) {
		connect();

		String sql = "select * from brand where brandname=?";
		int categorycode = 0;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, brandname);
			ResultSet rs = pstmt.executeQuery();
			if (rs != null) {
				while (rs.next()) {
					categorycode = rs.getInt("categorycode");
				}
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return categorycode;
	}

	// ������ȸ�� ���̵� ã��
	public String getIDInfo(String name) throws SQLException {
		connect();

		String sql = "select * from marketer_member where name=?";

		String marketer_id = null;
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, name);
		ResultSet rs = pstmt.executeQuery();

		if (rs != null) {
			while (rs.next()) {
				marketer_id = rs.getString("marketer_id");
			}
			return marketer_id;
		} else
			return null;
	}

	// �귣�� ���� �Ѱ� ������Ʈ
	public boolean updateDB(Brand brand) {
		connect();

		String sql = "update brand set brandname=?, categorycode=? where brandcode=?";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, brand.getBrandname());
			pstmt.setInt(2, brand.getCategorycode());
			pstmt.setInt(3, brand.getBrandcode());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	// �귣�� ���� �Ѱ� ����
	public boolean deleteDB(int brandcode) {
		connect();

		String sql = "delete from brand where brandcode=?";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, brandcode);
			pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	// �귣���̸� �ߺ� Ȯ��
	public Boolean isBrandExist(String brandname, int categorycode)
			throws SQLException {
		connect();

		String sql = "select * from brand where categorycode=?";
		boolean result = false;

		pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, categorycode);
		ResultSet rs = pstmt.executeQuery();

		if (rs != null) {
			while (rs.next()) {
				if (rs.getString("brandname").equals(brandname))
					result = true;
				else
					result = false;
			}
		}
		return result;
	}
	
	// �귣���̸� �ߺ� Ȯ��
		public Boolean isCategoryExist(int categorycode)
				throws SQLException {
			connect();

			String sql = "select * from brand where categorycode=?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, categorycode);
			ResultSet rs = pstmt.executeQuery();

			if (rs != null) {
				return true;
			}
			else return false;
		}

}
