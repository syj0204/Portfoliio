package member;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MarketerBean {
	// �����ͺ��̽� ������� ���� ����
	Connection conn = null;
	PreparedStatement pstmt = null;

	// �����ͺ��̽� ������������� ���ڿ��� ����
	String jdbc_driver = "oracle.jdbc.driver.OracleDriver";
	String jdbc_url = "jdbc:oracle:thin:@localhost:1521:orcl";

	// �����ͺ��̽� ���� �޼���
	void connect() {
		// JDBC ����̹� �ε�
		try {
			Class.forName(jdbc_driver);
			// �����ͺ��̽� ���������� �̿��� Connection �ν��Ͻ� Ȯ��
			conn = DriverManager.getConnection(jdbc_url, "kon", "kon");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// �����ͺ��̽� ���� ���� �޼���
	void disconnect() {
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// ������ȸ�� ���� ���(ȸ������)
	public boolean insertDB(Marketer marketer) throws SQLException {
		connect();

		String sql = "insert into marketer_member(marketer_id,pw,name,phone,email) values(?,?,?,?,?)";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, marketer.getMarketer_id());
			pstmt.setString(2, marketer.getPw());
			pstmt.setString(3, marketer.getName());
			pstmt.setString(4, marketer.getPhone());
			pstmt.setString(5, marketer.getEmail());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	/*
	 * ȸ�� ���� ���(ȸ������) public boolean insertDB(Member member) { connect();
	 * 
	 * String sql =
	 * "insert into member(id,pw,name,phone,email,title) values(?,?,?,?,?,?)";
	 * 
	 * try { pstmt = conn.prepareStatement(sql); pstmt.setString(1,
	 * member.getId()); pstmt.setString(2, member.getPw()); pstmt.setString(3,
	 * member.getName()); pstmt.setString(4, member.getPhone());
	 * pstmt.setString(5, member.getEmail()); pstmt.setString(6, "marketer");//
	 * ���� �߰��ؾ�~~, �� title�� �������� pstmt.executeUpdate(); } catch (SQLException e)
	 * { e.printStackTrace(); return false; } finally { disconnect(); } return
	 * true; }
	 */

	/*
	 * ȸ�� ���� ���(ȸ������) public boolean insertDB(Member member) { connect();
	 * 
	 * String sql = "insert into member(id,pw,name) values(?,?,?)";
	 * 
	 * try { pstmt = conn.prepareStatement(sql); pstmt.setString(1,
	 * member.getId()); pstmt.setString(2, member.getPw()); pstmt.setString(3,
	 * member.getName());// ���� �߰��ؾ�~~, �� title�� �������� pstmt.executeUpdate(); }
	 * catch (SQLException e) { e.printStackTrace(); return false; } finally {
	 * disconnect(); } return true; }
	 */

	// ������ȸ�� ���� �Ѱ� ��ȸ
	public Marketer getDB(String marketer_id) {
		connect();

		String sql = "select * from marketer_member where marketer_id=?";
		Marketer marketer = new Marketer();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, marketer_id);
			ResultSet rs = pstmt.executeQuery();

			rs.next();
			marketer.setMarketer_id(marketer_id);
			marketer.setPw(rs.getString("pw"));
			marketer.setName(rs.getString("name"));
			marketer.setPhone(rs.getString("phone"));
			marketer.setEmail(rs.getString("email"));
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return marketer;
	}

	// ������ȸ�� ���� ��ü ��ȸ
	public ArrayList<Marketer> getDBList() {
		connect();

		ArrayList<Marketer> datas = new ArrayList<Marketer>();

		String sql = "select * from marketer_member";
		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Marketer marketer = new Marketer();
				marketer.setMarketer_id(rs.getString("marketer_id"));
				marketer.setPw(rs.getString("pw"));
				marketer.setName(rs.getString("name"));
				marketer.setPhone(rs.getString("phone"));
				marketer.setEmail(rs.getString("email"));
				datas.add(marketer);
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		// ó���� ���� ArrayList �� ������.
		return datas;
	}

	// ������ȸ�� ���� �Ѱ� ������Ʈ
	public boolean updateDB(Marketer marketer) {
		connect();

		String sql = "update marketer_member set pw=?, name=?, phone=?, email=? where marketer_id=?";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, marketer.getPw());
			pstmt.setString(2, marketer.getName());
			pstmt.setString(3, marketer.getPhone());
			pstmt.setString(4, marketer.getEmail());
			pstmt.setString(5, marketer.getMarketer_id());

			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	// ������ȸ�� ���� �Ѱ� ����
	public boolean deleteDB(String marketer_id) {
		connect();

		String sql = "delete from marketer_member where marketer_id=?";

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, marketer_id);
			pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			disconnect();
		}
		return true;
	}

	/*
	 * // ȸ�� ���� ��� ���� ����(���̵�ã��, �ߺ�Ȯ�� ��) public boolean getDBInfo(String name,
	 * String idnum) { connect();
	 * 
	 * String sql = "select * from member where name=? and idnum=?"; Member
	 * member = new Member();
	 * 
	 * try { pstmt = conn.prepareStatement(sql); pstmt.setString(1, name);
	 * pstmt.setString(2, idnum); ResultSet rs = pstmt.executeQuery();
	 * 
	 * if (rs != null) return true; else return false;
	 * 
	 * rs.next(); member.setName(rs.getString("name"));
	 * member.setIdnum(rs.getString("idnum"));
	 * member.setEmail(rs.getString("email")); member.setId(rs.getString("id"));
	 * member.setPw(rs.getString("pw")); member.setPhone(rs.getString("phone"));
	 * member.setTitle(rs.getString("title"));// ���� �߰��ؾ�~~ rs.close(); } catch
	 * (SQLException e) { e.printStackTrace(); return false; } finally {
	 * disconnect(); } return true; }
	 */

	// ȸ�� ���� ��� ���� ����(���̵�ã��, �ߺ�Ȯ�� ��)
	/*
	 * public boolean getDBInfo(String name, String idnum) throws SQLException {
	 * connect();
	 * 
	 * String sql = "select * from member where name=? and idnum=?";
	 * 
	 * pstmt = conn.prepareStatement(sql); pstmt.setString(1, name);
	 * pstmt.setString(2, idnum); ResultSet rs = pstmt.executeQuery();
	 * 
	 * if (rs != null) return true; else return false; }
	 */

	// ȸ�� ���� ��� ���� ����(���̵�ã��, �ߺ�Ȯ�� ��)
	/*
	 * public boolean getDBInfo2(String id, String idnum) throws SQLException {
	 * connect();
	 * 
	 * String sql = "select * from member where id=? and idnum=?";
	 * 
	 * pstmt = conn.prepareStatement(sql); pstmt.setString(1, id);
	 * pstmt.setString(2, idnum); ResultSet rs = pstmt.executeQuery();
	 * 
	 * if (rs != null) return true; else return false; }
	 */

	// ������ȸ�� ���̵� ã��
	public String getIDInfo(String name) throws SQLException {
		connect();

		String sql = "select * from marketer_member where name=?";

		String marketer_id = null;
		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, name);
		ResultSet rs = pstmt.executeQuery();

		if (rs != null) {
			while (rs.next()) {
				marketer_id = rs.getString("marketer_id");
			}
			return marketer_id;
		} else
			return null;
	}

	// ������ȸ�� ��й�ȣ ã��
	public String getPWInfo(String marketer_id) throws SQLException {
		connect();

		String sql = "select * from marketer_member where marketer_id=?";
		String pw = null;

		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, marketer_id);
		ResultSet rs = pstmt.executeQuery();

		if (rs != null) {
			while (rs.next()) {
				pw = rs.getString("pw");
			}
			return pw;
		} else
			return null;
	}

	// ���̵� �ߺ�Ȯ��
	public boolean checkID(String marketer_id) throws SQLException {
		connect();

		String sql = "select * from marketer_member where marketer_id=?";
		boolean result = false;

		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, marketer_id);
		ResultSet rs = pstmt.executeQuery();

		if (rs != null){
			while (rs.next()) {
				if (rs.getString("marketer_id").equals(marketer_id))
					result = true;
				else
					result = false;
			}
		}
		return result;
	}

	// ������ �α��� ó��
	public boolean loginControl(String marketer_id, String pw)
			throws SQLException {
		connect();

		String sql = "select * from marketer_member where marketer_id=?";
		boolean result = false;

		pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, marketer_id);
		ResultSet rs = pstmt.executeQuery();
		if (rs != null) {
			while (rs.next()) {
				if (rs.getString("pw").equals(pw))
					result = true;
				else
					result = false;
			}
		}
		return result;
	}

}
