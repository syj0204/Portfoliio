package member;

public class Marketer {
	
	private String marketer_id;
	private String pw;
	private String name;
	private String phone;
	private String email;
	
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getMarketer_id() {
		return marketer_id;
	}
	public void setMarketer_id(String marketer_id) {
		this.marketer_id = marketer_id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
}
