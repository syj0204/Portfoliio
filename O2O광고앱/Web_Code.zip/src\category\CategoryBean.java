package category;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import brand.Brand;

public class CategoryBean {
	// �����ͺ��̽� ������� ���� ����
	Connection conn = null;
	PreparedStatement pstmt = null;

	// �����ͺ��̽� ������������� ���ڿ��� ����
	String jdbc_driver = "oracle.jdbc.driver.OracleDriver";
	String jdbc_url = "jdbc:oracle:thin:@localhost:1521:orcl";

	// �����ͺ��̽� ���� �޼���
	void connect() {
		// JDBC ����̹� �ε�
		try {
			Class.forName(jdbc_driver);
			// �����ͺ��̽� ���������� �̿��� Connection �ν��Ͻ� Ȯ��
			conn = DriverManager.getConnection(jdbc_url, "kon", "kon");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// �����ͺ��̽� ���� ���� �޼���
	void disconnect() {
		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// ī�װ��� ���� �Ѱ� ��ȸ
	public Category getDB(int categorycode) {
		connect();

		String sql = "select * from category where categorycode=?";
		Category category = new Category();

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, categorycode);
			ResultSet rs = pstmt.executeQuery();

			rs.next();
			category.setCategoryname(rs.getString("categoryname"));
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return category;
	}

	// ī�װ��� ���� ��ü ��ȸ
	public ArrayList<Category> getDBList() {
		connect();

		ArrayList<Category> datas = new ArrayList<Category>();

		String sql = "select * from category order by categorycode";
		try {
			pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Category category = new Category();
				category.setCategorycode(rs.getInt("categorycode"));
				category.setCategoryname(rs.getString("categoryname"));
				datas.add(category);
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		// ó���� ���� ArrayList �� ������.
		return datas;
	}

	// ī�װ����ڵ� ��ȸ
	public int getCategoryCode(String categoryname) {
		connect();

		String sql = "select * from category where categoryname=?";
		int categorycode = 0;

		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, categoryname);
			ResultSet rs = pstmt.executeQuery();
			if (rs != null) {
				while (rs.next()) {
					if (rs.getString("categoryname").equals(categoryname))
						categorycode = rs.getInt("categorycode");
					else
						categorycode = 0;
				}
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disconnect();
		}
		return categorycode;
	}

	/*
	 * // ī�װ��� �ڵ� �Ѱ� ��ȸ public int getCategoryCode(String categoryname) {
	 * connect();
	 * 
	 * String sql = "select * from category where categoryname=?"; int
	 * categorycode = 0;
	 * 
	 * try { pstmt = conn.prepareStatement(sql); pstmt.setString(1,
	 * categoryname); ResultSet rs = pstmt.executeQuery();
	 * 
	 * rs.next(); categorycode = rs.getInt("categorycode"); rs.close();
	 * 
	 * } catch (SQLException e) { e.printStackTrace(); } finally { disconnect();
	 * } return categorycode; }
	 * 
	 * // ī�װ��� �ڵ� �Ѱ� ��ȸ public int getCategoryCode(String categoryname) throws
	 * SQLException { connect();
	 * 
	 * String sql = "select * from category where categoryname=?"; int
	 * categorycode = 0; pstmt = conn.prepareStatement(sql); pstmt.setString(1,
	 * categoryname); ResultSet rs = pstmt.executeQuery();
	 * 
	 * if (rs != null) { while (rs.next()) { categorycode =
	 * rs.getInt("categorycode"); } } else categorycode=0;
	 * 
	 * return categorycode; }
	 */
}
